# EC_P1 GPIO page-jump proof gate (NCT6694B)

When tracing `EC_P1_GPIO*` on NCT6694B schematics, enforce these gates before marking `CONFIRMED`:

1) Page-jump gate (hard)
- If the signal row only shows a cross-reference token like `<49>` and the destination page is not present in current artifacts, do **not** infer destination pin/function.
- Mark as `AMBIGUOUS` / pending evidence.

2) Continuous-wire gate (hard)
- `CONFIRMED` requires a visible continuous wire path from signal label to chip pin row on available evidence.
- Nearby text or row adjacency is insufficient.

3) PDF text cross-check gate (recommended)
- Cross-check image interpretation against PDF text extraction (`words`/vector text) for `signal`, `pin`, and `GPIOxy` function string.
- If image-only and PDF-text evidence conflict, prefer the evidence-backed interpretation and keep conflicts pending.

4) Group/bit derivation rule
- For EC_P1 labels, derive `group/bit` from resolved chip function label (`GPIOxy`), not from `EC_P1_GPIOn` suffix.
- Example from AFE-R360 page-1 evidence:
  - `EC_P1_GPIO0 -> GPIO34`
  - `EC_P1_GPIO1 -> GPIO35`
  - `EC_P1_GPIO2 -> GPIO36`
  - `EC_P1_GPIO3 -> GPIO37`

5) Partial-proof output contract
- Allow partial confirmed output and keep unresolved rows explicit:
  - `topology_status=GPIO_TRACE_PARTIAL_CONFIRMED`
  - unresolved items keep `status=AMBIGUOUS` with missing-page reason.
