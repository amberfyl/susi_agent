# Machine-B safe-default result interpretation

Use this reference after `run_machineB_full_validation.py --execute` completes.

## Required closure checks

1. Read the machine-B summary JSON, not only the process exit code.
2. Separate orchestration/infrastructure state from section verdicts:
   - `errors=[]`, successful staging, runner completion, and reload/recovery readiness indicate infrastructure closure.
   - `exit_code=1` with `status=SECTION_FAIL` can be a valid completed run with section-level failures, not an SSH or deployment failure.
3. Require both activation and recovery evidence:
   - validation reload command exit code `0`, final `Status=OK`, `Problem=CM_PROB_NONE`;
   - rollback action `RESTORED_BACKUP`, rollback command exit code `0`;
   - recovery reload status `PASS`, final readiness `ready=true`, `status=OK`, `problem=0`.
4. Summarize section counts by `verdict` and preserve partial failures. Never collapse a multi-channel failure into a global failure without naming passed and failed channels.
5. In complete-INI coexistence mode, a split-section JSON hash differing from the deployed full-INI hash is an expected warning when the runner confirms the intended section exists in the full runtime INI. Do not apply that warning-only policy to strict paired/single-section runs.

## Safe-default interpretation

The default `--all` lifecycle does not enable `AllowControl`, fixture, functional, SetConfig, stimulus, or write switches. Therefore `CONDITIONAL`, `BLOCKED_FIXTURE`, `BLOCKED_SAFETY`, and `PENDING_DQA` commonly mean the read-only/API portion completed while physical or destructive coverage was intentionally omitted. Report these separately from `FAIL_SW`/hard API or capability failures.

## Reporting pattern

Include:
- target host/user and unique run ID;
- total sections and PASS/CONDITIONAL/FAIL counts;
- each hard failure with section, result, reason, and report path;
- manifest, summary JSON/TXT, raw reports, and reload log paths;
- validation reload, rollback, and recovery status;
- explicit statement when the non-zero exit is section-level rather than infrastructure failure.

Observed example: a 14-section run can finish all runners, return `SECTION_FAIL`/exit `1` because of two independent section failures, and still have `rollback=PASS` plus final SUSI4 `Status=OK; Problem=CM_PROB_NONE`. That is a closed/recovered run with actionable section defects, not an incomplete recovery.
