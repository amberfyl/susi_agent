# NCT6694B EC_P*_GPIO pattern lock for section generation

When generating `[GPIO]` for `NCT6694B` route (including compound `EIO-300 + NCT6694B` cases where GPIO section is resolved to `NCT6694B`):

- Default target-signal set is **all** `EC_P*_GPIO*` signals visibly connected to the target chip.
- Matching regex: `^EC_P\d+_GPIO\d+$`.
- `EC_P1_GPIO*`, `EC_P2_GPIO*`, `EC_P3_GPIO*`, etc. use the same trace flow. Never hard-code P1-only scope.
- Treat this as distinct from NCT61xxD (`SIO_GPIOn`) flow.
- Do not broaden to unrelated nets merely because their chip function contains `GPIO`; only external signals matching the selected pattern enter `target_signal_set`.
- First enumerate the complete `target_signal_set` and count. Every signal must map or be explicitly marked ambiguous; do not stop after the first port group.
- Search the schematic/PDF for the target keyword, render or crop matching regions at readable resolution, then trace each actual wire to package pin/function. A downscaled full-sheet raster is not acceptable when text is too small.
- Decode INI `(group, bit)` from the visible chip function label (`GPIO34 -> 3,4`; `GPIOA5 -> 10,5`; `GPIOD0 -> 13,0`), never from the external suffix (`EC_P2_GPIO5`).
- Preserve evidence crops inside the project directory and list them in `<PROJECT>-gpio-trace.json` `meta.evidence_images`; do not cite `/tmp`-only evidence.

Rationale:
- Prevents truncating multi-port boards to eight channels.
- Prevents OCR/row-alignment errors from low-resolution whole-page renders.
- Prevents cross-page/noisy signal ingestion while keeping generated GPIO rows aligned with actual board wiring and `bios_circuit_image_analysis_rule.md` R-016/R-017.
