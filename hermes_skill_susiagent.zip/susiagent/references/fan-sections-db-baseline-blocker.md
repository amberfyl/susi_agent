# FAN sections behavior with partial DB fan tables (updated)

Observed behavior (current generator)
- `config_new.db` may have `HWM.Fan` but no `HWM.Fan.Control` table.
- Some chip keys (for example `NCT6694B`) can return `SECTION_EMPTY` for `HWM.Fan` rows in DB query.
- Fan sections can still be generated from probe/pairing/hints path in `susi_gen.py`.

What now drives generation
1) Fan key source priority:
- probe `hwm.fans`
- pairing `by_key`
- non-EC fallback BIOS fan-name hints

2) Channel construction:
- deterministic contiguous channels from base `0x80000000 + idx`
- idx priority: pairing evidence (`fanin_idx`) > stable convention > next free idx

3) Fan template fields (`io_port/options/pulses`):
- `NCT6106D/NCT6116D/NCT6126D`: `io_port=0x2E`, `options=0x80000000`, `pulses=0`
- `NCT6694B` and other non-listed chips: default `io_port=0`, `options=0x80000000`, `pulses=0`

4) `HWM.Fan.Control` generation:
- synthesized from resolved `HWM.Fan` rows + pairing policy
- when non-EC and pairing artifact is missing, fallback is deterministic one-to-one from `HWM.Fan` channels
- default control option is `0x20000000`

Verification checklist
- Do not gate fan completion on physical presence of `HWM.Fan.Control` DB table.
- Verify section matrix/result status for both fan sections is `FOUND` (or equivalent generated status), not `INVALID_SECTION`/`SECTION_EMPTY`.
- Verify rendered INI rows are deterministic and chip-gated for `io_port` as above.

Common pitfall to avoid
- Outdated assumption: "fan sections require DB `HWM.Fan.Control` table rows." This is no longer true in current flow.
