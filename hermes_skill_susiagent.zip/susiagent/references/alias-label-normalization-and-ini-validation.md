# Alias/label normalization and INI validation

## Trigger
Use this whenever BIOS-derived temperature or fan name hints feed `[HWM.Temperature]`, `[HWM.Fan]`, or `[HWM.Fan.Control]` output.

## Failure mode
Hint artifacts can legitimately preserve evidence as structured records, for example:

```json
{"label": "CPU Temperature", "evidence": "BIOS monitor row"}
```

Older artifacts may instead contain the Python representation of that record as a string:

```text
{'label': 'CPU Temperature', 'evidence': 'BIOS monitor row'}
```

Passing either object directly through `str()` produces an invalid INI display field. The generated row then contains a dict representation instead of a plain alias and may fail the SUSI INI reader.

## Required implementation boundary
1. Normalize display hints at every read/write boundary, not only in the final renderer.
2. For a mapping, use only the `label` value.
3. For a legacy dict-string, parse safely with `ast.literal_eval()`; never use `eval()`.
4. For a plain string, preserve the string as-is after trimming.
5. If no usable label exists, use the established deterministic fallback alias rather than serializing the evidence object.
6. Keep evidence metadata in the JSON artifact, but never place it in the INI alias/name field.

A shared helper such as `_coerce_display_hint()` should accept mapping objects, legacy dict-string values, and scalar strings. Apply it to both temperature and fan hint loading and to any generated hint persistence path.

## Verification gate
After regeneration, inspect both split and combined outputs:

- `<PROJECT>_HWM.Temperature.ini`
- `<PROJECT>_HWM.Fan.ini`
- `<PROJECT>_HWM.Fan.Control.ini`
- `<PROJECT>-pre.ini`

For each resolved temperature/fan row:

- final alias/name is a scalar plain string;
- no field contains `{'label':`, `{'evidence':`, or `"label":` from a serialized object;
- `[HWM.Fan]` and `[HWM.Fan.Control]` use the same resolved display name for the same key unless explicit evidence requires divergence;
- `[HWM.Current]`, `[StorageArea]`, and `[ThermalProtect]` retain their required blank Name field.

Also run Python syntax validation on the modified generator before reporting completion. Do not claim the pipeline is fixed based only on inspecting the JSON hints; validate the actual emitted INI rows.
