# Report-driven section tuple fallback

## Intent

Use this convergence path only after the first complete-INI Machine-B validation reports have been retrieved. The AI reviews those reports and decides which sections are eligible for fallback; Python owns deterministic mutation, deployment, reload, targeted rerun, and rollback.

## Responsibility split

- AI: classify first-round reports, select eligible sections, state the trigger reason, and interpret returned fallback reports.
- Python: normalize candidates, write the plan, mutate INI tuples, deploy/reload, invoke one targeted section runner per attempt, collect evidence, stop/pass/exhaust, and restore baseline when needed.
- PowerShell: execute the section API checks and emit structured English/ASCII reports.

## Trigger gate

A section is eligible only when:

- matrix status is `GENERATED` and the complete runtime INI contains valid rows;
- library initialization, transport, runner, report generation, deployment, reload, and device health succeeded;
- the section is expected to exist;
- every expected channel failed consistently, or a specifically expected capability/subfeature is absent and evidence points to `options`;
- no channel passed when using a section-wide tuple fallback.

Do not trigger for runner/infrastructure failure, stale/missing report, fixture absence, fan-not-populated, GPIO loopback absence, SMBus slave NOACK alone, a single failed channel, or ordinary DQA-pending results. Preserve partial success as `PARTIAL_FAIL` with passed/failed channels and status codes.

## Execution contract

1. Validate the baseline report first.
2. Emit a machine-readable fallback plan containing section, reason, baseline tuple, ordered candidates, acceptance predicate, and safety mode.
3. For each candidate, clone the complete baseline INI and modify only eligible rows in that section.
4. Deploy the complete candidate INI, reload once, and run only that section.
5. Stop at the first candidate satisfying the section predicate.
6. If all candidates fail, restore the baseline runtime state and report `ALL_CANDIDATES_FAILED`.
7. If a candidate passes, persist a project override consumed by the main generator/builder, regenerate canonical split/full INI and JSON artifacts, then perform one canonical targeted revalidation.

Never perform WDT Start/PWRCYCLE, ThermalProtect SetConfig, StorageArea writes, GPIO writes, fan control, fixture transactions, or other opt-ins merely because fallback is active.

## Candidate normalization and order

Treat a candidate as numeric `(io_port, options)`, then format it for INI output. Deduplicate equivalent forms such as `0` and `0x00`.

Stable order:

1. baseline tuple (validation only; never repeat it);
2. same IOPort with alternate Option;
3. same Option with alternate IOPort;
4. remaining Cartesian combinations.

Candidate application must be section-aware. Preserve HWID, channel/API identity, group/pin, ranges, offsets, names, and all unrelated fields. In SMBus, never overwrite the fixed Intel Channel1 tuple; apply fallback only to eligible derived channels such as Channel2+.

## Current bounded candidate catalog

| Section | IOPort/Address candidates | Option candidates |
|---|---|---|
| SMBus | `0`, `0x2E`, `0x4E` | `0xA0000000` |
| I2C | `0`, `0x2E`, `0x4E` | `0x20000000` |
| VGA.Backlight | `0` | `0xA0000000` |
| VGA.Brightness | `0`, `0x2E`, `0x4E` | `0x00000000`, `0x20000000` |
| HWM.Voltage | `0`, `0x2E`, `0x4E` | `0x80000000` |
| HWM.Current | `0` | `0xA0000000` |
| HWM.Temperature | `0`, `0x2E`, `0x4E` | `0x80000001` |
| HWM.Fan | `0`, `0x2E`, `0x4E` | `0x80000000` |
| HWM.CaseOpen | `0x2E`, `0x4E`, `0x9E` | `0xA0000000` |
| WDT | `0`, `0x2E`, `0x4E` | `0xA0000000` |
| GPIO | `0`, `1`, `0x2E`, `0x4E`, `0x40`, `0x42`, `0x44`, `0x46`, `0x48`, `0x4A`, `0x4C` | `0x20000003`, `0xA0000003` |
| StorageArea | `0` | `0xA0000000` |
| ThermalProtect | `0` | `0xA0000000` |

This is a bounded catalog of values observed within the current DB scope, not proof that every Cartesian pair is valid.

## Evidence and outcomes

Record per attempt: candidate index, before/after tuple, candidate INI path/hash, deploy/reload health, report path, channel totals, passed/failed channels, status codes, and decision.

Recommended decisions:

- `BASELINE_PASS`
- `BASELINE_NOT_ELIGIBLE`
- `FALLBACK_NOT_TRIGGERED_PARTIAL_FAILURE`
- `CANDIDATE_VALIDATED_PASS`
- `ALL_CANDIDATES_FAILED`
- `FALLBACK_ABORTED_INFRASTRUCTURE_ERROR`
- `CANONICAL_REVALIDATION_PASS`
- `CANONICAL_REVALIDATION_FAIL`

## DB-first guard

Before adding a project-specific mapping file, query the active DB by `(product_name, chip_name) -> hardware_id -> section row`. If the row already supplies the full tuple, use it directly. Do not encode a duplicate board-specific answer such as a Brightness channel override merely to reproduce data already present in `VGA.Brightness`.
