# Compaction no-op + side-effect consent gate (2026-09-08)

Class of failure
- A context-compaction handoff block appeared without a new actionable user request.
- The agent resumed stale workflow actions (remote SCP sync) and hit a side-effect consent block.

Durable fix for this workflow class
1) If the latest user request is read/review-only (e.g., "看一下這檔案"), perform file read/summary only.
2) If a compaction/handoff message appears and there is no concrete post-handoff user ask, STOP and wait; do not resume prior pending execution.
3) For remote side effects (SCP/SSH writes, remote script execution that changes state), require explicit current-turn user consent before running.
4) If a side-effect command is denied by policy, do not retry via alternate command/path; report blocked status and wait for approval.

Quick operator checklist
- Latest ask parsed? (yes/no)
- Action class = read-only vs side-effect
- If side-effect: explicit consent in current turn?
- If no consent or denied: stop + report + wait
