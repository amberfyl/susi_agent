# FAN multipage mapping: connector count vs independent control channels

Purpose
- Prevent over-assigning fan control channels when schematics split evidence across pages.

Pattern observed
- A core SIO page may expose only logical fan nets (for example CPU/SYS1/SYS2).
- Separate fan-control pages may add more physical fan connectors (for example SYS3/SYS4).
- Extra connectors do not automatically imply extra independent PWM control sources.

Working rule
1) Build connector-level map (each fan header's TACH and PWMOUT path).
2) Build upstream control-source map (PWMIN/PWM source net into each control IC).
3) Merge both maps and decide whether channels are independent or shared.

Do not do
- Do not assume `connector_count == control_channel_count`.
- Do not assign FOEM channels from connector names alone.

One-to-one consequence
- Only when IN/OUT pairing is uniquely one-to-one should `[HWM.Fan]` and `[HWM.Fan.Control]` be emitted with synchronized mapping payload (hwid/channel_id/io_port/alias), differing only by section-fixed template fields.
