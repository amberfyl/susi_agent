# Screen-control schematic evidence and BL labels

## Goal

Confirm whether a support-table entry such as `HW socket: BL1` really corresponds to an LVDS/eDP backlight connector before using it as evidence for `VGA.Backlight` or `VGA.Brightness`.

## Do not match by token alone

`BL1` can appear in unrelated schematic contexts:

- a connector/socket reference for a backlight or inverter cable;
- a component value, internal part code, annotation, or rail/block label near a power inductor;
- a net label containing `BL` with no connector identity.

A `BL1` token next to an inductor reference such as `PL3`, surrounded by `SW`, `FB`, buck-regulator, inductance/current/DCR data, is power-converter/component context. It is not sufficient evidence for the support-table HW socket.

## Positive connector evidence

Treat `BL1` as the screen-control socket when the schematic shows a connector symbol and pin-level signals such as:

- panel/inverter power (`+V5`, `+V12`);
- ground;
- backlight enable (`BL_EN`, `BKLT_EN`, `ENABKL`, `BL_ON`, variants);
- brightness PWM (`BL_PWM`, `BKLT_PWM`, `LVDS*_PWM`, EC PWM variants).

Then keep the two functions separate:

- PWM path -> `[VGA.Brightness]`
- Enable/ON path -> `[VGA.Backlight]`

The same physical socket may support both and therefore map to `BACKLIGHT1` in both SUSI sections.

## Search order

1. Search the controlling EC identity (for example the chip named in the support table).
2. Search panel connector terms: `LVDS`, `LCD`, `PANEL`, `INVERTER`, `eDP`.
3. Search enable variants: `BL_EN`, `BKLT_EN`, `ENABKL`, `BACKLIGHT_EN`, `BL_ON`.
4. Search brightness variants: `BL_PWM`, `BKLT_PWM`, `LCD_PWM`, `LVDS*_PWM`, `EC_*PWM`.
5. Use bare `BL1` only as a secondary search because it is collision-prone.

Trace EC -> conditioning/buffer -> named PWM/enable net -> connector pin. Do not infer SUSI API IDs, tuple channels, polarity/options, or GPIO pins from the connector name alone; obtain those from DB rows, public API definitions, and probe evidence.

## MIO-2375 example evidence

A confirmed `BL1` 5-pin connector shows:

- pin 1: `+V5_1_INVERTER_0`
- pin 2: `EC_LVDS1_z_PWM` (brightness path)
- pin 3: `LVDS1_z_ENABKL` (backlight enable path)
- pin 4: `GND`
- pin 5: `+V12_1_INVERTER_0`

This supports one physical backlight socket with both Brightness and Backlight ON/OFF functions. It does not by itself determine SUSI API ID or INI tuple fields. A `z` suffix may hint active-low naming but is not enough to alter SUSI polarity/options without authoritative data.
