# Machine-B StorageArea JSON and runner contract

## Scope
StorageArea is a normal Machine-B section that must produce a section JSON and a PowerShell runner. Do not silently omit it or treat it as a ThermalProtect/WDT power-state feature.

## Builder output
`build_machineB_section_configs.py` should include:

- `StorageArea` in `SECTION_OUTPUTS`
- output `<project>_storage.json`
- `required_channels` from `[StorageArea]` keys (`Area0`, `Area1`, ...)
- preserve the INI tuple separately as `tuple_channel`
- map public storage IDs from `Susi4.h`:
  - `Area0` -> `SUSI_ID_STORAGE_STD` / `0x00000000`
  - `Area1` -> `SUSI_ID_STORAGE_OEM0` / `0x00000001`
  - `Area2` -> `SUSI_ID_STORAGE_OEM1` / `0x00000002`
  - in general `AreaN` -> ID `N` (`Area1` is OEM0)

The JSON should carry capability item IDs:

- total size: `0x00000000`
- block size: `0x00000001`
- lock status: `0x00010000`
- password max length: `0x00010001`

Read policy should include offset, length, sample count, and minimum success rate. Write policy may include enabled, verify, restore-original, and a test pattern, but a write must never happen merely because the JSON exists.

## Runner contract
`run_storage_validation.ps1` should:

1. validate `source_ini.section == StorageArea` and required keys;
2. initialize SUSI;
3. call `SusiStorageGetCaps` for each required storage ID;
4. call `SusiStorageAreaRead` for configured offset/length and report data as hex;
5. support an explicit write/verify/restore path only when both the JSON write policy and `-EnableWriteTest` are enabled;
6. restore original bytes after a write test when `restore_original` is true;
7. report L1-L6 and CI exit status consistently with other Machine-B runners.

Add the StorageArea P/Invoke declarations to the shared `common_susi.ps1` rather than duplicating them in every runner.

## Workflow pitfall
A user asking to “also handle Storage” may mean “generate Storage JSON and PS1,” not “disable Storage.” Confirm the requested operation from the latest message. Do not add a safety gate that removes Storage outputs or marks the section unsupported merely because WDT/ThermalProtect power-state tests were disabled.

## Verification
After implementation, verify:

- builder writes `<project>_storage.json` from a matrix containing `StorageArea`;
- `storage_api_id_name` for Area0 is `SUSI_ID_STORAGE_STD`;
- JSON parses;
- PowerShell parser accepts both `common_susi.ps1` and `run_storage_validation.ps1`;
- no remote run is claimed unless the user explicitly requested execution and the resulting report is pulled and checked.
