# Project path canonical-output lock (directory-vs-file resolver pitfall)

When `/CASES/<PROJECT>.json` exists at the CASES root, running:

`.../susi_gen.py --project <PROJECT> --root .../CASES ...`

may resolve outputs to CASES root-level artifacts (for example `.../CASES/<PROJECT>-pre.ini`) instead of the canonical project directory.

Required hardening for `/susiagent` runs:

1) Use `--project` as absolute project directory path (`.../CASES/<PROJECT>`), not token-only.
2) Always pass explicit canonical output paths:
   - `--in-pdf .../CASES/<PROJECT>/<PROJECT>.pdf`
   - `--out-json .../CASES/<PROJECT>/<PROJECT>.json`
   - `--spec-out .../CASES/<PROJECT>/<PROJECT>-spec.json`
   - `--out-ini .../CASES/<PROJECT>/<PROJECT>-pre.ini`
3) Keep `--probe` inside canonical project dir.
4) After run, verify no newly-produced competing root-level artifacts are being treated as active outputs.

5) Downstream matrix/source lock:
   - Feed `build_machineB_section_configs.py --matrix` with the same-run matrix under the canonical project dir (`.../CASES/<PROJECT>/<PROJECT>-section-matrix.json`).
   - Do not mix it with root-level duplicates (`.../CASES/<PROJECT>-section-matrix.json`) from older or drifted runs.
   - Sanity-check that matrix `sections[*].path` entries share the same base directory as `--out-ini`.

6) Cleanup policy for duplicates:
   - If duplicate root-level artifacts exist, report them as stale candidates.
   - Remove/overwrite only with explicit user approval; otherwise keep them untouched and continue using canonical in-project artifacts.

This prevents mixed-location artifacts and keeps `section-matrix.project`, split INIs, and Machine-B JSON generation aligned to one canonical project tree.