# ARK-1251 GPIO wire-tracing reference

For the ARK-1251 NCT6694B schematic, the corrected BI mappings established from focused schematic crops are:

| Signal | Logical GPIO | EC package pin |
|---|---|---|
| `EC_P1_GPIO1` | `GPIO34` | `L6` |
| `EC_P1_GPIO2` | `GPIO35` | `M6` |
| `EC_P1_GPIO3` | `GPIOD5` | `D11` |
| `EC_P1_GPIO4` | `GPIOB1` | `F1` |
| `EC_P1_GPIO5` | `GPIO73` | `A12` |
| `EC_P1_GPIO6` | `GPIO66` | `D12` |
| `EC_P1_GPIO7` | `GPIO67` | `C12` |
| `EC_P1_GPIO8` | `GPIO70` | `B12` |

Important correction: `EC_P1_GPIO3` routes to `SOUTF/GPIOD5/D11`, not `GPIOD4/E11`; `EC_P1_GPIO4` routes to `GPIOB1/F1`, not `GPIOB3/F2`. The earlier errors came from nearest-text/y-coordinate matching. Use vector wire tracing, including horizontal routes and bends, as the authoritative method.
