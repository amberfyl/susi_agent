# Machine-B full-INI single-reload validation

Use this pattern when validating all generated/runnable SUSI sections together on a target. It is the normal coexistence-validation path; per-section INI deployment is a diagnostic/convergence exception.

## Target path and activation convention

For the current Machine-B layout, use these paths unless a read-only target inventory proves the host differs:

- Runtime-loaded INI: `C:\Windows\SUSI\<project>.ini`
- Complete generated source on Machine-A: `<project>-pre.ini`
- Deployment rule: copy the complete source into the runtime slot **renamed to `<project>.ini`**. SUSI does not load `<project>-pre.ini` as the runtime filename.
- Project workspace: `C:\Users\susiaa\Desktop\verify\<project>\`
- Config JSON: `...\<project>\config\`
- Split/diagnostic INIs: `...\<project>\ini\`
- Section runners/helpers: `...\<project>\scripts\`
- Reports: pass an explicit project-scoped output path under `...\<project>\out\` (a per-run subdirectory is allowed and preferred for a full batch).
- Existing target reload entrypoint: `C:\Users\susiaa\Desktop\reload driver\reload_susi4_driver.bat`. Invoke the BAT already installed on the target; do not upload another reload implementation during the normal full-INI run. The BAT wraps the colocated `reload_susi4_driver.ps1` and writes `susi4_driver_reload.log`.

Run the reload BAT through target `cmd.exe`/`cmd /c`, retain its exit code/log, and independently verify final SUSI4 PnP state. A BAT launch/exit message alone is not proof that disable/enable completed.

This full-INI coexistence rule supersedes older split-INI single-slot references for the normal all-section run. Older per-section deploy/reload documents remain valid only for isolation, conflict diagnosis, or candidate convergence.

## Primary flow

1. Resolve the canonical project and read the section matrix.
2. Select sections whose matrix/config state is runnable; record skipped/pending sections explicitly.
3. Back up the target runtime INI and record its SHA-256.
4. Deploy the complete `<project>-pre.ini` once.
5. Close applications that may hold SUSI4 handles, then perform exactly one driver reload and verify final PnP health.
6. Start each section runner in a separate PowerShell process, sequentially, against the same complete runtime INI.
7. Each runner performs its own `SusiLibInitialize`/`SusiLibUninitialize`; these calls are not driver reloads.
8. Pull each newly timestamped JSON report immediately and retain runner exit code/stdout/stderr.
9. Perform lightweight health checks between runners; do not reload merely because one API verdict failed.
10. Produce a run manifest and aggregate summary with section status, SW/DQA verdicts, actual API calls, write/restore evidence, report path, and runtime INI hash.
11. In cleanup, restore the original INI when the run is temporary, reload after restore, and verify restored hash plus final device health.

## Ordering and safety

Run read-only/capability sections first, reversible writes second, and high-risk or fixture-dependent sections last.

- Read-only examples: SMBus/I2C capability, HWM Voltage/Current/Temperature/Fan/CaseOpen.
- Reversible writes: Backlight, Brightness, Fan Control, GPIO, StorageArea. Enable only when both JSON policy and the runner switch permit it; verify restoration.
- High-risk: WDT and ThermalProtect. Default to non-destructive GetCaps/GetConfig paths. Reboot, power-cycle, or Thermal SetConfig needs explicit current-turn approval.

Do not merge all section logic into one large runner. The orchestrator owns deployment, one-time reload, sequencing, report collection, health checks, and cleanup; section runners retain section-specific API logic.

## Hash policy

For complete-INI coexistence validation, a JSON `source_ini.sha256` may refer to the split section INI while the target intentionally runs the complete pre-INI. Therefore:

- Default: record both hashes and emit a provenance warning; do not block the runner solely on this expected mismatch.
- Validate that the complete runtime INI contains the required section and expected rows/identities.
- Strict source-hash enforcement is opt-in for paired/single-section validation or artifact-integrity audits.
- Never silently ignore an unexpected mismatch when the declared mode is paired/single-section validation.

## Isolation and convergence exception

Switch to a split section INI with its own deploy/reload cycle only when:

- the complete INI cannot load or destabilizes the driver;
- a section fails and cross-section interference must be isolated;
- an ordered candidate loop requires deploy -> reload -> reprobe -> evaluate for each candidate (for example Temperature/Voltage convergence);
- the runner/config contract explicitly requires paired-section provenance.

A normal API failure is report evidence, not an automatic reason to reload. Preserve the full-INI result, then run isolation as a separately labelled diagnostic result.

## Failure handling

- Driver reload or health failure: stop subsequent runners and enter recovery/cleanup.
- Runner crash or missing report: record infrastructure failure; do not count the section as completed.
- API/config failure with a valid report and healthy driver: record it and continue so the run captures the complete section set.
- Aggregate exit status must not be a hardcoded success; derive it from the configured SW verdict policy while retaining DQA conditional states separately.
