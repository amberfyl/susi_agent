# config schema migration audit

Use this checklist whenever AIagent_susi changes from one configuration database schema to another.

## Audit scope

Search both the project and the loaded `susiagent` skill library for:

- database filenames (`config.db`, `config_new.db`)
- retired table names (`GPIO.Defaults`, `GPIO.GroupPins`, `HWM.*.Channels`, `HWM.*.Defaults`)
- retired join keys (`prod_chip_id`)
- old column aliases (`item_name`, `channel`, `option`, `disp_name`)
- hardcoded `--db`, `DEFAULT_DB_PATH`, or SQLite open paths

Check runtime code, CLI wrappers, JSON/INI case artifacts, Markdown rules, and skill references. A schema migration is incomplete if only Python code is updated while skill instructions still prescribe the retired schema.

## Active config_new.db query contract

1. Resolve ProductChip using the fixed `(product_name, chip_name)` key.
2. Use `ProductChip.hardware_id` to join section tables.
3. Query hardware-specific section rows directly (`GPIO`, `HWM.Temperature`, `HWM.Voltage`, `HWM.Fan`, etc.).
4. Keep compatibility aliases only at the query API boundary; do not treat aliases as database columns.
5. Keep circuit/probe evidence rules separate from DB lookup rules. DB rows provide deterministic templates/baselines; they do not replace SIO circuit tracing or FAN topology judgement.

## Skill synchronization

After code migration, inspect every loaded skill and linked reference that mentions the old schema. Replace operational instructions with the active schema. Retain old names only when explicitly labeled as retired/non-query targets, so future agents do not accidentally restore the old flow.

## Verification

- Search the project and skill directory for active `config.db` bindings.
- Search for retired table names and `prod_chip_id`.
- Compile changed Python files.
- Run one known ProductChip/section query against `config_new.db`.
- Validate edited JSON artifacts.
- Re-read the skill/reference after patching to ensure it describes the same query contract as the code.
