# Section tuple fallback after first validation

## Purpose

Use a bounded fallback only when the generated section exists but its `io_port/address` or `options` prevents the section from activating correctly.

## Ownership and sequence

1. Run the normal first validation with the complete generated INI.
2. Retrieve all fresh section reports.
3. AI reviews the reports and decides which sections qualify for fallback.
4. AI emits a structured fallback plan with section, evidence, reason, and ordered candidates.
5. Python performs deterministic candidate mutation, complete-INI deploy/reload, targeted section execution, report retrieval, and rollback.
6. AI interprets the new report. Stop on the first validated candidate; otherwise continue until exhausted.

AI decides the branch; Python owns execution. Do not have AI manually rewrite and deploy each INI.

## Trigger gate

Trigger only when:
- matrix status is `GENERATED` and the section rows exist;
- driver/reload, SUSI initialization, runner execution, and report generation are healthy;
- all expected channels fail consistently, or the report provides section-specific evidence that an expected capability was not enabled by `options`;
- the failure is not a runner/infrastructure error, dependency failure, absent fixture, unpopulated fan, missing GPIO loopback, or isolated single-channel mapping issue.

A partial channel failure must remain `PARTIAL_FAIL`; do not trigger a section-wide tuple fallback when any required channel already works.

## Candidate execution

- Candidate unit is `(io_port, options)`.
- Normalize numeric values before deduplication (`0` and `0x00` are the same value; `1` is distinct).
- Keep the current tuple as baseline and do not retest it as a candidate.
- Prefer one-field changes first: change option with baseline port, then port with baseline option, then remaining combinations.
- Each round changes one problem section only in a complete INI, reloads once, and runs only that section.
- Preserve HWID, channel/API identity, key, offsets, ranges, names, group/pin, and every non-candidate field.
- Apply section-aware row selection. In particular, do not overwrite fixed Intel SMBus Channel1 while testing derived Channel2+ rows.
- Safe defaults remain in force: no WDT Start/PWRCYCLE, ThermalProtect SetConfig, Storage write, GPIO functional write, fan control, brightness/backlight toggle, or SMBus fixture transaction without separate authorization.
- On exhaustion, restore baseline and report `ALL_CANDIDATES_FAILED`.

## Bounded candidate catalog

| Section | IOPort/Address | Option |
|---|---|---|
| SMBus | `0`, `0x2E`, `0x4E` | `0xA0000000` |
| I2C | `0`, `0x2E`, `0x4E` | `0x20000000` |
| VGA.Backlight | `0` | `0xA0000000` |
| VGA.Brightness | `0`, `0x2E`, `0x4E` | `0x00000000`, `0x20000000` |
| HWM.Voltage | `0`, `0x2E`, `0x4E` | `0x80000000` |
| HWM.Current | `0` | `0xA0000000` |
| HWM.Temperature | `0`, `0x2E`, `0x4E` | `0x80000001` |
| HWM.Fan | `0`, `0x2E`, `0x4E` | `0x80000000` |
| HWM.CaseOpen | `0x2E`, `0x4E`, `0x9E` | `0xA0000000` |
| WDT | `0`, `0x2E`, `0x4E` | `0xA0000000` |
| GPIO | `0`, `1`, `0x00`, `0x2E`, `0x4E`, `0x40`, `0x42`, `0x44`, `0x46`, `0x48`, `0x4A`, `0x4C` | `0x20000003`, `0xA0000003` |
| StorageArea | `0` | `0xA0000000` |
| ThermalProtect | `0` | `0xA0000000` |

These values are a bounded observed candidate set, not proof that every Cartesian pair is valid.

## Result recording

Record per attempt: section, candidate index, before/after tuple, candidate INI hash/path, reload result, report path, passed/failed channels and status codes, and decision. Recommended decisions:

- `BASELINE_PASS`
- `FALLBACK_NOT_TRIGGERED_PARTIAL_FAILURE`
- `CANDIDATE_VALIDATED_PASS`
- `ALL_CANDIDATES_FAILED`
- `FALLBACK_ABORTED_INFRASTRUCTURE_ERROR`
