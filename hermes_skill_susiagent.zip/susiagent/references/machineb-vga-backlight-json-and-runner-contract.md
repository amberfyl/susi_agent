# Machine-B VGA.Backlight JSON and runner contract

## Why this reference exists

A Machine-B section run is only reproducible when the generated section INI, the JSON policy, and the runner agree on two different identities:

- the INI tuple/configuration channel used to describe the generated board configuration;
- the public SUSI API identifier passed to `SusiBoardGet*`/`SusiBoardSet*` calls.

Do not assume those values are interchangeable. Before running a target, compare the runner API IDs against the full-probe `HWM_BACKLIGHT_*` `[OK]` entries and record the comparison in the run evidence.

## Backlight generation count filter

Treat `config_new.db` `VGA.Backlight` rows as the maximum set. When the full `*susi_board_probe_report.txt` contains a `VGA.Backlight Channels` block, count only primary `[OK] ... Status=FOUND` channel rows and retain the first N DB rows; do not count `_Enable`/`_Brightness`/`_Level`/`_Polarity`/`_Frequency` value rows as additional channels. Remove excess rows from both the split INI and complete pre-INI. If the probe block is absent, preserve the DB maximum set. Record probe count, DB count, trimmed count, and `PROBE_CHANNEL_FILTER` in section-matrix metadata.

## Builder contract

`build_machineB_section_configs.py` should own the reproducible conversion from the generated matrix and split INI to `<project>_backlight.json`. The JSON should contain, at minimum:

- `category: "VGA.Backlight"`;
- source INI path and SHA-256;
- normalized items (`BACKLIGHT1`, `BACKLIGHT2`, ...);
- both `ini_tuple`/encoded channel and canonical `api_id` for each item;
- read/capability policy;
- `functional_test.enabled: false` by default;
- the common SW/DQA verdict policy.

Unknown Backlight keys or missing API mapping must fail JSON generation. Silently copying the tuple channel produces false `SUSI_STATUS_UNSUPPORTED` results and hides an ID-namespace defect.

## Runner safety contract

The default runner is read-only. `-EnableFunctionalTest` is not sufficient by itself: the JSON must also explicitly set `functional_test.enabled=true`.

When both gates are enabled, use this exact reversible sequence:

1. `GetEnable` and save the original value.
2. `SetEnable(!original)`.
3. `GetEnable` and verify the toggled value.
4. `SetEnable(original)`.
5. `GetEnable` and verify restoration.

If caps, initial GetEnable, or the required API call returns unsupported/error, stop before any SetEnable. Report `BLOCKED_UNSUPPORTED`/`N_A` according to the project contract; do not label it a functional-toggle failure and do not attempt writes after a failed prerequisite.

## Remote execution evidence

Distinguish two modes before acting:

- **Formal paired-config validation:** use the deployment/reload/restore sequence below.
- **Current-runtime read-only diagnostic:** when the user explicitly forbids INI update and reload, do not perform any deployment stages. Upload only runner/JSON/common helper, omit `-EnableFunctionalTest`, pass the live INI explicitly, and compare its SHA-256 before/after. If the generated JSON requires channels absent from the live INI, use a temporary live-channel JSON only to observe current API behavior and label it non-formal runtime evidence. See `machineb-current-runtime-readonly-diagnostics.md`.

For a formal target-B run:

1. Sync `common_susi.ps1`, the Backlight runner, JSON, and section INI; verify hashes.
2. Back up the live runtime INI.
3. Deploy the paired section INI.
4. Reload the SUSI4 driver/runtime; record this as a separate stage from `SusiLibInitialize`/`SusiLibUninitialize`.
5. Run the Backlight runner with explicit `-ConfigPath` and `-IniPath`.
6. Pull the newly timestamped report and use that report as the current result.
7. Restore the original runtime INI.
8. Reload after restore and verify the backup hash plus final device status.

If a mapping/config is corrected, the old report remains root-cause evidence only. A corrected run must produce and cite a new timestamped report.

## Verdict interpretation

Keep `result`, `reason`, `sw_verdict`, `dqa_verdict`, and `ci_exit_code` separate:

- SW: configuration, capability, API, and readback.
- DQA: functional toggle and recovery/restore.
- CI exit code follows SW verdict only.
- A disabled functional gate or absent fixture can be `CONDITIONAL`/`N_A`; an API namespace mismatch or failed required readback is a SW failure/blocker.

## Verification checklist

- [ ] Matrix status is valid for `VGA.Backlight`.
- [ ] Split INI exists and its SHA-256 matches JSON.
- [ ] JSON contains distinct tuple channel and canonical API ID.
- [ ] API IDs were checked against full-probe Backlight IDs.
- [ ] Default run made no SetEnable calls.
- [ ] Functional run had both explicit gates enabled.
- [ ] Functional run restored the original enable state.
- [ ] Pulled report is newer than the correction and is the cited result.
- [ ] Runtime INI hash and final device status were verified after cleanup.
