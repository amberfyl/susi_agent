# Local probe + no request form + image-cap fallback (ARK-2233 pattern)

When user explicitly provides:
- local probe report already in project directory (skip SSH),
- no request form,
- explicit `chip_name`,
- explicit unchecked sections (e.g. SMBus/I2C/Backlight/Brightness),

use this deterministic path.

## Why
`--stage all` can fail in extract/understand when source PDF embeds too many images (Responses API input-image cap, e.g. 96 > 50). In no-request-form mode, this should not block feasible sections.

## Run pattern
1) Keep canonical project lock: use absolute `--project /.../CASES/<PROJECT>` and explicit `--out-json/--spec-out/--out-ini` in project dir.
2) If canonical `<PROJECT>.json` / `<PROJECT>-spec.json` are missing, create minimal bootstrap artifacts (request-form bypass) with:
   - project identity,
   - `chips` using canonical DB chip key,
   - `features` booleans matching user unchecked list,
   - `feature_details` preserved as structured fields.
3) Run `susi_gen.py --stage generate` (not `--stage all`) with:
   - `--in-json <PROJECT>.json`
   - `--probe <local_report.txt>`
   - `--chip-name <canonical ProductChip.chip_name>`
   - `--sections` set to enabled subset only.
4) Verify matrix buckets and only claim Machine-B JSON for sections that are `GENERATED`.

## Guardrails
- Do not re-enable unchecked sections automatically.
- Do not rename probe file only to match default naming.
- Do not claim fan/fancontrol JSON when matrix shows `SKIPPED_EMPTY_SECTION` / `PENDING_*` / ambiguity.
- Report extract-stage image-cap as a blocker only for `all`, then continue via generate-only fallback when user intent allows.