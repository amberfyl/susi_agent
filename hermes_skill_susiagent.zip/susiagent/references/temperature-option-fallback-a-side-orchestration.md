# Temperature option fallback orchestration (A-side)

Context
- A standalone helper originally lived under `targetB_task/machineB_validation/` and was not part of the one-command pipeline.
- To keep A-side as source-of-truth, fallback decision/mutation must be triggered by `susi_gen.py` automatically, not by manual/isolated execution.

Canonical ownership
- Canonical helper path: `/home/company2/AIagent_susi/tools/hwm_temperature_option_fallback.py`
- Backward-compatibility wrapper may remain at:
  `/home/company2/AIagent_susi/targetB_task/machineB_validation/hwm_temperature_option_fallback.py`
  and delegate to the canonical helper.

When to trigger
- In `susi_gen.py` generate flow, after section/pre-INI are rendered but before final section-matrix write:
  - `HWM.Temperature` section status is `GENERATED`
  - route is non-EC
  - chip is SuperIO seed family requiring this policy
  - probe file exists
- Decision source: helper JSON output
  - `CANDIDATE_PREPARED_NEEDS_VALIDATION`: baseline全ERR，已套用第一組 `(io_port,option)` 等待上機驗證
  - `CANDIDATE_VALIDATED_PASS`: 迭代測試命中，已保留成功候選組
  - `ALL_CANDIDATES_FAILED`: 候選組合耗盡仍全ERR
  - `BASELINE_NOT_ALL_ERR`/skip/error states: record as-is

Mutation scope
- Run helper against BOTH artifacts in one attempt cycle:
  1) split section INI (`<PROJECT>_HWM.Temperature.ini`)
  2) merged pre-INI (`<PROJECT>-pre.ini`)
- Fallback operation is candidate iteration over `(io_port, option)` tuples when baseline probe indicates all HWM temperature reads are ERR.
  - each round: rewrite both INIs with one tuple → deploy/reload/probe (when runner is provided)
  - stop at first non-all-ERR result and keep that tuple
  - if all tuples fail, keep failure evidence and mark pending

Matrix recording
- Persist helper outcome object under section-matrix entry field:
  - `temperature_option_fallback`
  - include baseline summary, candidates, attempts, selected candidate, and decision
- For decisions `CANDIDATE_PREPARED_NEEDS_VALIDATION` / `CANDIDATE_VALIDATED_PASS` / `ALL_CANDIDATES_FAILED`, append route suffix `+TEMP_OPTION_FALLBACK` once.

Verification checklist
1. Run generate/all with probe.
2. Confirm section matrix includes `temperature_option_fallback` payload for `HWM.Temperature`.
3. If fallback triggered, confirm route suffix contains `TEMP_OPTION_FALLBACK`.
4. Re-read both split/pre INI to verify `io_port` and `option` values switched consistently to the selected candidate tuple.
