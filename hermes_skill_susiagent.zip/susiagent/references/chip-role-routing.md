# Chip-role routing: EIO-300 / NCT6694B / NCT61xxD

Use this when `spec.feature_details.*.chip` strings include mixed labels like `EIO-300 (Nuvoton NCT6694B)`.

## Core rule
- `NCT6694B` is section-limited in compound EIO-300 cases:
  - Route to `NCT6694B`: `GPIO`, `I2C`, `SMBus`
  - Route to EC side (`EIO-300` / `Advantech EIO_IS200`): all other EC-side sections (for example WDT/Storage/ThermalProtect and EC-side HWM paths)

## Pure SIO guard
- `NCT61xxD` family (`NCT6106D` / `NCT6116D` / `NCT6126D`) is pure SuperIO routing.
- Do not treat `NCT61xxD` as EC.

## Anti-patterns
- Do not classify EC vs SIO from vendor-style strings alone (`Nuvoton*`, casing, punctuation).
- Do not force one chip for all sections when the board uses compound roles.

## Operational check
When output looks inconsistent, verify by section:
1) Which section is being generated?
2) Is that section in the `NCT6694B` allowlist (`GPIO/I2C/SMBus`)?
3) If not, route via EC side (`EIO-300`/`Advantech EIO_IS200`) instead.
4) For compound `EIO-300` generation, initialize GPIO circuit-trace loading/regeneration with the resolved GPIO section chip (`NCT6694B`), not the top-level `EIO-300` key. Otherwise a valid `<PROJECT>-gpio-trace.json` can be ignored and the matrix remains `GPIO_TRACE_REQUIRED_NCT6694B`.
