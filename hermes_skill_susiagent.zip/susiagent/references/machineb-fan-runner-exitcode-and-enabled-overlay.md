# Machine-B fan runner exit-code/report precedence and enabled-overlay JSON

When running split Machine-B fan validators (`hwm.fan_verify.ps1`, `hwm.fan.control.ps1`), apply these operational rules:

1) `fancontrol` safety-default handling
- `<project>_fancontrol.json` often keeps `control_check.enabled=false` by design.
- `-AllowControl` alone is not enough in this state; runner returns `BLOCKED_CONFIGURATION`.
- For active control-effect validation, create a sibling overlay JSON (example: `<project>_fancontrol_enabled.json`) and only change:
  - `control_check.enabled = true`
  - top-level `enabled = true` (if key exists)
- Keep baseline JSON unchanged for reproducibility/safety.

2) Exit code vs report precedence
- `hwm.fan_verify.ps1` can print `DONE. Report: <path>` even with non-zero process exit.
- Do not classify the run from process exit code alone when a report file exists.
- Parse report JSON (`result`, `reason`, `checks`, `validation_layers`) and use that as authoritative run outcome.

3) Practical remote invocation pattern
- Always run with process-scope policy bypass in the same command:
  - `Set-ExecutionPolicy -Scope Process Bypass -Force`
- Pass explicit `-ConfigPath`/`-FanConfigPath`/`-IniPath`/`-FanIniPath` in section-only runs to avoid model-name inference drift.
- Sync `common_susi.ps1` before execution and verify remote files after SCP.

4) Reporting shorthand
- Fan read robustness summary: `result/reason` + per-channel RPM min/avg/max.
- Fan control summary: per-target PWM readback pass + RPM trend by sequence.
