# SuperIO HWM Voltage/Temperature v2 auto-convergence loop

When `/susiagent` is expected to finish in one command, a single `fetch -> generate` pass is insufficient for some SuperIO boards.

## Why this is needed

For non-EC SuperIO chips (`NCT6106D` / `NCT6116D` / `NCT6126D` / `NCT6776D`), `susi_gen.py` has v2 refine logic for:
- `HWM.Voltage` (`SUPERIO_V2_BIOS_PROBE_ALIAS`)
- `HWM.Temperature` (`SUPERIO_TEMP_V2_BIOS_PROBE_ALIAS`)

But these refiners are data-gated:
- BIOS-visible labels/hints must exist, and
- probe must contain `[OK]` channels for the corresponding items.

If first-pass probe has no `[OK]` for these sections, output remains seed-v1-style even though code supports v2.

## Mandatory second-round cases (user policy)

Run second-round as a hard requirement for:
- Chip family: `NCT61xxD` (`NCT6106D`, `NCT6116D`, `NCT6126D`)
- Sections: `HWM.Voltage` and `HWM.Temperature`

Interpretation:
- First round may output v1 seed.
- `/susiagent` must continue with deploy -> re-probe -> regenerate until v2 evidence appears, or return an explicit blocker.
- Do not declare completion for these 61xxD sections after first-pass-only output.

For non-61xxD SuperIO chips, second-round remains conditional (route/evidence-driven), not always mandatory.

## Operational contract (single-command closure)

After first generate, always inspect `<PROJECT>-section-matrix.json`:
- Voltage converged only if route includes `+SUPERIO_V2_BIOS_PROBE_ALIAS`.
- Temperature converged only if route includes `+SUPERIO_TEMP_V2_BIOS_PROBE_ALIAS`.

If either is missing on a board that requires v2:
1. Deploy `<PROJECT>-pre.ini` to target runtime INI location.
2. Reload SUSI runtime/driver on target.
3. Re-run target full probe.
4. Pull latest probe back to CASES project directory.
5. Re-run generate/all.
6. Re-check section matrix for v2 evidence fields (`*_v2_enabled`, kept/dropped counters).

Do not mark run complete while only v1 seed output exists.

## Stop condition

After one full re-probe loop, if v2 still absent, report explicit blocker category:
- BIOS label evidence missing,
- probe has no `[OK]` channels,
- or remote deploy/reload permission not granted.

Use a pending status instead of claiming completion:
- `PENDING_APPROVAL_FOR_V2_CONVERGENCE_LOOP`
- or blocker-specific pending status with exact missing evidence.
