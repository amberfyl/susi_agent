# Machine-B HWM.Temperature end-to-end runbook

This reference records the reusable workflow for a Temperature-only Machine-B validation. It is intentionally separate from the project-specific report and timestamps.

## Artifact ownership

- Generator: `build_machineB_section_configs.py`
- Temperature JSON: `<PROJECT>_temperature.json`
- Temperature split INI: `<PROJECT>_HWM.Temperature.ini`
- Runner: `targetB_task/machineB_validation/run_hwm_temperature_validation.ps1`
- Shared helper: `targetB_task/machineB_validation/common_susi.ps1`

The JSON builder is the authoritative producer. Do not hand-edit the JSON as the normal workflow; regenerate it from the section matrix and source INI.

## JSON generation

Run with the project-scoped matrix and output directory:

```text
.venv/bin/python build_machineB_section_configs.py \
  --matrix CASES/<PROJECT>/<PROJECT>-section-matrix.json \
  --output-dir CASES/<PROJECT>
```

Verify the generated Temperature item carries both namespaces:

```json
{
  "key": "TCPU",
  "api_id": "0x00020000",
  "tuple_channel": "0x80000000"
}
```

`api_id` is for `SusiBoardGetValue`; `tuple_channel` is the encoded INI/configuration channel. Never copy the tuple channel into `api_id`.

## Runner skeleton boundary

The runner skeleton is the PowerShell entrypoint and orchestration layer:

```text
targetB_task/machineB_validation/run_hwm_temperature_validation.ps1
```

Its responsibilities are: load JSON, validate the paired INI/hash, initialize SUSI, read configured temperature API IDs repeatedly, collect status-code evidence, build the layered report, and derive SW/DQA verdicts. `common_susi.ps1` owns shared initialization, sample collection, and status normalization.

The runner does not own API-ID mapping or JSON production; those belong to `build_machineB_section_configs.py` and the Python generator.

## Remote execution order

For a real target run, make the stages visible and ordered:

1. Back up `C:\Windows\SUSI\<PROJECT>.ini`.
2. Deploy the paired Temperature INI.
3. Reload the SUSI4 driver/service with the approved reload script.
4. Invoke the runner with explicit `-ConfigPath` and `-IniPath`.
5. Pull the newly timestamped report and inspect `api_calls`/layer verdicts.
6. Restore the original runtime INI in cleanup.
7. Reload again after restore and verify both restored hash and final device status.

Do not treat `SusiLibInitialize/SusiLibUninitialize` inside the runner as an OS driver reload.

## Diagnosis rule

If every temperature sample returns `0xFFFFFCFF` (`SUSI_STATUS_UNSUPPORTED`), first verify the API namespace and the runner's actual `-ConfigPath` before changing IO-port/options. A tuple/API namespace mismatch can make a valid INI appear unsupported.

After a mapping fix, sync the corrected JSON, verify the critical `api_id` on the target, run one fresh targeted validation, and cite only the new report as the current result. Keep the earlier report as root-cause evidence.

## Verdict interpretation

- `PASS_SW` means L1-L4 passed and must produce exit code 0.
- `FAIL_SW` means an L1-L4 failure and must produce non-zero exit code.
- Fixture/reboot-dependent uncertainty belongs in `result`/`dqa_verdict`; it must not override a passing software/API verdict.
- A successful readback with no stimulus may be `CONDITIONAL` + `PASS_SW` + `PENDING_DQA`.
