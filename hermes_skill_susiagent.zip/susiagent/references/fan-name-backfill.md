# Fan display-name backfill (BIOS vision -> hints JSON -> INI)

When
- `HWM.Fan` / `HWM.Fan.Control` names look generic (`CPU Fan`, `System Fan`, `OEM Fan n`) but BIOS pages clearly show board-specific labels.
- Existing `<PROJECT>-bios-image-cache.json` is voltage-focused and does not contain fan wording.

Policy
1) Keep topology/channel decisions independent (probe + pairing evidence).
2) Backfill `disp_name` from BIOS-visible fan labels.
3) Make naming deterministic via project hints file, not manual post-edit.
4) For NON-EC/SIO boards where probe `HWM_FAN_*` is unsupported, BIOS fan hints are allowed to supply fan key/count seed (`FCPU`/`FSYS`/`FOEMn`) so `HWM.Fan` does not collapse to empty solely because probe lacks fan items.
5) Even with BIOS-seeded fan keys, pairing topology from circuit evidence is preferred (`FAN_ONE_TO_ONE_CONFIRMED` / `FAN_ONE_TO_MANY_CONFIRMED`). If pairing artifact is missing in NON-EC/SIO, generator may fallback to deterministic one-to-one control mapping from resolved `HWM.Fan` channels and mark matrix status as fallback.

Name source priority
1. `<PROJECT>-fan-name-hints.json` (explicit project override)
2. BIOS cache extraction (`bios*.png` analysis text)
3. Key fallback alias (`FCPU->CPU Fan`, `FSYS->System Fan`, `FOEMn->OEM Fan n`)

Recommended hints file
Path:
- `CASES/<PROJECT>/<PROJECT>-fan-name-hints.json`

Shape:
```json
{
  "by_key": {
    "FCPU": "COM Module FAN",
    "FSYS": "Carrier Board FAN"
  },
  "by_idx": {
    "0": "COM Module FAN",
    "1": "Carrier Board FAN"
  },
  "source": "bios_vision_analyze"
}
```

Notes
- Keep `by_key` uppercase keys.
- `by_idx` keys are stringified integers; parser should accept base-10 and `0x` forms.
- If `by_key` and `by_idx` disagree, `by_key` wins for that key.

Vision prompt pattern (fan-focused)
- "只擷取和風扇有關的可見文字標籤。若看不到風扇項目，回覆 NONE。不要猜測。"

Example mappings from BIOS wording
- `Smart Fan - COM Module` / `COM Module FAN` -> `FCPU`
- `Smart Fan - Carrier Board` / `Carrier Board FAN` -> `FSYS`

Verification checklist
1) Run `susi_gen.py --stage all` with probe.
2) Confirm both sections exist in `<PROJECT>-pre.ini`.
3) Confirm `[HWM.Fan]` and `[HWM.Fan.Control]` use the same resolved display name per key.
4) Confirm no manual edit was required after generation.
