# Machine-B fan validation minimal mode (read robustness + control delta)

When user intent is "just verify fan read stability and real RPM response after control set", avoid over-layered reporting and run the lean acceptance path.

## Trigger
- User says too many validation layers are unnecessary.
- User asks for old-style behavior: read has value, repeat many times for tolerance, set control then RPM must change.

## Minimal acceptance gates
1) Read robustness gate
- Sample each target fan key repeatedly (default N=30).
- Require non-null and plausible RPM values.
- Pass criteria: success_rate >= policy threshold (example 0.95) and RPM within plausible bounds.

2) Control effectiveness gate
- Capture baseline RPM.
- Apply manual PWM sequence (example 30 -> 60 -> 90), with settle time between steps.
- Pass criteria: observed RPM delta against baseline (or step-to-step) reaches minimum threshold (example >= 200 RPM) on required keys.

3) Recovery gate (safety)
- Restore original control config in finally block.
- Read back once to confirm restoration.

## Reporting contract (lean)
Use concise output fields only:
- result: PASS | FAIL | CONDITIONAL
- reason: one-line cause
- metrics: sample_count, success_rate, baseline_rpm, pwm_steps, rpm_deltas, restore_status

Do not force users to consume L1~L6 labels when they only need operational confidence.
Keep layered internals optional for debug builds, not required for user-facing pass/fail.

## Mapping note for legacy scripts
Legacy AIMB fan scripts often use:
- configuration
- function_read
- function_control
- value/mapping (optional when BIOS reference exists)
- recovery

Treat these as operational checks, not strict one-field-per-layer semantics.
