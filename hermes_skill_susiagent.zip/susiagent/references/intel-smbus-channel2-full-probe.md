# Intel SMBus Channel2+ mapping from full probe

When CPU platform is Intel, SMBus generation keeps Channel1 fixed and derives Channel2+ from the full board probe report.

Rules:
1) Parse full probe lines matching `SMBUS_OEMn ... EXISTS` (case-insensitive).
2) Map bus index to INI channel key:
   - `OEM0 -> Channel2`
   - `OEM1 -> Channel3`
   - `OEM2 -> Channel4`
   - `OEM3 -> Channel5`
3) For each mapped channel, fill values as:
   - `HWID = ProductChip.hardware_id` (DB key: `(product_name, chip_name)`)
   - `channel = 0x80000000 + n` (hex, uppercase)
   - `io_port = 0`
   - `option = 0xA0000000`
4) Keep Channel1 fixed as:
   - `0x00000001,0,0,0xA0000000,`
5) If no OEM bus is confirmed `EXISTS`, leave Channel2+ empty. Do not guess.

Verification checklist:
- Full probe contains at least one `SMBUS_OEMn ... EXISTS` line.
- Generated `<PROJECT>_SMBus.ini` has matching Channel2+ rows.
- `section-matrix` SMBus reason mentions Intel fixed Channel1 plus full-probe OEM mapping.
