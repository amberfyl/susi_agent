# Machine-B SW/DQA verdict split (Phase1)

Purpose
- Decouple CI/software gating from fixture- or reboot-dependent DQA checks.
- Preserve section-level validation detail while making CI pass/fail deterministic.

Verdict model
- `sw_verdict`: `PASS_SW | FAIL_SW`
- `dqa_verdict`: `N_A_DQA | PENDING_DQA | PASS_DQA | FAIL_DQA`
- `ci_exit_code`: `FAIL_SW -> 1`, `PASS_SW -> 0`

Layer mapping contract
- SW gate uses only L1~L4:
  - `L1_configuration`
  - `L2_capability`
  - `L3_api`
  - `L4_readback`
- DQA gate uses L5~L6:
  - `L5_functional`
  - `L6_recovery`

Interpretation
- Any `FAIL*` in L1~L4 => `FAIL_SW` and non-zero exit.
- No `FAIL*` in L1~L4 => `PASS_SW` and zero exit, even if L5/L6 are `CONDITIONAL`/`PENDING` due to fixture policy.
- DQA verdict is informational for bring-up/coverage tracking and should not block CI when `sw_verdict=PASS_SW`.

Implementation landing (Phase1)
- Shared policy helper in `targetB_task/machineB_validation/common_susi.ps1`:
  - `Apply-VerdictPolicy`
  - `Resolve-DqaVerdictFromLayers`
- Section runners should call shared policy before final output/exit:
  - `run_hwm_fan_validation.ps1`
  - `run_hwm_fan_control_validation_section.ps1`
  - `run_smbus_validation.ps1`
  - `run_wdt_validation.ps1`
- Machine-B config builder should emit `verdict_policy` in generated JSON:
  - `<project>_fan.json`
  - `<project>_fancontrol.json`
  - `<project>_smbus.json`
  - `<project>_wdt.json`

Notes
- Keep existing detailed `result`/`validation_layers` fields; verdict split is additive.
- This model is designed for SW-vs-DQA responsibility separation, especially when fixture presence is conditional during bring-up.
