# Machine-B per-section JSON + split fan runners

Context
- User goal: `/susiagent <MODEL>` should be one-pass end-to-end.
- Machine A already generates split section INIs; next required link is automatic JSON generation per section for the current model/platform.
- Existing target-B validation worked, but policy + execution were mixed in a single AIMB-specific flow.

Durable pattern
1) Keep `INI` as tuple source of truth.
2) Build per-section JSON from `<project>-section-matrix.json` + section INIs.
3) On machine B, run per-section PowerShell entrypoints that load JSON and infer what to test.

Current fan first-stage implementation
- Builder:
  - `build_machineB_section_configs.py`
  - Inputs: `--matrix <project>-section-matrix.json`
  - Outputs (when generated):
    - `<project>_fan.json`
    - `<project>_fancontrol.json`
- Verified command shape:
  - `python3 /home/company2/AIagent_susi/build_machineB_section_configs.py --matrix /home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>-section-matrix.json --output-dir /home/company2/AIagent_susi/CASES/<PROJECT>`

Machine-B split runner entrypoints
- `targetB_task/machineB_validation/hwm.fan_verify.ps1`
  - Wraps `run_hwm_fan_validation.ps1`
  - Auto-resolves `<model>_fan.json` from `-JsonDir` unless `-ConfigPath` provided
- `targetB_task/machineB_validation/hwm.fan.control.ps1`
  - Wraps `run_hwm_fan_control_validation.ps1`
  - Auto-resolves `<model>_fancontrol.json` + `<model>_fan.json` unless explicit paths provided

Remote execution checklist (SSH to target B)
1) Ensure all scripts in one directory (example: `C:/Users/susiaa/Desktop/verify`) and include the latest `common_susi.ps1` from repo.
2) Copy section JSONs (`<project>_fan.json`, `<project>_fancontrol.json`) to the same directory.
3) Prefer PowerShell invocation form:
   - `powershell -NoProfile -Command "Set-ExecutionPolicy -Scope Process Bypass -Force; & '<entrypoint.ps1>' ..."`
   - This avoids script-policy failures when helper scripts are dot-sourced.
4) For SHA-256 gate, pass the exact INI file paired with JSON `source_ini` metadata. If target uses another INI copy, expect hash-mismatch `FAIL_CONFIG`.
5) If using section-only INI names like `<project>_HWM.Fan.ini`, pass explicit `-ConfigPath` because model inference from INI stem can produce a wrong JSON filename.

Observed pitfalls and fixes
- Pitfall: `Resolve-SectionIniPath not recognized` on target.
  - Cause: stale `common_susi.ps1` missing newer helper functions.
  - Fix: overwrite target copy with repo version before running tests.
- Pitfall: runner exits `FAIL_CONFIG` with INI SHA mismatch.
  - Cause: JSON was built from one INI file while runtime used another (`C:/Windows/SUSI/<model>.ini`).
  - Fix: either run against the paired INI used during JSON build, or regenerate JSON from the runtime INI artifact.
- Pitfall: `hwm.fan_verify.ps1` infers `<model>` incorrectly from section-INI filename.
  - Cause: stem `AIMB-289_HWM.Fan` leads to lookup `AIMB-289_HWM.Fan_fan.json`.
  - Fix: pass explicit `-ConfigPath` (or improve wrapper inference logic).

Blocking/quality gates
- If matrix section status is `SKIPPED_EMPTY_SECTION`, `PENDING_*`, or `INVALID_SECTION`, do not claim runnable JSON for that section.
- Fail build on missing source INI, hash mismatch, section/key mismatch, or tuple arity mismatch.
- Keep `source_ini.file` for B runtime path resolution (`-IniDir`); `source_ini.path` is provenance only.

Integration recommendation for `/susiagent`
- After `susi_gen.py` generate/all emits `<project>-section-matrix.json`, run builder as post-stage.
- Report section JSON generation separately from target-B runtime capability results.
- Expand to other sections only after each section has fixed API mapping + safety policy + dedicated runner.