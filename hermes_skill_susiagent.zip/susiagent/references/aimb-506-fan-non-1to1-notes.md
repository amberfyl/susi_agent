# AIMB-506 FAN mapping note: non-one-to-one case

Purpose
- Concrete example where FANIN channel count != FAN connector/FANOUT count.
- Prevent wrong assumption that `[HWM.Fan]` and `[HWM.Fan.Control]` must always share identical channel_id mapping.

Observed files
- `circuit_AIMB-506fan1.pdf` (SIO/function side)
- `circuit_AIMB-506fan2.pdf` (fan-control/connector side)

Confirmed pattern
1. SIO-side FANIN/FANOUT labels expose core channels (CPU + SYS main channels).
2. Fan-control pages expose additional connectors (SYS3/SYS4), but these may be downstream branches sharing upstream PWM/TACH sources.
3. Therefore, connector count can exceed confirmed FANIN channel count.

Extraction guidance
1. Build FANIN map first from traced `*_FAN_SPEED`/`*TACH*` -> `*FANIN*` labels.
2. Build FANOUT/control map from `*_PWM` / fan-control IC input nets and connector outputs.
3. Check whether extra SYS connectors are independent channels or branch/merge paths.
4. If not independent, do not auto-create new FANIN channels.

INI impact
- One-to-one only: synchronized `channel_id` mapping for `[HWM.Fan]` and `[HWM.Fan.Control]`.
- Non-one-to-one: section key names may still align, but channel_id mapping can differ and must follow each section’s own traced evidence.

Status suggestions
- `FAN_ONE_TO_ONE_CONFIRMED`
- `FAN_PAIRING_NEEDS_FANCONTROL_EVIDENCE`
- `FAN_PAIRING_AMBIGUOUS`
