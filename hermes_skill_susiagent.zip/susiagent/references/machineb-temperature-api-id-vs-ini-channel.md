# Machine-B HWM.Temperature: INI channel vs public API ID

## Failure signature
A temperature runner returns `0xFFFFFCFF` (`SUSI_STATUS_UNSUPPORTED`) for every sample, while the full probe reports `HWM_TEMP_CPU` as `[OK]`.

## Root cause
HWM.Temperature INI tuples and `SusiBoardGetValue()` do not use the same ID namespace. For example:

```ini
TCPU=0x30313640,0x80000000,0,0x80000001,0,CPU Temperature
```

The tuple's `0x80000000` is the encoded configuration channel. The public Board API temperature ID is `0x00020000` for TCPU. The full probe convention is `0x00020000 + temperature_index`.

Do not build JSON `api_id` from tuple field 2. Preserve that field separately as `tuple_channel` and derive/validate the API ID from the canonical temperature key and SUSI namespace:

- `TCPU` -> `0x00020000`
- `TCHIPSET` -> `0x00020001`
- `TSYS` -> `0x00020002`
- `TCPU2` -> `0x00020003`
- `TOEM0..TOEM5` -> `0x00020004..0x00020009`
- `TSYS2` -> `0x0002000A`
- `TGRAPHIC` -> `0x0002000B`

## Diagnostic sequence
1. Read the full-probe temperature block and record the successful public ID/value.
2. Read the generated JSON `channels.<key>.api_id` and the INI tuple's second field separately.
3. Inspect runner arguments/call path and verify the ID passed to `SusiBoardGetValue` equals the full-probe ID.
4. Check `SusiLibInitialize`/`Uninitialize` and driver reload separately; successful init does not prove the OS driver reload occurred.
5. Only after the ID namespace is correct, investigate tuple `io_port/options` or candidate fallback.

## Builder contract
`build_machineB_section_configs.py` must emit both `tuple_channel` and canonical `api_id`, with an explicit source marker such as `SUSI_HWM_TEMPERATURE_NAMESPACE`. Unknown temperature keys should fail generation rather than silently copying a tuple field into an API ID.

## Verification
After regeneration, require the TCPU JSON to contain:

```json
"tuple_channel": "0x80000000",
"api_id": "0x00020000"
```

Then perform one targeted remote run with the corrected JSON. Do not begin broad `(io_port, options)` fallback iteration until the public API ID matches the known-good full probe ID.

For a remote rerun, use this evidence order:

1. Upload the corrected JSON and read it back on the target; verify the critical `channels.TCPU.api_id` before running.
2. Backup the target runtime INI, deploy the paired Temperature INI, and record the deployed SHA-256.
3. Reload SUSI4 explicitly with the approved reload script; record before/disable/enable states.
4. Run the Temperature runner with explicit `-ConfigPath`, `-IniPath`, and output directory. Pull the newly timestamped report; never reuse the prior failure report as the current result.
5. Verify the report has `api_id=0x00020000`, `status_code=0x00000000`, and success rate meeting policy. For a read-only run, `CONDITIONAL` with `PASS_SW` is expected when functional thermal stimulus is not applied.
6. Restore the original runtime INI and reload again. Verify the final INI hash and SUSI4 status (`OK`, `CM_PROB_NONE`) before closing the run.

This sequence distinguishes a stale/wrong JSON artifact from a genuine tuple/options or driver problem and prevents repeated blind remote tests.
