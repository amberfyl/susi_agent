# GPIO auto-trace contract (code -> AI -> code)

When `/susiagent <PROJECT>` reaches generate stage and `<PROJECT>-gpio-trace.json` is missing, treat that as an automation step, not a user task.

## Required flow
1. Code detects missing GPIO trace artifact.
2. Render each required `circuit*.pdf` page to a persistent project raster named from the source, e.g. `circuit_<board>_page1.png`; do not leave the only analyzed raster under `/tmp`.
3. Code triggers AI image/PDF analysis (`vision_analyze` path) against that persistent raster.
4. Code writes normalized `<PROJECT>-gpio-trace.json`; `meta.images_analyzed` must name files that actually exist in the project directory.
5. Code consumes JSON and renders `[GPIO]` lines into split/pre INI.
6. Section matrix records source/status/reason (`gpio_trace_source`, `gpio_trace_status`, `gpio_trace_confirmed_count`, `gpio_trace_reason`) and must make DB-row use distinguishable from trace use.
7. Before reporting completion, verify the raster exists, the trace source is current, and matrix route is `GPIO_TRACE`; regenerate the Machine-B GPIO JSON after any GPIO INI regeneration.

## Evidence portability
- The project must retain the exact rendered image used for circuit interpretation so a reviewer can inspect the same pixels later.
- Temporary rasters may be used during experimentation, but completion requires copying the accepted raster into the project and verifying its checksum.
- A trace JSON that names a missing raster is incomplete evidence even when the resulting INI is technically correct.
- Explain mixed provenance explicitly: ProductChip HWID and stable protocol defaults may come from DB/code, while GPIO keys and group/bit topology come from circuit trace. A visible `query_key` alone does not mean DB GPIO channel rows were used; cite `gpio_group_pins_total`, `route`, and `gpio_trace_*` fields.

## Contract boundary
- AI responsibility: evidence-based trace interpretation + structured JSON fields.
- Python responsibility: normalization, dedup, numeric coercion (group/bit), ambiguity handling, rendering, and final matrix status.
- Never ask user to hand-craft trace JSON in normal pipeline flow.

## Scope lock
- Analyze only `bios*` / `circuit*` assets unless user explicitly broadens scope.
- If only ambiguous evidence exists, keep section pending/ambiguous and report blocker; no guessed mapping.

## Minimal JSON shape (ingest)
```json
{
  "topology_status": "GPIO_TRACE_CONFIRMED|GPIO_TRACE_AMBIGUOUS",
  "items": [
    {
      "report_name": "GPIO00",
      "signal": "EC_P1_GPIO0",
      "function_label": "GPIOB0",
      "group": 0,
      "bit": 0,
      "package_pin": "F1",
      "status": "CONFIRMED|AMBIGUOUS",
      "evidence": "wire/path evidence",
      "name": ""
    }
  ]
}
```
