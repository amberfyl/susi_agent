# Non-EC/SIO no-request-form feasibility mode

When user says there is no request form and directly provides `chip_name` (for example `NCT6126D`), `/susiagent` should still proceed and report what sections are currently completable from existing artifacts.

## Trigger
- User explicitly states no request form (`沒有request form`) and supplies project + chip override.
- User asks: "from current data, which sections can be completed?"

## Procedure
1. Resolve canonical project name under `CASES/` (case-insensitive).
2. Use explicit `--chip-name <DB chip_name>` in generate/all run (do not rely on request-form derived chip inference).
3. If full split run is blocked, run per-section `--stage generate --sections <SECTION>` probes and summarize status buckets.
4. Treat `AIMB/ASMB + NCT61xxD` as NON-EC/SIO route unless evidence says otherwise.

## Status semantics to preserve
- `HWM.Fan` may be `GENERATED` from BIOS fan-name hints (seed keys/count) even when probe fan rows are unsupported.
- `HWM.Fan.Control` must remain pending (`FAN_PAIRING_NEEDS_FANCONTROL_EVIDENCE` / ambiguous) until circuit pairing evidence exists.
- Do not force fan-control channels from DB defaults or naming proximity.

## Reporting contract
- Return concise section feasibility summary with absolute paths for generated artifacts.
- For pending/blocked sections, include exact matrix status + reason string (no hand-wavy wording).
