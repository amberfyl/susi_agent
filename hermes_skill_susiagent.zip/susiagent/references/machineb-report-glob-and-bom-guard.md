# Machine-B report parsing guard: filename glob overlap + UTF-8 BOM

When summarizing latest Machine-B validation results from CASES artifacts, avoid two recurring parser mistakes:

1) Filename glob overlap (`hwm_fan_*.json` vs `hwm_fan_control_*.json`)
- Pitfall: naive glob `hwm_fan_*.json` also matches `hwm_fan_control_*.json`.
- Effect: HWM.Fan summary can accidentally read fan-control report and show wrong verdict/result.
- Guard options:
  - Prefer strict regex on basename:
    - `^hwm_fan_\d{8}_\d{6}\.json$`
    - `^hwm_fan_control_\d{8}_\d{6}\.json$`
  - Or keep glob + explicit exclusion:
    - `glob('hwm_fan_*.json')` + exclude entries containing `_control_`.

2) Windows/PowerShell JSON UTF-8 BOM
- Pitfall: report JSON may start with BOM; plain `encoding='utf-8'` can raise:
  - `Unexpected UTF-8 BOM (decode using utf-8-sig)`
- Guard:
  - Read report JSON with `encoding='utf-8-sig'`.

Recommended extraction mapping
- HWM.Fan: `hwm_fan_<ts>.json` (exclude `_control_`)
- HWM.Fan.Control: `hwm_fan_control_<ts>.json`
- SMBus: `smbus_<ts>.json`
- WDT: `wdt_<ts>.json`

Outcome expectation
- Each section’s latest report is selected from its own filename family.
- Verdict summary (`result`, `sw_verdict`, `dqa_verdict`, `ci_exit_code`) is not cross-contaminated across sections.
