# FAN / FAN control mapping playbook (cross-project)

Purpose
- Standardize how to extract fan tach/control relationships from circuit artifacts for SUSI-related analysis.

What to extract (minimum contract)
- Per fan connector:
  - connector_name (e.g., CPU FAN1, SYS FAN3)
  - tach_net (FANIN/TACH feedback net)
  - pwm_output_net at connector pin 4 (fan control output)
  - pwm_input_source_net(s) feeding the buffer/controller (PWMIN side)

Core rule: fan mapping is often NOT one-to-one
- TACH is commonly per-connector (independent feedback channels).
- PWM is commonly grouped/shared (one source controls multiple connectors).
- Do not force FANIN index == PWM index.

Evidence policy
- Use only visible, traceable schematic evidence.
- Prefer connector-side net labels + explicit fan block wiring.
- Treat EC pinmux tables (TACHx/PWMx capability lists) as capability hints; finalize mapping from actual routed nets.
- If crops are ambiguous, cross-check full-page PDF/vector source before confirming.

AIMB-593 confirmed example (reference pattern)
- CPU FAN1: PWM0 + TACH0
- SYS FAN1/2: shared PWM1 with independent TACH1/TACH2
- SYS FAN3/4: shared PWM2 with independent TACH4/TACH5
- SYS FAN5: PWM3 + TACH6

Common pitfall
- Misclassifying as one-to-one by reading only EC function naming (TACHx/PWMx) without connector wiring context.
