# EC_P* GPIO cross-reference tag interpretation

Session lesson
- On some schematics, tokens like `<49>` beside `EC_P*_GPIO*` are net reference identifiers, not page numbers.
- Do not hard-stop mapping just because `<n>` exists in net text.

Mapping rule
1) Prefer direct same-sheet electrical evidence:
   - `EC_P*_GPIOn` net label
   - continuous wire path
   - chip pin endpoint
   - pin function label containing `GPIOxy`
2) When (1) is present, mapping is CONFIRMED and may emit:
   - INI key `GPIOxy`
   - group=`x`, bit=`y`
3) Mark `AMBIGUOUS` only if the signal is genuinely page-jump-only and same-sheet endpoint/function-label proof is absent.

Worked example
- `EC_P1_GPIO2 -> GPIO36` => INI row uses trailing `,3,6`.

Guardrail
- Never downgrade a same-sheet confirmed wire mapping to ambiguous solely due to `<n>` tokens.