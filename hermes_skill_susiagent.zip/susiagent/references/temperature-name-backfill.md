# HWM Temperature Name Backfill

Use this when generated `[HWM.Temperature]` rows have empty or fallback Name fields and BIOS screenshots may contain sensor labels.

## Evidence workflow

1. Scope visual analysis to `bios*.png` first; do not use unrelated images unless explicitly requested.
2. Run a dedicated high-reasoning `vision_analyze` pass, not only the voltage-focused cache pass. Ask for temperature sensor names and values, and explicitly prohibit guessing.
3. Prefer real-time monitor labels over threshold/configuration labels. For example, `CPU Temperature` in `PC Health Status` is a sensor name; `CPU Shutdown Temperature` is a safety threshold, not a sensor row.
4. If the BIOS image clearly shows `CPU Temperature` and the probe has `HWM_TEMP_CPU` in `[OK]`, map it to `TCPU`. Keep unsupported probe temperature items out of the generated section.
5. Persist normalized project hints as `<PROJECT>-temperature-name-hints.json`, for example:

```json
{
  "by_key": { "TCPU": "CPU Temperature" },
  "source": {
    "image": "bios3.png",
    "evidence": "BIOS PC Health Status visibly shows CPU Temperature"
  }
}
```

6. The generator must apply these hints after probe/DB channel resolution so names change without changing HWID, channel ID, I/O port, options, or offset. Regenerate both the split section INI and combined `<PROJECT>-pre.ini`.
7. Re-read both outputs and verify each evidence-supported temperature key has the expected non-empty Name field.

## Pitfalls

- A voltage cache marked `DONE_VISION_ANALYZE` does not prove that temperature names were analyzed; voltage and fan/temperature extraction are separate targeted passes.
- Do not use a generic key fallback (`CPU Temp`, `System Temp`) when a BIOS label is visible.
- Do not treat `CPU Shutdown Temperature` as proof of a `TCPU` sensor display name unless an actual monitor row is also visible.
- Preserve the probe-first rule for item existence and channel mapping; BIOS vision supplies the display alias only.
