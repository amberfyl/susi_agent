# Vision cache vs AI analysis boundary

When implementing BIOS hint extraction inside `susi_gen.py`, keep this boundary explicit:

## Two required halves

1. Producer (AI step)
- Scope: `bios*.png|jpg|jpeg` only (unless caller expands scope).
- For each pending/missing cache item (`analysis_status != DONE_VISION_ANALYZE` or empty `analysis_text`), run `vision_analyze` with task-specific prompt (temperature/fan names).
- Persist results back to `<PROJECT>-bios-image-cache.json` with:
  - `analysis_status = DONE_VISION_ANALYZE`
  - `analysis_text`
  - normalized hints/evidence fields when applicable.

2. Consumer (deterministic step)
- Parse cache text/hints into:
  - `<PROJECT>-temperature-name-hints.json`
  - `<PROJECT>-fan-name-hints.json`
- Merge existing manual hints (do not overwrite explicit entries).
- Apply hints during generate while preserving probe/DB channel decisions.

## Completion criteria (must all pass)

- Producer executed for pending scoped BIOS images.
- Cache re-read verifies those items are `DONE_VISION_ANALYZE` and have non-empty `analysis_text`.
- Hints artifacts are regenerated/merged and re-read.
- Regenerated INIs show non-fallback names when clear BIOS labels exist.

## Anti-pattern to avoid

- Claiming "auto extraction in pipeline" when code only regex-parses old cache content and never triggers new AI analysis for pending BIOS images.
