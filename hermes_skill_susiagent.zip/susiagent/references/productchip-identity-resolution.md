# ProductChip identity resolution

Use this when the user supplies an EC/SIO marketing or configuration identity but the generator cannot resolve `chip_name`.

1. Confirm the part number from scoped schematic evidence (`circuit*.png`, and the schematic PDF only when the PNG is ambiguous). Do not select a DB row from board proximity or a typical-board assumption.
2. Query `ProductChip` with the fixed key `(product_name, chip_name)` policy. Treat the table columns separately:
   - `chip_name`: generator/query key and the value passed to `susi_gen.py --chip-name`.
   - `config_chip`: human/configuration identity that may match the schematic wording but is not necessarily a valid lookup key.
   - `hardware_id`: the DB HWID used for rendering.
3. If the schematic says `RDC_EIO-IS200` but the DB row is `chip_name=EIO-201`, `config_chip=Advantech EIO_IS200`, use `EIO-201` as the resolved generator key and record the mapping in verification output.
4. Re-run the complete pipeline after resolving the key; a successful `generate` with the wrong key can still leave sections as `NO_SUCH_PRODUCT_CHIP`.
5. Verify the section matrix query key, generated section statuses, and output paths all use the canonical project token and resolved DB key.

Common failure mode: passing `EIO-IS200` because it is the visible/config label when the database stores only `EIO-201` and `EIO-211` as valid `chip_name` values. The resulting run may produce the top-level INI but silently omit EC-backed sections.