# Post-INI deterministic Machine-B validation orchestrator

## Scope boundary

When `/susiagent` has already produced the project INI artifacts, do not reopen PDF/probe/vision/DB/INI-generation design. Treat these as authoritative inputs:

- `CASES/<project>/<project>-pre.ini`
- `CASES/<project>/<project>-section-matrix.json`
- generated split section INIs referenced by the matrix

The post-INI workflow starts at Machine-B validation-config generation and ends at report aggregation.

## Public `/susiagent` mode contract

The user-facing invocation has exactly two top-level modes:

```text
/susiagent <PROJECT>
    -> preserve the existing probe/vision/generation workflow, including required generation-owned v2 convergence, build Machine-B section JSON, then stop before P6-P12 full validation

/susiagent <PROJECT> --all --host <MACHINE_B_HOST> [--user <USER>]
    -> complete generation, then execute P5-P12 under safe defaults
```

Rules:

- `--all` belongs to the susiagent skill, not to `susi_gen.py`. Translate it into `susi_gen.py --stage all` for generation and `run_machineB_full_validation.py --execute` for the post-INI phase.
- Without `--all`, preserve existing probe acquisition and generation-owned convergence behavior, but do not invoke `run_machineB_full_validation.py --execute` or enter the 14-section P6-P12 full-validation lifecycle.
- With `--all`, require a positively identified host and use `susiaa` as the default user when no user override is supplied. Never infer the host from stale conversation context or an unrelated SSH alias.
- `--all` is current-turn authorization for staging, backup, one full-INI deployment, one validation reload, safe-default runners, report retrieval, rollback, and one recovery reload. It does not authorize control, fixture, functional, SetConfig, stimulus, or write opt-ins.
- Run only `GENERATED`/runnable sections. `SKIPPED_EMPTY_SECTION`, `PENDING_*`, and blocked generation states remain explicit results rather than fabricated runner coverage.
- A unique run ID is mandatory. The fixed handoff is:

```text
.venv/bin/python run_machineB_full_validation.py \
  --project <PROJECT> \
  --repo-root /home/company2/AIagent_susi \
  --run-id <UNIQUE_RUN_ID> \
  --execute --host <MACHINE_B_HOST> --user <USER>
```

Completion means the lifecycle and recovery finished and the manifest/reports/summaries were emitted; it does not mean every section verdict is PASS.

## Responsibility split

- Skill/AI: interpret user intent, explain failures, decide whether an exceptional isolation/convergence run is warranted.
- `build_machineB_section_configs.py`: deterministically generate section JSON from the matrix and split INIs.
- New full-validation Python orchestrator: deterministically preflight, create an execution manifest, stage files, deploy the full INI once, invoke the existing target reload BAT once, run section runners sequentially, retrieve fresh reports, and aggregate verdicts.
- PowerShell section runners: perform SUSI API operations and emit timestamped structured JSON reports.

Do not rely on model memory for filenames, runner pairing, ordering, safety gates, or stop conditions. Encode those in code and tests.

## Required implementation order

1. Define the post-INI input/output contract and canonical paths.
2. Add a fixed 14-section registry containing section name, config filename, runner, report prefix, execution tier, dependencies, and required safety switches.
3. Test registry completeness against every `GENERATED` matrix entry.
4. Implement local preflight and `--dry-run` execution-manifest generation without SSH or target side effects.
5. Integrate `build_machineB_section_configs.py` and validate generated configs.
6. Add remote staging and backup.
7. Copy `<project>-pre.ini` to `C:\Windows\SUSI\<project>.ini`; do not perform per-upload local/remote SHA-256 comparison. Treat SCP failure or missing destination as transfer failure, and validate the runtime filename/path separately.
8. Invoke the target-installed `C:\Users\susiaa\Desktop\reload driver\reload_susi4_driver.bat` exactly once on the normal path; verify exit code, log, and final PnP state.
9. Run each valid section runner in an independent PowerShell process against the same runtime INI.
10. Pull each newly generated report immediately, reject stale/missing reports, validate JSON, and produce an execution manifest plus summary.
11. Enforce safety/stop policy in code and tests.
12. Perform real target execution only after explicit current-turn approval.

## P1 contract implementation (landed)

The deterministic P1 boundary is implemented in:

- `run_machineB_full_validation.py`
- `tests/test_machineb_full_validation_contract.py`

Use `build_post_ini_contract(project=..., repo_root=..., run_id=...)` as the only path resolver for later phases. It is deliberately read-only: contract construction validates inputs and computes output/target paths but must not create `validation_runs/<run_id>` or contact Machine-B.

Stable schema IDs:

- contract: `machineb.post_ini_contract.v1`
- execution manifest: `machineb.execution_manifest.v1`
- validation summary: `machineb.validation_summary.v1`

The contract fixes these boundaries:

- authoritative inputs: full `<project>-pre.ini`, section matrix, all `GENERATED` split INIs, config directory, and Machine-B runner directory;
- local outputs: `manifest.json`, `reports/`, JSON/text summaries, and `reload.log` under `CASES/<project>/validation_runs/<run_id>/`;
- target paths: established `Desktop\verify\<project>` workspace, `C:\Windows\SUSI\<project>.ini`, and the target-installed reload BAT;
- machine-readable input failures through `ContractErrorCode` (invalid path token, missing case/full INI/matrix/runner directory, invalid matrix JSON/schema/project identity, duplicate section, and missing `GENERATED` split INI).

P1 verification must include the contract unit tests, full existing test discovery, Python compilation, and one real local contract build against a generated project. The real build must prove the expected generated-section count and that its computed output directory was not created. Do not introduce registry, SSH, deployment, reload, or runner execution into P1; those remain later phases.

## P2 fixed registry implementation (landed)

The deterministic P2 registry is implemented in:

- `run_machineB_full_validation.py`
- `tests/test_machineb_full_validation_registry.py`

Use an immutable `SECTION_REGISTRY` tuple plus a read-only `SECTION_REGISTRY_BY_NAME` lookup. Each `SectionRegistryEntry` must carry the section name, config-template name, runner name, report prefix, execution tier, difficulty rank/reason, script dependencies, section dependencies, opt-in switches, default switches, and any extra path arguments. Keep registry decisions in Python rather than deriving them at runtime from filenames or asking AI to choose a runner.

The fixed execution order starts with low-risk reads, but dependency-coupled sections take precedence over a globally monotonic tier order:

1. `HWM.CaseOpen`
2. `HWM.Current`
3. `HWM.Voltage`
4. `HWM.Temperature`
5. `I2C`
6. `SMBus`
7. `WDT`
8. `ThermalProtect`
9. `HWM.Fan`
10. `HWM.Fan.Control`
11. `VGA.Backlight`
12. `VGA.Brightness`
13. `GPIO`
14. `StorageArea`

Execution tiers are `SIMPLE_READ`, `GATED_READ`, `REVERSIBLE_WRITE`, and `DEPENDENT_CONTROL`. `HWM.Fan.Control` must immediately follow `HWM.Fan`, because it consumes the fan JSON/runtime INI and the preceding tachometer/RPM baseline. Dependency locality takes precedence over placing dependent control last; all control behavior remains explicitly gated and default-off.

All mutating, fixture, or control behavior must remain explicit opt-in and default off, including `EnableFixtureTest`, `EnableFunctionalTest`, `EnableWriteTest`, `EnableSetConfigTest`, `AllowControl`, and `EnableStimulus`. Every runner depends on `common_susi.ps1`; fan control additionally records its fan-section dependency and explicit `FanConfigPath`/`FanIniPath` arguments.

P2 tests must prove:

- exactly 14 unique entries and ranks;
- the fixed difficulty order and tier progression;
- exact config-template, runner, and report-prefix pairings;
- dependency closure, especially fan control → fan;
- opt-in switches are explicit and default disabled;
- every `GENERATED` matrix section resolves through `SECTION_REGISTRY_BY_NAME`.

Verification discipline: distinguish a landed implementation from a fully verified phase. Run focused registry tests first, then Python compilation, full regression discovery, a real project matrix-to-registry coverage check, and `git diff --check`. If the user denies a combined verification command, do not retry through another tool or command shape and do not infer that verification passed or failed. Report the focused tests already observed separately, leave the combined verification incomplete, and wait for a new explicit instruction.

## P3 registry-to-manifest implementation (landed)

The deterministic in-memory manifest builder is implemented in:

- `run_machineB_full_validation.py`: `build_execution_manifest(contract)`
- `tests/test_machineb_execution_manifest.py`

P3 converts the authoritative contract plus fixed registry into a JSON-serializable dry-run manifest without writing files or contacting Machine-B. Its rules are:

- include only matrix entries whose status is `GENERATED`;
- order planned sections by `SECTION_REGISTRY`, never by matrix row order;
- keep `HWM.Fan` immediately followed by `HWM.Fan.Control`;
- reject an unknown generated section with `GENERATED_SECTION_NOT_REGISTERED`;
- reject a generated section whose generated dependency is absent with `SECTION_DEPENDENCY_MISSING`;
- resolve config, runner, split-INI, report-prefix, tier, dependency, and extra-argument metadata deterministically;
- expose available opt-in switches but leave `enabled_switches` empty;
- keep every mutating/fixture/control opt-in disabled in `safety_policy`;
- do not create `validation_runs/<run_id>` during contract or in-memory manifest construction.

Use strict RED → GREEN verification: first observe focused tests fail because the manifest API is absent, then implement the minimum behavior and rerun the same tests. In status reports, explicitly explain that RED is the expected pre-implementation TDD checkpoint—not a remaining defect. After focused GREEN, run Python compilation, complete test discovery, one real project contract-to-manifest build, JSON serialization, fan-pair position checks, output-noncreation assertion, and `git diff --check` before marking P3 complete.

Terminology guard: before requesting approval for a “local test,” state that it means WSL-hosted Python/file-contract tests using the repository `.venv`; it does not require a Windows SUSI installation and does not run PowerShell, SUSI APIs, INI deployment, driver reload, SSH, WinRM, or Machine-B hardware. This avoids conflating development-host tests with target functional validation.

## P4 local preflight and dry-run implementation (landed)

`run_machineB_full_validation.py` provides a local-only dry-run path:

```text
.venv/bin/python run_machineB_full_validation.py \
  --project <PROJECT> \
  --repo-root /home/company2/AIagent_susi \
  --run-id <RUN_ID> \
  --dry-run
```

The implementation uses `run_local_preflight()` and `write_dry_run_manifest()` to validate every planned section config JSON, runner, and shared script dependency before atomically writing `CASES/<project>/validation_runs/<run_id>/manifest.json`. Config JSON must parse to an object. Fixed failures include `CONFIG_FILE_MISSING`, `CONFIG_INVALID_JSON`, `RUNNER_FILE_MISSING`, and `SCRIPT_DEPENDENCY_MISSING`.

The P4 preflight boundary remains strictly local: it does not invoke SSH/WinRM/SCP, PowerShell runners, INI deployment, driver reload, or SUSI APIs. A preflight failure must occur before the run output directory is created. Tests live in `tests/test_machineb_full_validation_dry_run.py`.

After P5 integration, `write_dry_run_manifest()` also materializes deterministic section configs under `CASES/<project>/config/` before preflight; therefore “dry-run writes only manifest” applies only to the `validation_runs/<run-id>/` directory, not to the project config directory.

## P5 section-config builder integration (landed)

P5 wires the existing builder into the orchestrator without duplicating mapping logic:

- `build_machineB_section_configs.py`: callable `build_section_configs(...)`
- `run_machineB_full_validation.py`: `prepare_section_configs(contract)`
- `tests/test_machineb_section_config_integration.py`

Required sequence:

1. Read the authoritative section matrix and referenced split INIs.
2. Build all `GENERATED` section config objects in memory before changing outputs.
3. If any source/config conversion fails, raise one build failure and leave the config set unrefreshed; the orchestrator maps this to stable `CONFIG_BUILD_FAILED` and does not create a run manifest.
4. Atomically write each successful config through a temporary file plus replace.
5. Only after the whole build validates, prune known stale config filenames for sections no longer `GENERATED`.
6. Require the builder’s generated-section set to exactly match `contract.inputs.generated_sections`.
7. Record builder identity, matrix/output paths, registry-ordered sections, config paths, count, and removed stale paths in `manifest.json` under `config_build`.
8. Run ordinary local preflight against those freshly generated configs.

The callable builder is the single owner of channel/API mapping and section JSON content. The orchestrator must not re-read BIOS/circuit images, query DB/probe data, infer channels, or implement a second copy of builder rules.

P5 remains local-only and does not authorize Machine-B access. Verification should include focused RED→GREEN tests, Python compilation, full test discovery, and a real project dry-run. For the real dry-run, prefer a new unique `run-id`; do not prepend `rm -rf` merely to reuse a friendly run name. If cleanup is genuinely required, state the exact absolute directory and its artifact scope before requesting deletion approval.

## P6 remote staging and backup implementation (landed)

P6 separates deterministic orchestration policy from the concrete transport:

- `run_machineB_full_validation.py`: `build_remote_staging_plan(...)`, `stage_remote_bundle(...)`, `RemoteStageErrorCode`, and manifest/schema integration;
- `machineb_transport.py`: `RemoteTransport` protocol plus `SshPowerShellTransport`;
- `tests/test_machineb_remote_staging.py`: fake-transport orchestration tests and fake-command-runner SSH/SCP tests.

The dry-run manifest must contain a `staging_plan`, but constructing or writing that plan must not instantiate a transport, run SSH/SCP, create remote directories, or contact Machine-B. The plan deterministically lists:

1. the canonical workspace, scripts, config, INI, run-output, and backup directories;
2. the runtime INI and per-run backup path;
3. the full pre-INI;
4. all generated split INIs in registry order;
5. all generated section configs in registry order;
6. unique runner scripts and shared dependencies.

Reject two different local files mapping to the same case-insensitive Windows destination with `PLAN_CONFLICT`. Identical repeated dependencies may be deduplicated.

`stage_remote_bundle(...)` must use dependency injection through the transport protocol and execute this order:

1. connectivity/identity probe;
2. canonical remote directory creation;
3. backup the existing runtime INI, if present;
4. verify source-runtime and backup SHA-256 equality;
5. upload each staged artifact and treat SCP failure as upload failure;
6. do **not** compare local and remote SHA-256 for ordinary uploaded artifacts;
7. return structured staging metadata for later manifest integration.

A missing original runtime INI is valid state, not a staging failure: record `original_exists=false`, no backup path/hash, and continue. A present runtime INI must be backed up and hash-verified before any artifact upload. P6 stages files only; it must not copy the staged full INI into `C:\Windows\SUSI`, reload the driver, or invoke section runners.

Use stable P6 failure codes rather than parsing exception text: `PLAN_CONFLICT`, `CONNECTION_FAILED`, `DIRECTORY_SETUP_FAILED`, `BACKUP_FAILED`, `UPLOAD_FAILED`, `HASH_READ_FAILED`, and `HASH_MISMATCH`.

The concrete SSH transport must:

- perform no network I/O in its constructor;
- use non-interactive OpenSSH (`BatchMode=yes`) with explicit connect/command timeouts;
- invoke PowerShell through UTF-16LE `-EncodedCommand`;
- escape PowerShell single-quoted literals;
- use legacy-compatible `scp -O` and convert Windows destinations to `/C:/...` form;
- parse explicit response markers instead of relying on incidental stdout;
- validate that remote SHA-256 responses are exactly 64 hexadecimal characters.

Verified Windows PowerShell compatibility rules:

- Use `New-Item -ItemType Directory -Path ... -Force` for remote workspace creation. Do not assume the target Windows PowerShell accepts `New-Item -LiteralPath`; a real Machine-B rejected that parameter before any backup/deployment/reload occurred.
- `Get-PnpDevice.Problem` may serialize as an enum name rather than a decimal integer. Normalize at least `CM_PROB_NONE -> 0` and `CM_PROB_DISABLED -> 22`, preserve `problem_raw`, and treat unknown names as not ready rather than throwing a parser exception.
- Apply the same normalization to validation activation readiness and rollback recovery readiness; otherwise a successful restore/reload can be falsely reported as rollback failure.

Test orchestration with a fake transport and the concrete SSH command construction with an injected fake command runner. Required P6 tests cover canonical plan contents, backup-before-upload ordering, missing-original handling, explicit absence of per-upload hash comparison, dry-run no-network behavior, SSH/SCP option/path construction, command failure, and malformed backup-hash responses.

Verification discipline remains layered: focused RED, focused GREEN, Python compilation, full regression discovery, `git diff --check`, then one real-project local dry-run using a fresh run ID. If the user denies the real-project verification command, do not retry it with a shorter command, alternate shell syntax, or another tool. Preserve the already observed focused/full-test results, mark only the denied verification incomplete, and wait for a new instruction. A denied local dry-run does not imply either success or failure, and it does not authorize target access.

## P7-P11 activation, execution, aggregation, rollback, and fake integration (landed)

The deterministic post-staging path is implemented in:

- `run_machineB_full_validation.py`: `activate_runtime_ini(...)`, `execute_validation_sections(...)`, `rollback_runtime_ini(...)`, `run_activated_validation(...)`, `write_validation_summary(...)`, and execute-mode CLI wiring;
- `machineb_transport.py`: runtime file/process/PnP/runner/report primitives plus `RemoteCommandResult`;
- `tests/test_machineb_full_validation_pipeline.py`, `tests/test_machineb_remote_staging.py`, and `tests/test_machineb_full_validation_dry_run.py`.

### P7 activation contract

1. Resolve exactly one staged artifact with `kind=full_ini`; never deploy a split INI on the normal path.
2. Confirm both the staged full INI and target-installed reload BAT exist.
3. Close `SusiDemo4` before runtime activation so an open handle cannot invalidate PnP reload behavior.
4. Copy the staged full INI once to `C:\Windows\SUSI\<project>.ini`.
5. Invoke the reload BAT once for validation activation and persist stdout/stderr in the local reload log.
6. Treat BAT exit code alone as insufficient: require exactly one matching SUSI4 System-class PnP device with `Status=OK` and `Problem=0`.
7. A reload/readiness failure blocks every section runner and transitions directly to rollback.

Validation reload count and rollback reload count are separate lifecycle metrics. “Reload once” means one activation reload for the full validation run; restoring the prior runtime state requires a separate recovery reload.

### P8 runner execution contract

- Execute manifest sections in registry order and use one unchanged full runtime INI for every runner.
- Construct remote runner/config paths from the staged target directories; do not pass local WSL paths to target PowerShell.
- Pass only baseline arguments (`ConfigPath`, `IniPath`, `OutDir`) plus the declared dependency paths. `HWM.Fan.Control` additionally receives `FanConfigPath` and `FanIniPath`.
- Do not pass `AllowControl`, `EnableFixtureTest`, `EnableFunctionalTest`, `EnableSetConfigTest`, `EnableStimulus`, or `EnableWriteTest` unless a future explicit CLI policy enables them from current-turn user consent.
- If `HWM.Fan` has infrastructure error or SW/API failure, emit `BLOCKED_DEPENDENCY` for `HWM.Fan.Control`; continue independent later sections.
- A section report showing a fixture-not-present conditional state is not equivalent to a mapping/API failure.

Transport pitfall: non-zero runner exit is section evidence, not automatically an SSH transport failure. The concrete transport must provide an allow-failure execution primitive that preserves remote exit code/stdout/stderr in `RemoteCommandResult`; only SSH/process-launch failure is a transport exception.

PowerShell argument construction must use escaped literals/typed values and splatting. Preserve string arrays such as `DllDirs` as arrays, booleans as `$true/$false`, and never use `Invoke-Expression`.

### P9 fresh-report and summary contract

- Snapshot `<prefix>_*.json` before each runner and accept exactly one newly created path afterward.
- Download each report immediately. Parse with `utf-8-sig` because Windows PowerShell UTF-8 output may contain BOM.
- Require report `category` to equal the manifest section. Missing, stale, multiple, malformed, or wrong-category reports are `ORCHESTRATOR_ERROR`.
- JSON report fields are verdict-authoritative. Preserve runner exit code/stdout/stderr as diagnostic evidence and warn on disagreement rather than overwriting the JSON verdict.
- For multi-channel sections, an overall `FAIL` remains valid when any required channel fails, but the report and text summary must distinguish `PARTIAL_FAIL` from all-channel failure. Include total/passed/failed counts, passed channel names, failed channel names, and status codes; do not use an unqualified section-wide failure sentence when some channels passed.
- Tolerate both runner families: newer reports with `sw_verdict`/`dqa_verdict`, and older VGA/GPIO/Storage reports without those optional fields.
- Summary status distinguishes `ORCHESTRATOR_ERROR`, `SECTION_FAIL`, and successful execution that may still contain DQA conditional/pending results.

### P10 rollback contract

Rollback belongs in the outer coordinator cleanup path after any attempted deployment/reload/run:

- if the original runtime INI existed, copy the verified backup back to the runtime path;
- if it did not exist, remove the INI created by this run;
- invoke a separate recovery reload;
- require final PnP readiness again;
- never let section PASS results hide rollback failure.

Keep runner-internal hardware restoration (fan/GPIO/storage) separate from orchestrator-owned runtime INI restoration. Both layers can be required.

### P11 fake-integration verification contract

Before P12, fake transport tests must prove:

- all 14 runners execute in exact registry order;
- fan/fan-control adjacency and dependency blocking;
- one full-INI deployment and one validation activation reload;
- reload failure yields zero runner invocations but still attempts rollback;
- every dangerous switch is absent by default;
- fresh report discovery, BOM-safe parse, category validation, and SW/DQA preservation;
- original-present restore and original-absent removal paths;
- execute CLI builds configs/preflight/manifest, stages, invokes P7-P10, and returns summary exit code.

Run focused Machine-B tests, full `tests/` discovery, Python compilation, and `git diff --check`. Test counts are not a durable contract; report the observed counts from the current repository rather than encoding old counts as an invariant.

## P12 real-target smoke gate

Real execution requires explicit current-turn authorization plus a positively identified Machine-B SSH host and user. Do not infer Machine-B from an unrelated SSH alias, a previously used target, or a context summary. A valid project artifact set does not identify the target machine.

Use execute mode only after host identity is confirmed:

```text
.venv/bin/python run_machineB_full_validation.py \
  --project <PROJECT> \
  --repo-root /home/company2/AIagent_susi \
  --run-id <UNIQUE_RUN_ID> \
  --execute --host <MACHINE_B_HOST> --user <MACHINE_B_USER>
```

The first smoke run keeps every fixture/control/write/stimulus/SetConfig switch off. If host discovery or an approval-gated command is denied, do not probe through alternate commands, do not deploy anything, and do not label P12 complete. Report P7-P11 separately as locally/fake verified and request the exact host/user or new approval.

## Canonical target layout

- Workspace: `C:\Users\susiaa\Desktop\verify\<project>\`
- Runners/helpers: `scripts\`
- Generated configs: `config\`
- Split INIs for provenance/isolation: `ini\`
- Per-run reports/manifest/backup: `out\<run_id>\`
- Runtime INI: `C:\Windows\SUSI\<project>.ini`
- Existing reload entrypoint: `C:\Users\susiaa\Desktop\reload driver\reload_susi4_driver.bat`

Do not create a competing `Desktop\susi_validation` hierarchy when the established `verify\<project>` layout exists. Do not upload a replacement reload implementation during the normal full-INI run.

## Legacy orchestrator boundary

`run_two_section_validation.py` is a legacy isolation/experiment orchestrator. It consumes pre-existing JSON; it does not call `build_machineB_section_configs.py` and does not generate PowerShell runners. It deploys split INIs and reloads per section, so it must not be expanded blindly into the normal full-INI workflow. Reuse generic SSH/SCP/report parsing helpers only after separating them from its old deployment policy.

## Deterministic safety rules

Encode, do not merely document:

- full INI deployed once on the normal path;
- reload BAT called once on the normal path;
- reload failure blocks all runners;
- each runner is a separate process;
- destructive/fixture/write switches default off;
- report JSON is authoritative over wrapper exit code for section verdict;
- stale or missing report is infrastructure failure;
- runtime-health/recovery failure stops later write-tier tests;
- split INI reload loops are isolation/convergence only;
- expected split-source-vs-full-runtime hash mismatch is warning-only in complete-INI mode.

## Minimum tests

- all 14 registry entries are unique and complete;
- every `GENERATED` matrix section resolves to config and runner;
- runtime filename is exactly `<project>.ini`;
- dry-run performs no network or target mutation; local writes are limited to deterministic `CASES/<project>/config/` refresh plus `validation_runs/<run-id>/manifest.json`;
- normal plan deploy count is one and reload count is one;
- reload failure produces no runner invocations;
- dangerous switches remain disabled without explicit CLI opt-in;
- report selection rejects pre-existing files;
- missing/crashed runner produces an infrastructure stop according to tier policy;
- summary preserves SW and DQA verdict separation.
