# Local-probe EIO-300 + NCT6694B runbook

Use when a project reports that networking is unavailable and probe text was already copied into `CASES/<PROJECT>/`.

## Proven execution pattern

1. Do not run `ssh`, `scp`, `fetch_probe.py --mode ssh`, or auxiliary remote probes. This is a hard local-probe gate.
2. Resolve the project directory case-insensitively and enumerate candidate `*.txt` files. Accept a clearly matching generic report such as `susi_full_probe_report.txt`; do not rename it just to satisfy a canonical filename.
3. Keep all generated artifacts inside the canonical project directory. Pass explicit absolute paths for `--project`, `--in-pdf`, `--out-json`, `--spec-out`, `--out-ini`, and `--probe`; this prevents stale CASES-root artifacts from being selected.
4. For a fresh project, run `extract`, then `understand` with available BIOS screenshots, then `generate --split`. If the user supplied an explicit compound chip identity, use `--product-name` and the canonical EC key (`EIO-300`) rather than the display token `NCT6694B`.
5. Verify section routing in the matrix: `SMBus`, `I2C`, and `GPIO` must query `NCT6694B`; other EC-side sections must query `EIO-300`.
6. Build Machine-B JSON only from that same project-local matrix.

## Vision artifacts

For BIOS JPG/JPEG screenshots, analyze all `bios*` files, not just PNGs. Persist:
- `<PROJECT>-bios-image-cache.json` with `DONE_VISION_ANALYZE` per scoped BIOS/circuit raster;
- `<PROJECT>-temperature-name-hints.json` for clearly visible real-time sensor labels;
- `<PROJECT>-fan-name-hints.json` for BIOS fan labels.

For EC GPIO projects, schematic image analysis may document `EC_P1_GPIO*`, but DB-driven EC GPIO generation remains the baseline; tracing is evidence/support, not a substitute for section routing.

## Verification checklist

- `section-matrix.project` equals the canonical project token.
- All expected section statuses are `GENERATED` or explicitly reported as skipped/pending.
- `PlatformVersion` and `BIOSVersion` in the generated pre-INI match probe `Value=` rows.
- `HWM.Current`, `StorageArea`, and `ThermalProtect` Name fields remain blank.
- Confirm `<PROJECT>_fan.json`, `<PROJECT>_fancontrol.json`, and any other Machine-B JSON are generated from the project-local matrix.
