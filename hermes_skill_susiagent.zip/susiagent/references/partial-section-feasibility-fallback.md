# Partial section feasibility fallback (AIMB-289, NCT6126D)

When user intent is "from existing data, what sections can be completed", and full generate/split is blocked, run section-isolated generation.

## Trigger pattern
- User gives explicit chip override and asks for current feasible sections.
- Full run fails due one section hard error (DB/query/contract mismatch).

## Confirmed CLI constraints
- `--split` and `--sections` are mutually exclusive.
- Do not combine them in one invocation.

## Recovery flow
1. Try full run once:
   - `--stage generate --split`
2. If blocked, execute per-section loop:
   - `--stage generate --sections SMBus`
   - ...repeat for all 14 sections.
3. Bucket status into:
   - `GENERATED`
   - `SKIPPED_EMPTY_SECTION`
   - blocked/pending/error (`PENDING_*`, `*_AMBIGUOUS`, hard exceptions)

## AIMB-289 observed statuses
- GENERATED: `SMBus`, `VGA.Brightness`, `HWM.CaseOpen`, `WDT`, `GPIO`
- SKIPPED_EMPTY_SECTION: `VGA.Backlight`, `HWM.Current`, `HWM.Temperature`, `HWM.Fan`, `StorageArea`, `ThermalProtect`
- BLOCKED/PENDING:
  - `I2C`: `sqlite3.OperationalError: no such column: item_name`
  - `HWM.Voltage`: `PENDING_R_015_NEED_EVIDENCE`
  - `HWM.Fan.Control`: `FAN_PAIRING_AMBIGUOUS`

## Useful operator note
If you need a partial artifact set quickly, run one command with comma-separated stable sections in `--sections` (no `--split`) and report only generated outputs with absolute paths.