# Machine-B StorageArea write-test observed run

## Scope
Use this reference when executing `run_storage_validation.ps1` for StorageArea with `-EnableWriteTest`.

## Required safety contract
- Lock/Unlock must remain disabled for the initial validation: do not declare or call `SusiStorageAreaSetUnlock` or `SusiStorageAreaSetLock`.
- Write is opt-in only when both conditions are true:
  - JSON `write_check.enabled=true`
  - runner switch `-EnableWriteTest`
- The intended sequence is `Read -> Write(pattern) -> Read/verify -> Write(original) -> Read/verify restore`.
- Backup the runtime INI before deployment, restore it after the run, and verify the restored hash and final SUSI4 device status.

## Observed target behavior and later resolution
An earlier MIO-2375 report showed `StorageGetCaps` and `StorageAreaRead` returning `0xFFFFFCFF` (`SUSI_STATUS_UNSUPPORTED`). Because no original buffer was captured, the runner correctly issued no `StorageAreaWrite`, restore, or restore-read calls.

A later rerun on the same target, with the runtime INI containing the active `[StorageArea]` section, passed `GetCaps`, read, write/verify, restore, and restore-verify using the same public storage API ID. Therefore, do **not** preserve the earlier `UNSUPPORTED` result as a board capability claim or JSON-ID defect. Treat it as evidence that the required section was not registered in the active runtime state at that earlier timestamp.

Diagnostic rule: compare runtime INI path/hash, section presence, deployment/reload state, and report timestamp before changing API IDs or generator mappings. See `machineb-runtime-state-and-cross-tool-diagnosis.md`.

## Remote execution order
1. Sync `common_susi.ps1`, the StorageArea runner, JSON, and section INI; verify hashes.
2. Back up `C:\Windows\SUSI\<project>.ini`.
3. Deploy the paired StorageArea INI.
4. Attempt the project-approved driver reload and record its exact result. `SusiLibInitialize` is not a driver reload substitute.
5. Run the runner with `-ConfigPath`, `-IniPath`, `-OutDir`, and `-EnableWriteTest`.
6. Pull the newly timestamped report and inspect `metrics.policy`, `metrics.write_test`, and `api_calls` for actual `StorageAreaWrite`/restore evidence.
7. Restore the original runtime INI even when the run fails; verify hash and device status.

## Interpretation
- `write_enabled=true` proves policy/switch gating only; it does not prove a write occurred.
- Actual write execution requires report calls named `StorageAreaWrite:<channel>`, `StorageAreaRestore:<channel>`, and `StorageAreaRestoreRead:<channel>`.
- If only `StorageGetCaps`/`StorageAreaRead` appear and those return `0xFFFFFCFF`, report StorageArea as unsupported/read-blocked and explicitly state that no storage mutation occurred.
- A reload-tool failure must be reported separately from the API result. Do not claim a valid post-deploy runtime test merely because the driver currently shows `Status=OK`.
