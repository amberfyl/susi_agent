# FAN mapping evidence checklist

Use this when mapping FAN input/output nets from schematic images/PDF.

## 1) Candidate net discovery
- IN candidates: `FAN_SPEED*`, `*TACH*`, `CPUFANIN`, `SYSFANIN`, `AUXFANIN*`
- OUT candidates: `*_PWM`, `CPUFANOUT`, `SYSFANOUT`, `AUXFANOUT*`

## 2) Required proof chain (must be explicit)
For each mapping, capture all 3 layers:
1. external signal/net label
2. logical function label (CPU/SYS/AUX FAN IN/OUT)
3. EC/SIO endpoint pin (pin number + pin function)

Reject mappings that rely only on nearby text or row proximity.

## 3) Pairing rule
- Pair IN/OUT only when both signals are evidenced for the same fan channel.
- One-to-one is decided only after diagram/PDF tracing is complete (never as a precondition).
- If one-to-one is confirmed, `[HWM.Fan]` and `[HWM.Fan.Control]` must use synchronized keys and mapping values (`hwid`, `channel_id`, `io_port`, BIOS alias), with differences limited to each section's fixed template fields.
- If only one side is proven or endpoint is unclear, mark as `ambiguous`.

## 3.1) Evidence logging scope
- File/page/region logging is optional debug metadata.
- Normal generation output does not require file/page fields unless conflict/ambiguity needs audit.

## 4) Ambiguity gate
Escalate to cross-check with source schematic PDF/vector geometry when:
- image crop is too tight,
- crossing lines or junction dots are unclear,
- pin-row alignment risks off-by-one,
- `X`/`NC` marks conflict with visible routed wire.

## 5) X/NC policy
- Treat `X`/`NC` as hint-only.
- Final decision is always continuous routed wire + endpoint evidence.
