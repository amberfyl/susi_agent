# Local-probe non-destructive rerun + policy-denied recovery

When user says network is unavailable and probe report already exists in project dir (for example: `網路不通`, `report 已拿回`, `不用 SSH`), run `/susiagent` in strict local-probe mode.

## Durable rules

1) No SSH path in local-probe mode
- Do not run `ssh`, `scp`, or `fetch_probe.py --mode ssh`.
- Use existing local report path via `--probe`.

2) Prefer non-destructive rerun commands
- Do not prepend cleanup like `rm -f ...` before `susi_gen.py` unless user explicitly asks cleanup.
- Use explicit canonical in-project output args and let generator overwrite expected artifacts.
- Rationale: policy/approval systems may deny destructive commands and block the whole run.

3) Denied-command recovery (local stage)
- If command is denied by policy/approval gate, stop immediately.
- Report exact blocked command class and ask for approval.
- After approval, rerun the same stage with minimal non-destructive command form first.
- Do not attempt alternate hidden/destructive bypasses.

## Suggested command shape (local-probe)

`/home/company2/AIagent_susi/.venv/bin/python /home/company2/AIagent_susi/susi_gen.py --stage all --project /home/company2/AIagent_susi/CASES/<PROJECT> --root /home/company2/AIagent_susi/CASES --probe /home/company2/AIagent_susi/CASES/<PROJECT>/<LOCAL_REPORT>.txt --chip-name <DB_CHIP_KEY> --out-json /home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>.json --spec-out /home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>-spec.json --out-ini /home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>-pre.ini --split`

Notes:
- For compound chip input like `EIO-300/nct6694B`, keep section-routing policy intact (SMBus/I2C/GPIO to NCT6694B; EC-side others EIO-300).
- Use canonical project directory path in `--project` to avoid root-level artifact drift.
