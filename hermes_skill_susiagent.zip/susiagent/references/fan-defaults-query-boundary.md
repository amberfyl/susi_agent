# HWM.Fan query boundary in config_new.db

Current schema
- The active database is `config_new.db`.
- Fan channel rows are queried from the hardware-specific `HWM.Fan` table by `(product_name, chip_name)` -> `hardware_id`.
- The retired `HWM.Fan.Defaults` and `HWM.Fan.Channels` tables are not query targets.

Compatibility
- `query_config_db.py` returns the new source columns (`report_name`, `channel_id`, `channel_name`, `options`) plus read-only aliases for existing builder code.
- Shared fan template defaults remain available through `load_hwm_fan_defaults()`; this helper reads the active `HWM.Fan` rows and does not query a retired defaults table.

What to do
1) Query `HWM.Fan` through `query_section()` for hardware-specific fan rows.
2) Use `load_hwm_fan_defaults()` only for shared template compatibility values.
3) Do not add or restore generic CLI targets for the retired `HWM.Fan.Defaults` / `HWM.Fan.Channels` names.

Pipeline implication
- In `/susiagent` runs, use the active `HWM.Fan` section rows as the DB baseline, then let fan-pairing evidence determine the final FAN/FAN.Control mapping.
- Do not treat DB baseline rows as final topology judgement.

Consistency note
- Fan-default chip applicability should stay aligned with generator code. Current implemented set includes:
  - `EIO-201`, `EIO-211`, `IT-8528`, `IT-5782`, `IT-5121`.
