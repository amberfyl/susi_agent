# SMBus policy addendum: EC Intel Channel1 override + SIO-empty short-circuit

Scope
- Applies to `/home/company2/AIagent_susi/susi_gen.py` SMBus decision path (`_build_smbus_query_result`).

Rules (execution order)
1) SIO short-circuit first:
   - If `chip_name` is SIO family (`NCT6106D` / `NCT6116D` / `NCT6126D` / `NCT6776D*`), return `SECTION_EMPTY` for SMBus immediately.
2) EC Intel override:
   - For non-SIO (EC-route) and Intel CPU, always emit fixed `Channel1` (`hw=0x00000001, channel=0, io_port=0, option=0xA0000000`) even when `spec.features.smbus=false`.
3) Non-Intel + smbus disabled:
   - If `spec.features.smbus=false` and CPU is not Intel, keep SMBus `SECTION_EMPTY`.
4) AMD path remains unchanged:
   - Keep existing SPD idx probe + Channel2 policy.

Why this order matters
- Prevents `spec.features.smbus=false` from incorrectly suppressing Intel EC Channel1.
- Prevents SIO platforms from emitting SMBus rows due to CPU-based logic.

Minimal verification checklist
- EC + Intel + `features.smbus=false` => `status=FOUND`, `Channel1` present with fixed tuple.
- SIO + Intel/AMD => `status=SECTION_EMPTY`.
- EC + AMD => existing SPD idx pending/fill behavior unchanged.
