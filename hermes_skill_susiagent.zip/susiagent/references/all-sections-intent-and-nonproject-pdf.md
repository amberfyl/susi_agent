# All-sections intent + non-`<PROJECT>.pdf` input handling

When user asks `/susiagent <PROJECT>` with intent like “所有 section 都要”, interpret it as:
- run full split pipeline and produce a section-matrix entry for all standard sections,
- do not treat `SKIPPED_EMPTY_SECTION` as pipeline failure,
- report per-section status explicitly (`GENERATED` vs `SKIPPED_EMPTY_SECTION` vs `PENDING_*`).

If `<PROJECT>.pdf` is missing but project contains a board/schematic PDF (for example `circuit_SIO6126.pdf`), use explicit `--in-pdf` and always lock outputs with:
- `--out-json <PROJECT>.json`
- `--spec-out <PROJECT>-spec.json`
- `--out-ini <PROJECT>-pre.ini`

This prevents basename drift to `circuit_*` artifacts and keeps `section-matrix.project == <PROJECT>` consistent.

AIMB-289 pattern (validated): host override + shorthand chip (`6126D` -> `NCT6126D`) + non-project PDF still yields complete matrix coverage when split generation is executed with explicit output names.
