# Machine-B SW/DQA Dual Verdict + CI Exit-Code Policy

When validation includes fixture/reboot-dependent steps, do not use a single `result` field as CI gate.

## Contract
Each Machine-B section report should include:
- `result` (human diagnostic summary)
- `sw_verdict` (`PASS_SW` | `FAIL_SW`)
- `dqa_verdict` (`N_A_DQA` | `PENDING_DQA` | `PASS_DQA` | `FAIL_DQA`)
- `ci_exit_code` (integer for pipeline)

## Layer-to-verdict mapping

### SW verdict (pipeline gate)
Compute from L1~L4 only:
- `L1_configuration`
- `L2_capability`
- `L3_api`
- `L4_readback`

Rule:
- Any `FAIL*` in L1~L4 => `FAIL_SW`
- Otherwise => `PASS_SW`

### DQA verdict (fixture/lab completion gate)
Compute from L5~L6 only:
- `L5_functional`
- `L6_recovery`

Rule:
- Any `FAIL*` => `FAIL_DQA`
- Both `PASS` => `PASS_DQA`
- Both in `N_A`/`NOT_REQUIRED` => `N_A_DQA`
- Otherwise (`PENDING`, `CONDITIONAL`, mixed) => `PENDING_DQA`

## Exit code policy (must be CI-safe)
- `FAIL_SW` => non-zero (typically 1)
- `PASS_SW` => zero

Important: `CONDITIONAL`/`BLOCKED_*` from fixture or reboot gating should not force non-zero when SW path is healthy.

## Implementation notes
- Keep `result` + `reason` for operators.
- Use `sw_verdict` for automation merge gates.
- Use `dqa_verdict` for DQA fixture tracking and formal signoff dashboards.
- Mirror this policy in both runner scripts and generated section JSON (`verdict_policy`) so behavior is reproducible.

## Validation checklist for rollout
1. Run Fan / Fan.Control / SMBus / WDT on a known target.
2. Confirm report includes `sw_verdict`, `dqa_verdict`, `ci_exit_code`.
3. Confirm fixture-blocked sections can still emit `sw_verdict=PASS_SW`, `dqa_verdict=PENDING_DQA`, `ci_exit_code=0`.
4. Confirm real API/readback break emits `sw_verdict=FAIL_SW`, `ci_exit_code!=0`.
