# Machine-B HWM.Current JSON and runner contract

Use this reference when adding or executing a Machine-B validator for `[HWM.Current]`.

## Canonical ID rule

The second field in a generated INI tuple is the configuration/tuple channel. It is not automatically the `SusiBoardGetValue()` API ID.

For current channels, construct the API namespace from the canonical SUSI Current namespace:

- `OEM0` -> `0x00023000`
- `OEM1` -> `0x00023001`
- `OEM2` -> `0x00023002`
- in general: `0x00023000 + index`

Preserve the raw INI tuple channel separately in JSON as `tuple_channel`. Never replace the canonical API ID with `0x80000000 + index` merely because that value appears in the INI.

The builder must fail closed for an unknown current key rather than inventing an API ID.

## JSON contract

`build_machineB_section_configs.py` owns generation. A generated file should include:

```json
{
  "category": "HWM.Current",
  "required_channels": ["OEM0"],
  "channels": {
    "OEM0": {
      "tuple_channel": "0x80000000",
      "api_id": "0x00023000",
      "decode": "milliamps"
    }
  }
}
```

The source INI hash and section metadata must remain available when the general builder schema provides them.

## Runner contract

The section runner should visibly mark the four reusable stages in its source:

```powershell
# [RUNNER SKELETON] 1) config + section gate
# [RUNNER SKELETON] 2) initialize + capability gate
# [RUNNER SKELETON] 3) per-channel sampling loop
# [RUNNER SKELETON] 4) verdict mapping + result breakdown
```

The sampling loop should use the JSON `api_id`, verify status codes, collect multiple samples, and report the decoded current value in mA. A successful software/API read without a controlled load stimulus is `CONDITIONAL` for DQA, while the SW verdict and exit code still follow the shared Machine-B SW/DQA policy.

## Execution sequence

For a remote run, require explicit current-turn consent before state-changing actions. Then execute one auditable state change at a time:

1. back up the runtime INI;
2. copy the paired Current JSON and section INI;
3. deploy the section INI to the runtime path;
4. reload SUSI4/driver;
5. run the Current runner with explicit `-ConfigPath` and `-IniPath`;
6. pull the timestamped report;
7. restore the original INI;
8. reload again and verify the restored hash and final device state.

Do not claim that library initialize/uninitialize performed an OS driver reload. Do not present a pre-fix report as the result of a corrected JSON/config run.

## Local preflight

Before remote execution, compile the builder and validate the generated Current JSON. Confirm that `category`, required keys, canonical API IDs, and preserved tuple channels are all correct. For the target report, compare the runner API ID with the full-probe `[OK]` Current API ID before trying option or runtime fallbacks.
