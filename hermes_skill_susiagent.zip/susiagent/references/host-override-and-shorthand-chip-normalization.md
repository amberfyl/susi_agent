# Host override + shorthand chip normalization (susiagent)

When user invokes `/susiagent` in plain language with both a custom host and shorthand chip token (example: `aimb-289 ip 172.22.12.71 chipname 6126`), enforce this deterministic flow:

1. Resolve canonical project directory case-insensitively (`AIMB-289`).
2. Use user host override for this run, not the skill default host.
3. Run SSH auth preflight (`BatchMode=yes`) before fetch.
4. Fetch probe via `fetch_probe.py` using venv Python and explicit remote BAT/report paths.
5. Normalize shorthand chip token to canonical `ProductChip.chip_name` with unique match (e.g., `6126`/`6126D` -> `NCT6126D`).
6. Run `susi_gen.py --stage all` with explicit `--chip-name <canonical>` and explicit `--in-pdf/--out-json/--spec-out/--out-ini` to preserve project-token outputs.
7. Verify lock after run:
   - `section-matrix.project == <PROJECT>`
   - expected artifacts exist (`<PROJECT>-pre.ini`, `<PROJECT>-section-matrix.json`, split INIs)
8. Build Machine-B section JSON from matrix; only claim runnable fan/fancontrol JSON when source sections are `GENERATED`.

Quick report checks:
- Fan display-name consistency across `[HWM.Fan]` and `[HWM.Fan.Control]`.
- Section summary split into `GENERATED` vs `SKIPPED_EMPTY_SECTION`.

This pattern avoids wrong-host execution, chip-name inference failures, and output basename drift when schematic PDF filename differs from project token.
