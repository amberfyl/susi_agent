# Post-validation IOPort/Address fallback convergence

Use this policy after the first `/susiagent --all` full-INI validation. It is a deterministic recovery path for sections that should exist but whose API probing fails on every channel.

## Responsibility split

- AI: classify the first-run reports, choose eligible sections, and produce a schema-validated `fallback-plan.json` using registry values only.
- Python: order candidates, clone the effective full INI, mutate one section, deploy, reload, run the targeted validator, collect evidence, stop, and restore/retain state deterministically.
- PowerShell: run one section's existing SUSI API validation and emit its normal JSON report.
- AI must not emit arbitrary INI patches, remote commands, runner paths, or values outside the registry.

## Candidate data ownership

Keep three data classes separate:

1. `config_new.db`: formal baseline tuple source.
2. Version-controlled JSON candidate registry beside Machine-B validation code: historical DB-range whitelist for fallback testing. Do not write unverified possibilities into the DB.
3. Project override JSON: only a target-validated successful route. The generator applies `DB baseline -> project override` and regenerates full INI, split INIs, matrix, and section JSON.

The registry may record both route and Option value sets, but the first implementation enables route fallback only:

- `route_candidates`: enabled.
- `option_candidates`: documentary whitelist only.
- `enable_option_fallback`: false.

If a section has no route other than its baseline value, classify it as `NO_ALTERNATIVE_CANDIDATE` and do not redeploy an identical INI.

## Eligibility gate

First establish section applicability before deployment or report analysis. A DB tuple match or generic `hardware_monitor=true` is not enough to make a subsection applicable. For `HWM.Current` and `HWM.CaseOpen`, explicit user/spec intent is authoritative: false, disabled, or an explicit empty item list means skip even if generic DB rows exist; true or a non-empty item list enables generation. Only when spec intent is unknown or absent may completed BIOS-image-cache evidence enable the section. If neither source enables it, the generator must omit the entire section, mark it `SKIPPED_NOT_APPLICABLE`, remove stale split/config artifacts, and the Machine-B manifest must not schedule its runner. Any API failure caused by testing such a non-applicable section is invalid evidence and must never trigger fallback.

Trigger fallback only when all are true:

- section-specific spec/BIOS evidence positively enables the section, and DB/matrix evidence agrees that it should exist;
- the baseline full INI contains the complete generated section with at least one tuple;
- the section runner completed and produced a fresh, parseable report;
- every reported channel's relevant SUSI API call failed, except for the GPIO-specific route-probe policy below;
- the failure is not caused by SSH, deployment, reload/readiness, driver, missing/stale report, fixture, control/write opt-in, or another infrastructure condition.

Do not trigger for `PARTIAL_FAIL`: one successful channel already proves the product-wide route because rows in a product normally share the same IOPort/Address. Products with per-channel route exceptions require explicit project-specific handling.

GPIO uses a section-specific route-probe contract because `GetDirection`/`GetLevel` success does not prove the INI IOPort route. Trigger GPIO fallback only when both `GetCaps input` and `GetCaps output` are present for every required bank and every one of those calls fails. Any successful required GetCaps call blocks GPIO fallback; missing GetCaps evidence fails closed. A GPIO candidate converges only when every required bank has successful GetCaps input/output with complete expected masks and successful GetDirection/GetLevel (`caps_ok=true` and `reads_ok=true`). Do not accept a candidate merely because Direction or Level succeeds.

### Section-specific route probes

Do not equate every successful API call with proof that the configured route is correct. Define a deterministic route-probe contract per section when its report mixes capability calls with secondary read/control calls.

For GPIO:

- `SusiGPIOGetCaps` input and output are the required route probes for every required bank.
- Trigger route fallback when all required GetCaps calls have explicit failure statuses, even if `GetDirection` or `GetLevel` succeeds. Those secondary reads do not prove that the INI IOPort/Address is correct.
- If any required GetCaps call succeeds, classify the baseline as partial route-probe success and do not run product-wide route fallback.
- Missing or ambiguous GetCaps evidence must fail closed as `ROUTE_PROBE_EVIDENCE_MISSING`, not trigger fallback.
- Use a distinct trigger such as `EXPECTED_SECTION_ROUTE_PROBE_ALL_FAILED`; do not mislabel this as all channel APIs failing.

The trigger classifier must derive this from raw report evidence (`api_calls`, bank metadata, statuses, and expected masks), not from an AI-authored plan field or the runner process exit code.

### Plan trust boundary

Treat AI plan fields as proposals, not authorization. Before any config generation, staging, or target access, Python must independently:

- parse the referenced baseline summary and raw reports, not merely compare caller-supplied hashes;
- verify project/run ID, generated-section membership, section category, report path/hash, fresh `COMPLETED` execution, and zero successful plus at least one failed relevant API channel;
- recompute the trigger classification from report evidence and reject disagreement with `trigger_code`, `passed_channels`, or `failed_channels`;
- parse the baseline full INI and require `baseline_route` to match every mutable target row while preserving fixed rows;
- reject unknown plan fields and enforce the complete plan schema plus exact registry candidate order.

A valid SHA-256 proves file identity only; it does not prove that the file content authorizes fallback.

## Mutation contract

For each eligible section:

1. Baseline means the complete first-version INI used by the first full validation.
2. Normalize and remove the baseline route from the registry candidates; preserve deterministic registry order.
3. For each candidate, clone the current effective full INI.
4. Change only the IOPort/Address field of every mutable row in that one section.
5. Do not change key, channel ID, HWID, Option, pulses, group/bit, aliases, row order, or any other section.
6. Preserve fixed rows such as Intel SMBus Channel1; only allowed SMBus Channel2+ rows may change.
7. Deploy -> reload/readiness -> run the existing single-section validator -> fetch the fresh report.
8. Never mutate more than one problem section in an attempt.

## Acceptance and stopping

- Candidate acceptance must use the same section-specific route-probe contract that authorized fallback; do not blindly reuse a generic `ANY_CHANNEL_API_SUCCEEDED` rule.
- For ordinary channel-based sections, a candidate may converge when at least one channel's relevant route-diagnostic SUSI API call has an explicit success status.
- For GPIO, accept a candidate only when every required bank passes all of these: GetCaps input status is success, GetCaps output status is success, both returned support masks cover the bank's `expected_mask`, GetDirection succeeds, and GetLevel succeeds. A pre-existing Direction/Level success must never cause the first candidate to be accepted while GetCaps still fails.
- Generic `channel:*` pass labels are insufficient: capability-mask, range, plausibility, readback, fixture, or functional passes must not authorize convergence unless the section-specific contract explicitly names them.
- Runner reports should expose raw per-call API names/status codes plus enough bank/channel metadata for Python to recompute trigger and acceptance. Fail closed when required API-specific evidence is missing or ambiguous.
- Stop immediately at the first candidate that satisfies its complete section-specific acceptance contract; do not exhaust the whitelist.
- Keep successful section changes in the current effective full INI so later section convergence can build on them.
- Per-channel route exceptions are not inferred automatically.

If every candidate fails, restoring the pre-attempt effective baseline is the preferred deterministic behavior, but the key contract is evidence completeness: report every tested route as failed and do not create a project override or claim convergence.

`NO_ALTERNATIVE_CANDIDATE` is unresolved/exhausted, not `NO_ACTION`. Treat candidate exhaustion as a section-level validation result, not a pipeline-fatal condition: retain complete evidence, restore that section's pre-attempt effective baseline, create no override for it, and continue with every remaining eligible section. After all sections have been processed, `/susiagent --all` reports that the run completed and points to the aggregate summary; unresolved/failed sections are recorded in that summary but do not by themselves make the overall command report failure. Reserve a nonzero/fatal overall result for orchestration or infrastructure failures that prevent the run from completing safely (for example deployment, rollback/cleanup, corrupt evidence, or transaction failure).

## Attempt evidence

For every attempt retain:

- section and candidate route;
- changed keys/rows and confirmation that only the target section changed;
- candidate full-INI SHA-256;
- deploy status;
- reload command/readiness status;
- runner process exit code as diagnostic evidence;
- fresh report path and SHA-256;
- per-channel API result and status code;
- acceptance decision.

Use the JSON report verdict/API evidence as authoritative; process exit code alone is insufficient. Preserve attempt and accepted-route evidence even if later project-override, generator, matrix, or section-JSON convergence fails; append the formal-convergence error instead of replacing prior results.

## Formal artifact transaction

Project override, full INI, split INIs, matrix, and section JSON are one logical transaction:

1. Snapshot all files that may change.
2. Build and validate every new artifact in temporary paths.
3. Commit only after all generator/builder checks pass.
4. If any write, build, or validation fails, restore every snapshot and retain the remote attempt evidence.

Never commit the project override first and leave partially updated generated artifacts. A failed/no-candidate section must not create or update an override.

## Option handling

Option values can enable finer capabilities and may need a future, separately specified convergence mode. Do not combine route and Option lists into a Cartesian product. Until an explicit Option-only trigger and acceptance contract exists, record Option candidates but never iterate or mutate them.

## Legacy helper migration

`tools/hwm_temperature_option_fallback.py` is a prototype, not the new executor. Reusable ideas are: all-channel failure trigger, candidate de-duplication, first-success stop, attempt recording, and restore-on-exhaustion. Do not directly reuse these conflicting behaviors:

- Temperature-only scope;
- simultaneous `io_port + option` mutation;
- hard-coded Option values outside the current whitelist;
- in-place modification of canonical split/pre INIs before validation;
- selecting and retaining the first candidate when no runner is supplied;
- shell-command execution with `shell=True`;
- plain probe-text decisions without targeted JSON API evidence or infrastructure classification.

The existing generator hook and orchestration documentation that describe simultaneous route+Option iteration must be migrated to this post-first-validation, route-only contract.

## Required tests

Cover at least:

- eligibility only for expected, all-channel API failures;
- section-specific route-probe triggers: GPIO GetCaps input/output all fail is eligible even when GetDirection/GetLevel succeeds;
- GPIO partial GetCaps success and missing/ambiguous GetCaps evidence do not trigger fallback;
- GPIO candidates are rejected when only Direction/Level succeeds, when GetCaps status fails, or when returned support masks do not cover `expected_mask`;
- GPIO converges only when all required banks pass GetCaps input/output, capability masks, GetDirection, and GetLevel;
- PARTIAL_FAIL, fixture, and infrastructure exclusions;
- registry validation, normalization, baseline removal, and deterministic order;
- Option never changes;
- only one target section and only mutable route fields change;
- Intel SMBus Channel1 remains fixed;
- any one channel API success stops remaining candidates;
- all failures retain complete evidence and create no override;
- successful override feeds the main generator and regenerates all dependent artifacts.
