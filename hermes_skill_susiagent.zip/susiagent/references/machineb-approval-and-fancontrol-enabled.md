# Machine-B approval gate + fancontrol enabled pitfall

When running target-B validation from WSL/CLI, two recurring pitfalls were confirmed.

## 1) Approval-gated remote side effects are per command

Symptoms
- A remote write command (`scp`/`ssh` with state change) can be blocked with `User denied this command`.
- One write command may pass while the next one is blocked even in the same workflow.

Operational rule
- Treat each remote write as separately approval-gated.
- Do not chain multiple writes in one compound command (`cmd1 && cmd2`) when approval is expected.
- Run one write command at a time, get approval, then verify remote state (`dir`/hash/list) before continuing.
- If denied, stop and request fresh explicit consent; do not retry by alternate command in the same turn.

## 2) fan control runner can be blocked by config default

Symptoms
- `hwm.fan.control.ps1 -AllowControl` returns `BLOCKED_CONFIGURATION` with reason `enabled is false`.

Cause
- `<project>_fancontrol.json` may intentionally default to `control_check.enabled=false`.

Action
- For real control-effect validation, pass an enabled config explicitly:
  - `-ConfigPath <...>\<project>_fancontrol_enabled.json`
- Keep safe default JSON for non-intrusive runs; use enabled variant only when user requested active control test.

## Verification sequence (recommended)
1. Run read-only fan check (`hwm.fan_verify.ps1`) first.
2. If control test requested, run control with explicit enabled config.
3. Pull report JSONs back to local `verify_out/` and summarize with `checks` first (`read_stability/control_effect/recovery`).
