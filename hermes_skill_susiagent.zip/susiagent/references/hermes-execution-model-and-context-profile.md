# Hermes execution profile for deterministic SUSI runs

Use this when the SUSI architecture and code are already fixed and the user only wants the agent to execute the pipeline.

## Model/reasoning selection

- Routine artifact generation or a previously proven `--all` Machine-B run: prefer the execution-oriented Luna model at `medium` reasoning (current example: `gpt-5.6-luna`).
- First safe smoke run on a new Machine-B or an environment whose transport/runtime paths have not been proven: use Luna `high`, then return to `medium` after one complete deployment/recovery cycle succeeds.
- Unknown cross-layer failure, architecture change, code modification, or contradictory Python/PowerShell/report evidence: switch to the stronger analysis/coding model (current example: Sol) at `high`; reserve `xhigh` for genuinely difficult redesign or root-cause work.
- Do not use Sol/xhigh by default merely to launch the deterministic orchestrator. Fixed ordering, safety gates, runner selection, parsing, and rollback belong to code, not repeated model reasoning.

## Context status and compression

Hermes TUI renders `used/context-window` (for example `95.7K/272K`). Treat the right-hand value as the provider-resolved context cap, not as the compression trigger. For Codex-backed models it may be a provider-specific cap discovered from `/models` or a provider-aware fallback.

Configure compression independently:

```bash
hermes config set compression.threshold 0.75
hermes config
```

For long tool-heavy SUSI runs, `0.70`–`0.75` is a practical range. Keep enough headroom for a large runner report or tool result. The trigger is approximately:

```text
context_window × compression.threshold
```

`compression.target_ratio` controls the approximate retained size after compression; it does not control when compression starts. Change the threshold first and normally keep the target ratio at its established value.

Do not raise `model.context_length` above the actual provider cap merely to delay compression. Hermes permits an explicit override, but the upstream provider can still reject an oversized prompt. Switch to a provider/model with a genuinely larger window if more context is required.

After changing compression construction-time settings, restart the CLI session; restart the gateway for gateway use. Do not disable compression for long SUSI runs unless accepting eventual provider-limit failures.
