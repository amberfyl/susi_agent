# EC_P1 page-jump missing-destination hard-stop (AFE-R360 pattern)

Problem pattern
- GPIO trace claims `CONFIRMED` mappings for `EC_P1_GPIO*` from a page that only shows BI/page-jump tags (for example `<49>`).
- Destination page evidence is not available in project sources (common when project only has one schematic page or incomplete export).
- Result: false-positive GPIO group/bit mapping and wrong `[GPIO]` output.

Durable rule
1. For `EC_P1_GPIO*`, if available evidence only shows page-jump markers and destination-page continuity cannot be proven, force status to `AMBIGUOUS`.
2. Do not emit guessed `group/bit/package_pin` from proximity or partial labels.
3. In generate stage, ambiguous-only trace must produce `GPIO_TRACE_AMBIGUOUS` with `row_count=0` and `path=null` for GPIO section (no `[GPIO]` output).
4. If a stale `_GPIO.ini` exists from an older wrong run, remove/regenerate so deliverables do not carry obsolete mappings.

Quick verification checklist
- `section-matrix` GPIO entry:
  - `status = GPIO_TRACE_AMBIGUOUS`
  - `gpio_trace_confirmed_count = 0`
  - `path = null`
- `<PROJECT>-pre.ini` has no `[GPIO]` section when trace is ambiguous-only.

Notes
- This is evidence-quality gating, not a board-specific exception.
- Applies equally when PNG crops are present but page-jump destination pages are missing.