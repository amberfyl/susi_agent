# Machine-B GPIO JSON and Runner Contract

Use this contract when adding GPIO to `build_machineB_section_configs.py` and validating it on a Windows SUSI target.

## Design principle

Keep the runner close to the legacy QA `gpio.c`, `gpio_FF.c`, and `gpio_FFFF.c` behavior. Do not introduce loopback maps, fixture schemas, or per-pin policy unless the board or user explicitly requires them.

Minimal flow:

1. `SusiGPIOGetCaps(bank, INPUT_SUPPORT)`
2. `SusiGPIOGetCaps(bank, OUTPUT_SUPPORT)`
3. Save current direction and level
4. With an explicit functional-test switch only, set affected pins to output
5. Write/read back low, then high
6. Restore original level, then original direction
7. Read back the restored state and report recovery separately

## ID separation

Do not derive the public SUSI GPIO ID from the INI tuple group/pin.

- INI key `GPIO00`, `GPIO01`, ... defines public GPIO number `0`, `1`, ...
- Preserve tuple fields 4/5 independently as `tuple_group` and `tuple_pin`
- Compute:
  - `bank_number = gpio_id >> 5`
  - `bank_id = 0x00010000 + bank_number`
  - `bank_bitmask = 1 << (gpio_id & 0x1F)`
- OR per-channel bitmasks into each bank's `expected_mask`

This prevents tuple routing metadata from being incorrectly passed as a SUSI API ID.

## JSON ownership

`build_machineB_section_configs.py` owns `<project>_gpio.json`. The JSON should remain small:

- category/model/source INI metadata
- required channel keys
- per-channel public ID plus tuple group/pin
- per-bank ID and expected mask
- functional check enabled policy
- safety fields requiring an explicit runner switch and restore

Do not use an unhooked helper script as the canonical generator.

## Runner safety

- Read-only mode must perform capability and initial direction/level calls without mutation.
- Mutation requires both JSON enablement and `-EnableFunctionalTest`.
- Never copy or deploy INI or reload the driver when the user says a fixed runtime INI is already active. Pass its path explicitly with `-IniPath`.
- On any exception after mutation starts, attempt emergency restore before `SusiLibUninitialize`.
- Restore level while pins are still outputs, verify it, then restore direction and verify it.

## Remote execution sequence without INI deployment

1. Confirm the fixed target INI exists.
2. Upload only runner, JSON, and synchronized `common_susi.ps1`.
3. Compare SHA-256 locally and remotely.
4. Run read-only validation first.
5. Pull and inspect the timestamped JSON report; do not rely only on process exit code.
6. If capabilities and initial reads pass, run once with `-EnableFunctionalTest`.
7. Pull and inspect low/high readback and restore evidence.

## Acceptance boundary

A low/high API readback proves SUSI API mapping, output latch behavior, and reversible state handling. It does not prove electrical loopback or external pin voltage. State that limitation explicitly unless a fixture or physical observation was used.

## Proven four-pin example

For `GPIO00..GPIO03`, Bank0 expected mask is `0x0000000F`. A successful run should show:

- input/output support includes `0x0F`
- low set/read = `0x00`
- high set/read = `0x0F`
- restored level/direction match their pre-test values
