# BIOS image format fallback + alias completion gate

Use this when voltage/temperature/fan aliases are unexpectedly empty or wrong even though channel_id is correct.

## Symptom pattern
- `HWM.Voltage` channel IDs are correct (probe/DB path OK), but Name/alias is wrong or missing.
- `HWM.Temperature`/`HWM.Fan*` alias remains fallback/blank.
- `*-temperature-name-hints.json` shows `NO_BIOS_IMAGES` despite BIOS screenshots existing as `.jpg/.jpeg`.

## Root cause class
Name backfill path used PNG-only discovery (`bios*.png`) and skipped available BIOS `.jpg/.jpeg` captures.

## Required guardrails
1. Enumerate scoped BIOS/circuit rasters with extension-flexible matching:
   - prefix: `bios*` / `circuit*`
   - extension: `.png/.jpg/.jpeg`
   - case-insensitive.
2. Never derive `NO_BIOS_IMAGES` from `bios*.png` alone.
3. Run separate BIOS-name passes (temperature/fan) even if voltage cache is DONE.
4. Before completion, verify generated output contains non-empty alias where BIOS evidence exists.

## Fast verification checklist
- Cache item count includes jpg/jpeg BIOS files.
- `*-temperature-name-hints.json` has non-empty `by_key` when BIOS health page clearly shows sensor labels.
- `*_HWM.Temperature.ini` and `<project>-pre.ini` show backfilled temperature label (e.g., `TCPU...,CPU Temperature`).
- `*-voltage-alias-bridge.json` evidence image points to actual BIOS image when BIOS labels were used.

## Example (SOM-6883)
- BIOS health labels visible on `bios2.jpg`: `+12V`, `+5V`, `VBAT`, `CPU Temperature`.
- Expected outputs:
  - `HWM.Voltage`: `V120 -> +12V`, `V50 -> +5V`, `VBAT -> VBAT`
  - `HWM.Temperature`: `TCPU -> CPU Temperature`
