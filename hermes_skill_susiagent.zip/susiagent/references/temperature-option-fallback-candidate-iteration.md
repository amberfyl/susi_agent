# HWM.Temperature option fallback candidate iteration contract

Scope
- Applies to `/susiagent` A-side orchestration when SuperIO `HWM.Temperature` probe is all-ERR and option fallback is enabled.

Contract
1) Baseline gate
- Parse current probe report first.
- If baseline is not all-ERR, return `BASELINE_NOT_ALL_ERR` and do not mutate temperature tuples.

2) Candidate loop (ordered)
- Candidate unit is `(io_port, options)`.
- Apply one candidate to both artifacts in the same round:
  - `<PROJECT>_HWM.Temperature.ini`
  - `<PROJECT>-pre.ini`
- After apply, run deploy/reload/reprobe through runner command when provided.
- Re-evaluate probe; stop immediately at first non-all-ERR result.

3) Outcomes
- `CANDIDATE_VALIDATED_PASS`: a candidate produced non-all-ERR probe; keep that tuple and stop.
- `ALL_CANDIDATES_FAILED`: all candidates were tried and still all-ERR.
- `CANDIDATE_PREPARED_NEEDS_VALIDATION`: candidate was written but no runner/reprobe executed in-process.

4) Matrix/route recording
- Persist structured fallback outcome in section-matrix metadata.
- Append route marker `+TEMP_OPTION_FALLBACK` when fallback path is triggered.

Operational notes
- Candidate list is intentionally append-only and can be expanded gradually over time; no requirement to predefine a complete set in one session.
- Keep ordering stable: most-likely tuples first to minimize deploy/reprobe rounds.
- If tuple format is invalid, fail fast at parse stage rather than silently skipping.
