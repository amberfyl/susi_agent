# GPIO INI key zero-padding guard

Context
- User corrected generated GPIO INI key format.
- Wrong: `GPIO0=`, `GPIO1=`, `GPIO2=`
- Required: `GPIO00=`, `GPIO01=`, `GPIO02=` (two-digit zero-padded sequence).

Rule
- When rendering `[GPIO]` section item keys from numeric suffixes, normalize `GPIO<n>` to `GPIO{n:02d}`.
- Keep already-correct keys unchanged (`GPIO02` stays `GPIO02`).
- Only normalize canonical GPIO keys (`^GPIO\d+$`), do not rewrite unrelated names (`SIO_GPIO1`, `GPI01`).

Quick check examples
- `GPIO0 -> GPIO00`
- `GPIO1 -> GPIO01`
- `GPIO12 -> GPIO12`
- `GPIO02 -> GPIO02`

Why this matters
- Downstream tooling and expected golden format assume fixed-width GPIO keys, so single-digit keys cause avoidable diffs and validation friction.
