# SMBus gating and channel-fill policy

Use this when `/susiagent` generates SMBus rows.

## 1) Spec gate (hard gate)
- If `spec.features.smbus` is `false`: SMBus section is disabled (`SECTION_EMPTY`).
- If `spec.features.smbus` is `true`: continue with CPU/probe-driven SMBus generation.

## 2) Keep rich SMBus context in spec
- `features.smbus` remains boolean for compatibility.
- Preserve non-boolean context under `feature_details.smbus`.
- Most important field: `feature_details.smbus.chip` (may contain EC/model/description text).

## 3) Intel rule
- Channel1 is fixed (`hw=0x00000001`, `channel=0`, `io_port=0`, `option=0xA0000000`).
- Channel2+ is from full probe `SMBUS_OEMn ... EXISTS`:
  - `OEM0 -> Channel2`, `OEM1 -> Channel3`, ...
  - channel field is `0x80000000 + n`.
  - hw field uses ProductChip `hardware_id`.

## 4) AMD rule
- No EPYC pre-filter: do not short-circuit SMBus generation solely because CPU name contains `EPYC`.
- Channel1 idx is dynamic from SPD-idx probe.
- If Channel1 idx is `0..3` and SMBus is EC-related (`feature_details.smbus.chip` contains `EC`):
  - emit Channel2 with fixed idx=4 (`channel=0x80000004`, hw=ProductChip `hardware_id`, io/option fixed).
- If Channel1 idx is `4`:
  - do not emit Channel2.

## 5) Rendering tuple reminder
- SMBus row rendering shape: `hw,channel,io_port,option,disp_name`.
- For generated channels here, `io_port=0` and `option=0xA0000000`.
