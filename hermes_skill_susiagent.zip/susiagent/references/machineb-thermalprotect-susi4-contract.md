# Machine-B ThermalProtect / Susi4 contract

## Canonical IDs from `Susi4.h`

ThermalProtect has four API channel IDs, distinct from INI tuple channels:

```text
TPCH0 -> SUSI_ID_THERMAL_PROTECT_1 -> 0x00000000
TPCH1 -> SUSI_ID_THERMAL_PROTECT_2 -> 0x00000001
TPCH2 -> SUSI_ID_THERMAL_PROTECT_3 -> 0x00000002
TPCH3 -> SUSI_ID_THERMAL_PROTECT_4 -> 0x00000003
```

For the generated INI, the second tuple field remains configuration/EC data:

```text
TPCH0..TPCH3 -> 0x80000000..0x80000003
```

Do not pass the `0x80000000 + n` tuple field directly to the ThermalProtect API. Preserve it as `tuple_channel`; emit the API ID separately as `thermal_api_id`.

## Read and guarded SetConfig validation

Default Machine-B runner behavior remains read-only. The optional `-EnableSetConfigTest` path may validate SetConfig without issuing a thermal event:

1. Read the original config with `GetConfig`.
2. Set a disabled safe config (`SourceId=0`, `EventType=0xFF`, temperatures zero).
3. Read back and require both `SourceId=0` and `EventType=0xFF` before treating the safe transition as successful.
4. For an original `SHUTDOWN` or `POWEROFF` config, leave the channel in the verified safe state; never restore that power-action config automatically.
5. For other original configs, restore the exact original fields and verify the restore readback.
6. Never call thermal event trigger/clear APIs. Do not infer safety if SetConfig or its safe readback fails.

Use the APIs declared in `Susi4.h`:

```c
SusiThermalProtectionGetCaps(Id, ItemId, &value);
SusiThermalProtectionGetConfig(Id, &config);
SusiThermalProtectionSetConfig(Id, &config); // explicit switch only
```

Capability item IDs:

```text
0x00000000 = SUSI_ID_TP_EVENT_SUPPORT_FLAGS
0x00000001 = SUSI_ID_TP_EVENT_TRIGGER_MAXIMUM
0x00000002 = SUSI_ID_TP_EVENT_TRIGGER_MINIMUM
0x00000003 = SUSI_ID_TP_EVENT_CLEAR_MAXIMUM
0x00000004 = SUSI_ID_TP_EVENT_CLEAR_MINIMUM
```

Support flag bits:

```text
bit 0 = shutdown
bit 1 = throttle
bit 2 = poweroff
```

`GetConfig` returns:

```text
SourceId                 -> HWM temperature API ID (0x000200xx)
EventType                -> shutdown/throttle/poweroff/none
SendEventTemperature     -> 0.1 Kelvin
ClearEventTemperature    -> 0.1 Kelvin
```

## Safety and verdict policy

The default Machine-B runner is read-only: `GetCaps` and `GetConfig` only. The guarded SetConfig round-trip is available only with explicit `-EnableSetConfigTest`; it may set `EventType=NONE`, verify the disabled state, and restore only non-power-action originals. A `SHUTDOWN`/`POWEROFF` original is intentionally left disabled after successful verification. Never call trigger/clear, shutdown, throttle, or poweroff operations as part of this SetConfig check.

Recommended initial layers:

```text
L1 configuration = INI/JSON and TPCH0..TPCH3 mapping valid
L2 capability    = GetCaps status for each Thermal ID/item
L3 API           = GetCaps/GetConfig call status
L4 readback      = SourceId/EventType/temperature fields valid
L5 functional    = CONDITIONAL (no stimulus)
L6 recovery      = N_A unless an approved recovery test exists
```

Keep `sw_verdict` based on L1-L4 and CI exit code; keep functional/recovery uncertainty in `dqa_verdict`/`result`.

## Implementation checklist

1. Parse `[ThermalProtect]` and preserve raw tuple fields.
2. Map TPCH index to `thermal_api_id = index`, never tuple field.
3. Generate JSON with both `tuple_channel` and `thermal_api_id`.
4. Implement a runner using the Susi4 thermal APIs and status-code evidence.
5. Validate `SourceId` against the HWM temperature namespace.
6. Report unsupported IDs as capability/API evidence, not as a guessed mapping failure.
7. Deploy/reload/test only with the standard backup -> restore -> reload -> hash-verification closure.
