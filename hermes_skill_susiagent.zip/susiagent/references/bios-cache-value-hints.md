# BIOS cache value hints (fan/temperature/voltage)

When building or refreshing `<PROJECT>-bios-image-cache.json`, persist not only labels but also visible real-time values from BIOS images.

## Required per-item fields
- `voltage_label_hints`: deduped voltage labels (`+12V`, `+5VSB`, `VBAT`, ...)
- `voltage_value_hints`: array of `{label,value,unit}` where unit is `V` or `mV`
- `temperature_value_hints`: array of `{label,value,unit}` where unit is `C`
- `fan_value_hints`: array of `{label,value,unit}` where unit is `RPM`

## Producer/consumer contract
- Producer step (vision): extract labels + values from scoped BIOS rasters (`bios*.png|jpg|jpeg`).
- Consumer step (generation/validation): read value hints directly from cache; do not require a second ad-hoc image pass.
- If cache already has `analysis_text` but value arrays are missing/empty, treat as incomplete cache and rerun vision producer for affected items.

## Parsing tolerance
- Accept common forms like:
  - `CPU FAN1 Speed: 2480 RPM`
  - `VCORE=1.015 V`
  - `+5VSB 5020mV`
  - `CPU Temperature 54 C`
- Keep values evidence-only; do not guess missing numbers.

## Verification use
- Functional validation report proves API read/control behavior.
- BIOS value hints support value-correlation checks (with tolerance and no-fan N/A policy), not strict equality across different timestamps.
