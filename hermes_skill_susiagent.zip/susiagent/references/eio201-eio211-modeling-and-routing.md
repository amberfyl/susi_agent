# EIO-201 / EIO-211 data-model and routing guard

Context
- Some platforms expose `EIO-211` in forms/specs while `config_new.db` ProductChip may only have `EIO-201` and `EIO-300` rows.
- `EIO-201` and `EIO-211` can share the same `hardware_id` (`0x30313640`) but are different chip generations/identities.

Do
1. Keep `ProductChip.chip_name` atomic (single value per row).
   - Good: `EIO-201`, `EIO-211`
   - Bad: `EIO-201/EIO-211`
2. Prefer DB/schema fix over skill-only workaround:
   - Add explicit `ProductChip` row(s) for `chip_name=EIO-211` per product family as needed.
   - Keep both generations independently queryable under fixed key `(product_name, chip_name)`.
3. Treat shared `hardware_id` as compatibility evidence, not identity collapse.
4. For EIO-211 EC cases, do **not** fallback to `EIO-300` just to bypass missing ProductChip rows; that can incorrectly trigger `NCT6694B` section routing.

Optional schema note
- If lifecycle relationship must be represented (new/old generation), store it in a dedicated relation table (e.g. `chip_relationship`) rather than encoding two chip names into one `chip_name` cell.

Verification checklist
- `ProductChip` has separate rows for `EIO-201` and `EIO-211` where required.
- Section matrix route for EIO-211 EC case does not unexpectedly switch to `NCT6694B` unless platform is truly EIO-300 compound route.
- No generated workflow relies on slash-joined chip names.