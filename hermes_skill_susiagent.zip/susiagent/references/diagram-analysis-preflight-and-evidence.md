# Diagram Analysis Preflight and Evidence Workflow

Use this whenever `/susiagent` must interpret BIOS captures, schematic rasters, or circuit PDFs.

## Mandatory preflight

1. Read the current project rule source before any image reasoning:
   `/home/company2/AIagent_susi/AnalysisSKill/bios_circuit_image_analysis_rule.md`
2. Treat that file as authoritative over remembered behavior, context summaries, and condensed skill notes.
3. Determine the chip-aware target signal pattern and enumerate the complete `target_signal_set` before mapping.

## PDF and raster workflow

1. Search the schematic/PDF for the selected target signal pattern or keywords.
2. Record every matching page and region; do not stop after the first port group or first visible cluster.
3. Render focused high-resolution crops that clearly show signal labels, wire bends, junctions, package pins, and function labels.
4. Save crops and page/keyword evidence inside the project directory. `/tmp` may be used for intermediate work only, never as the sole evidence location.
5. Use low-resolution full-page renders only for navigation. Never accept final mapping from unreadable whole-page imagery.
6. Trace each target signal along the actual electrical wire to the endpoint. Text proximity, OCR order, row alignment, and signal suffix are not connection evidence.
7. Emit either a confirmed mapping or an explicit ambiguity result for every member of `target_signal_set`.

## Chip-aware scope examples

- `NCT6694B` / `EIO-300`: all matching `EC_P*_GPIO*` ports, including P1, P2, P3, and later ports when present. Never hard-code P1-only scope.
- `NCT61xxD`: default to `SIO_GPIO*`.
- Use the current rule file for alternative patterns, owner-chip decisions, and ambiguity handling.

## Required output layers

Keep these fields separate:

- external signal/net
- chip GPIO function label
- normalized group/bit
- package pin or coordinate, when readable
- evidence crop/page
- status and ambiguity reason

Examples of label normalization only:

- `GPIO34` → group 3, bit 4
- `GPIOA5` → group 10, bit 5
- `GPIOD0` → group 13, bit 0

Normalization does not prove connectivity; connectivity still requires wire tracing.

## Completion checks

Before generation proceeds, verify:

- the current rule file was read in this run;
- target pattern and complete target count are recorded;
- every target has mapping or ambiguity;
- no unrelated FAN/BEEP/LED signal leaked into GPIO output;
- evidence crops are readable and preserved in the project;
- stale generated GPIO artifacts are overwritten after a corrected trace.

## Common failure modes

- Reading only the skill summary and skipping the project rule file.
- Rendering one whole schematic page and asking vision to infer tiny labels.
- Stopping after eight P1 signals when P2 or later ports exist.
- Deriving group/bit from `EC_Pn_GPIOm` suffix instead of the traced chip function label.
- Claiming completion while evidence exists only in `/tmp`.
