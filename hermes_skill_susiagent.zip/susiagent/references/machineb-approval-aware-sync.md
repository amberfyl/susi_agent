# Machine-B approval-aware sync pattern (2026-09-08)

When this applies
- Copying scripts/JSON/INI to target-B (`172.22.12.77`) via `scp`/`ssh` where Hermes policy prompts for side-effect approval.

Observed behavior
- Approval is evaluated per side-effect command.
- One approved `scp` does not imply subsequent `scp` commands are approved.
- Partial sync can occur (e.g., `config` uploaded, `ini` blocked).

Durable execution pattern
1) Split sync into small independent batches by destination/use:
   - shared scripts -> `verify/`
   - JSON -> `verify/<PROJECT>/config/`
   - INI -> `verify/<PROJECT>/ini/`
2) After each batch, verify remote state immediately (`dir` for target folder) and report exact files present.
3) If a command is policy-denied, stop that branch, report blocked step, and request explicit consent for only the remaining batch.
4) Resume from the missing batch only (do not re-upload already confirmed files).
5) Finish with a final remote directory check for both `config` and `ini`.

Why this helps
- Reduces repeated rework after partial approvals.
- Gives user deterministic progress visibility despite per-command approval gates.
- Keeps `/susiagent` Machine-B deployment idempotent and restartable.
