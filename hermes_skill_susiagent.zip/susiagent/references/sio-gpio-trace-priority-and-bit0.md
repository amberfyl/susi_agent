# SIO GPIO trace-first + bit=0 rendering guard

When this applies
- NON-EC/SIO projects (for example NCT6126D/NCT61xxD family) where `spec.gpio` may be empty.

Core rule
- Do not treat empty `spec.gpio` as permission to finalize GPIO from `config_new.db` GPIO rows alone.
- For SIO route, run/consume circuit-trace artifact first (`<PROJECT>-gpio-trace.json`) and use DB as template/default provider only.

Recommended source priority for GPIO rows
1) Confirmed circuit trace contract (`group`, `bit`, signal evidence)
2) `spec.gpio` (if explicitly populated)
3) DB baseline fallback (last resort)

Image scope + evidence composition guard for SIO GPIO tracing
- Restrict GPIO tracing assets to `circuit*` sources only (exclude `bios*`).
- In a single trace run, include BOTH:
  - existing `circuit*.png|jpg|jpeg` rasters
  - rendered pages from `circuit*.pdf` (when present)
- Treat PDF pages as evidence complement, not only a fallback when rasters are missing.

Target-signal-set guard (R-016/R-017 alignment)
- Build one `target_signal_set` before mapping; do not mix all GPIO-like nets together.
- Chip-aware default for SIO (`NCT6126D/NCT6116D/NCT6106D/NCT6776D`) is `SIO_GPIO*`.
- If default pattern has no hits, try alternate naming patterns and choose exactly one evidence-consistent set.
- If multiple sets remain plausible, mark `GPIO_SIGNAL_SCOPE_AMBIGUOUS` and stop auto-confirmation.
- Keep `OUT_OF_SCOPE` nets out of output (FAN/BEEP/LED/PORT80 helpers stay excluded even if nearby pin labels include `GP*`).

EC vs SIO count-source rule (must enforce in code path)
- EC route: GPIO item count is driven by probe/spec (`spec.gpio.count` or `len(spec.gpio.pins)`) and then rendered with DB defaults/templates.
- SIO/NON-EC route: GPIO item count is driven by confirmed circuit-trace evidence (`target_signal_set`), not by DB row count.
- SIO must not finalize from DB GPIO rows when trace evidence exists; DB is template/default provider only.

Section-availability troubleshooting (common confusion)
- `ProductChip` hit (for example `AIMB + NCT6126D` exists) only proves identity/hwid lookup is valid.
- It does NOT imply every section can be generated.
- `SECTION_EMPTY` can still be correct when section tables have no rows for that `hardware_id` (for example `VGA.Backlight`) or when probe evidence is unsupported/absent (for example `HWM.Fan*` all unsupported).

Rendering pitfall (must-have)
- Preserve numeric zero fields during line render.
- `group=0` or `bit=0` are valid values and must render as `0`, not empty strings.
- Use `None` checks (`is None`) rather than truthy checks when serializing numeric fields.

Verification checklist
- `<PROJECT>-gpio-trace.json` exists and reports confirmed items.
- `<PROJECT>-section-matrix.json` marks GPIO with trace route (for example `NON_EC+GPIO_TRACE`) and `GENERATED`.
- Generated GPIO ini contains rows with explicit zero bits where expected (e.g., `...,1,0,`).
- Key canonicalization is applied for SIO traces: `SIO_GPIO<n>` must be rendered as `GPIO<n>` in output INI keys; `SIO_GPIO*` is circuit evidence text, not final INI key naming.
- Per-signal dedup uses stable canonical key (`GPIO<n>`) and keeps the highest-quality evidence row (e.g., `GPxy`-parsed mapping) when multiple trace candidates exist for the same signal; lower-confidence generic `GPIO` duplicates must not appear as extra rows.
