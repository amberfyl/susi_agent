# Fan pairing minimal JSON contract (machine-first)

Use this when handing vision analysis back into pipeline code.

Minimal required shape
```json
{
  "topology_status": "FAN_ONE_TO_ONE_CONFIRMED",
  "items": [
    {"key": "FCPU", "fanin_idx_candidate": 0, "control_idx_candidate": 0},
    {"key": "FSYS", "fanin_idx_candidate": 1, "control_idx_candidate": 1}
  ]
}
```

Allowed status values
- FAN_ONE_TO_ONE_CONFIRMED
- FAN_ONE_TO_MANY_CONFIRMED
- FAN_PAIRING_NEEDS_FANCONTROL_EVIDENCE
- FAN_PAIRING_AMBIGUOUS

Core rules
- Keep output minimal: only `topology_status` + `items` unless caller explicitly asks for extra metadata.
- `items[].key` accepts `FCPU`, `FCPU2`, `FSYS`, `FOEM<n>`.
- `control_idx_candidate` may repeat across multiple keys for one-to-many control.
- If incoming analysis is verbose, parser should normalize and write back this minimal shape.
- NON-EC/SIO fallback semantics: BIOS may seed fan key/count. Pairing contract is preferred for final `HWM.Fan.Control` channels; when pairing is missing, generator may fallback to one-to-one control mapping from resolved `HWM.Fan` channels and label matrix status as fallback.
