# Machine-B HWM.Voltage JSON and runner contract

## When this applies

Use this contract when adding or validating a Machine-B section runner for `HWM.Voltage`, especially after the Temperature runner has established the common execution pattern.

## Source-of-truth and generation

1. Generate the section JSON from the canonical section matrix and generated section INI with `build_machineB_section_configs.py`.
2. Do not hand-author the project JSON as the normal workflow; manual JSON is only a debugging fixture and must not be presented as the generated artifact.
3. Keep generated artifacts in the canonical project directory and verify the builder output path after generation.
4. Validate the builder with Python compilation plus assertions over each expected channel/API mapping.

## ID namespace separation

The INI tuple channel is a configuration tuple field and is not necessarily the public SUSI API ID. For Voltage, the builder must preserve the tuple channel separately and derive the public API ID from the canonical Voltage namespace:

- `VCORE` -> `0x00021000`
- `V50` / `+5V` -> `0x00021004`
- `V120` / `+12V` -> `0x00021005`
- `VBAT` -> `0x00021008`

Unknown voltage keys must fail generation rather than copying the INI tuple channel into `api_id`. Alias/name fields only affect display names; they must not change the item identity selected from report/channel semantics.

## Runner skeleton markers

New section runners should expose the reusable stages explicitly in comments so a reviewer can distinguish the common skeleton from Voltage-specific policy:

1. config and section gate;
2. SUSI initialization and capability gate;
3. per-channel sampling loop;
4. verdict mapping, report writing, and exit code.

Use stable `[RUNNER SKELETON]` markers near those stages. The runner must load the generated JSON, validate the paired INI/hash when applicable, sample each configured channel, and emit the standard SW/DQA verdict fields rather than embedding channel mappings in PowerShell.

## Verification boundary

Local generation verification is not remote execution verification. Report these separately:

- local: Python syntax, builder output, JSON schema/mapping assertions;
- remote: file sync/hash, runtime INI deployment, SUSI4 driver reload, runner execution, pulled timestamped report, and restoration of the original runtime INI.

Do not claim Voltage hardware/API validation from local JSON generation alone. For a remote run, use the established backup -> deploy -> reload -> run -> pull report -> restore -> reload/verify closure sequence.

## Tested remote execution recipe

Use this sequence when the user explicitly authorizes a real Machine-B run:

1. Resolve the remote workspace with a read-only inventory first. Do not assume the workspace is under the probe tools directory; the validated target used `C:\Users\susiaa\Desktop\machineB_validation` for runners/configs and `C:\Users\susiaa\Desktop\reload driver\reload_susi4_driver.ps1` for driver reload.
2. Confirm local SHA-256 values for the runner, `common_susi.ps1`, section INI, and generated JSON.
3. Back up `C:\Windows\SUSI\<PROJECT>.ini` before deployment and record the backup hash. Use a unique per-section backup name such as `<PROJECT>.ini.backup_before_voltage`.
4. Copy artifacts individually, then verify each remote hash. Keep state-changing SCP/SSH operations separate so an approval or failure is attributable to one artifact.
5. Deploy the paired section INI to the runtime path and verify that its SHA-256 equals the JSON `source_ini.sha256`.
6. Parse the PowerShell runner remotely before execution using `System.Management.Automation.Language.Parser`; require `PS_PARSE_OK`.
7. Reload SUSI4 explicitly with the remote reload script and require the device transition `OK -> disabled/error -> OK`, ending with `CM_PROB_NONE`.
8. Run the runner with explicit paths; do not rely on model-derived defaults when testing a section artifact:

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
& 'C:\Users\susiaa\Desktop\machineB_validation\run_hwm_voltage_validation.ps1' `
  -ConfigPath 'C:\Users\susiaa\Desktop\machineB_validation\<PROJECT>_voltage.json' `
  -IniPath 'C:\Users\susiaa\Desktop\machineB_validation\<PROJECT>_HWM.Voltage.ini' `
  -OutDir 'C:\Users\susiaa\Desktop\machineB_validation\out'
```

9. Pull the timestamped report before cleanup. Validate all expected channels have `status_code=0x00000000`, `success_rate=1`, `in_range=true`, and `span_ok=true` when the run is expected to pass.
10. Interpret the result correctly: read-only Voltage validation is normally `result=CONDITIONAL`, `sw_verdict=PASS_SW`, `dqa_verdict=PENDING_DQA`, and exit code `0`; `CONDITIONAL` here means no load-stimulus profile was applied, not that API/readback failed.
11. Restore the original runtime INI, reload SUSI4 again, then verify both the restored hash and final device state (`Status=OK`, problem code `0`/`CM_PROB_NONE`).

For complex PowerShell over SSH, use UTF-16LE Base64 `-EncodedCommand` instead of nested shell quoting. This avoids silently passing literal PowerShell text through the Windows OpenSSH command shell. Preserve the raw output needed for evidence, but summarize only the final status in the user-facing response.

## Example evidence pattern

A successful four-channel MIO-2375 run produced:

- `VCORE` (`0x00021000`): 10/10, 1260-1720 mV, span 460 mV;
- `V50` (`0x00021004`): 10/10, 5040-5050 mV, span 10 mV;
- `V120` (`0x00021005`): 10/10, 11890-11930 mV, span 40 mV;
- `VBAT` (`0x00021008`): 10/10, 2990-3000 mV, span 10 mV.

The report showed `L1`-`L4=PASS`, `L5=CONDITIONAL`, `L6=N_A`, `PASS_SW`, and exit code `0`; the runtime INI was restored and SUSI4 finished `OK/CM_PROB_NONE`.

## Related contract

Temperature uses the same namespace-separation and remote-closure principles; see `references/machineb-temperature-api-id-vs-ini-channel.md` and the Machine-B runner rules in `SKILL.md`.
