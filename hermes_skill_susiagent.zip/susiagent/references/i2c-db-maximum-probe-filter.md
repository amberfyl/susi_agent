# I2C DB Maximum-Set / Full-Probe Filtering

## Rule

Treat `config_new.db` I2C rows as the maximum topology, not the board's active runtime capability. When a full probe report is available, generate the I2C section from the intersection:

```text
DB maximum rows ∩ full-probe supported buses
```

Do not modify or delete DB rows merely because a particular board does not expose every possible I2C bus.

## MIO-2375 evidence pattern

The probe can report:

```text
I2C_EXTERNAL (Id=0) -> supported
I2C_OEM0 (Id=1)     -> supported
I2C_OEM1 (Id=2)     -> not supported
I2C_OEM2 (Id=3)     -> not supported
I2C_SUPPORTED mask  -> 0b00000011
```

The DB may still contain four rows (`I2C_EXTERNAL`, `I2C_OEM0`, `I2C_OEM1`, `I2C_OEM2`). The generated INI must contain only Channel1/Channel2, with encoded channels `0x80000000` and `0x80000001`.

`Devices found: (none)` does not mean the bus is unsupported; it means the supported bus had no detected slave device. Filter on the bus support/skip status and capability IDs, not on device enumeration count.

## Implementation contract

- Parse supported buses from the full probe parser output (`i2c_buses`).
- Prefer exact DB `report_name` ↔ probe bus-name matching (`I2C_EXTERNAL`, `I2C_OEM0`, etc.).
- If a DB row has no report name, fall back to decoded encoded-channel ID ↔ probe `probe_id` matching.
- Only apply the intersection when probe bus data is present. If no probe bus list is available, preserve the prior DB maximum-set behavior rather than silently emitting an empty section.
- Preserve the encoded INI tuple channel separately from public API IDs.
- Record filtered decoded IDs in diagnostic metadata (for example `i2c_skipped_oem_ids`).

## Regression coverage

Add a test with four DB rows and a probe containing only `I2C_EXTERNAL` and `I2C_OEM0`. Assert that the result contains exactly Channel1/Channel2 and excludes the rows for IDs 2/3. Keep the existing no-probe test to prove DB maximum-set fallback remains compatible.

## Verification checklist

1. Read the probe report's `I2C Buses` section and `I2C_SUPPORTED mask`.
2. Inspect generated `_<project>_I2C.ini`; count channels and decode tuple IDs.
3. Rebuild `<project>_i2c.json`; its `required_channels` must match the filtered INI.
4. Run the I2C contract tests and the complete local unittest suite.
5. Treat any prior Machine-B report generated before this change as stale; remote validation requires a newly authorized run after regeneration.
