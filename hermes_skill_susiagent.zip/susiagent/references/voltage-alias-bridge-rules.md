# Voltage alias bridge rules (EC path)

Use this note when HWM.Voltage DB rows and BIOS labels do not 1:1 align.

## Durable rules
- Preserve left-side item key from DB/report semantics (`report_name` + `channel_id`).
- Use BIOS label matching to fill `disp_name` (Name field), not to rewrite keys.
- Disambiguate `+5V` vs `+5VSB` by `report_name` first, then BIOS labels.
- Recognize `+9V/9V` as valid BIOS voltage labels and value hints.

## Controlled exceptions
1) VBAT promotion
- If BIOS clearly shows `VBAT` and the only candidate row is `HWM_VOLTAGE_VBATLI`, and there is no true `VBAT` key in section:
  - Promote key `VBATLI -> VBAT` once.
- Do not apply if a true `VBAT` row already exists.

2) Singleton remainder mapping
- If alias bridge ends with exactly one unresolved row AND BIOS has exactly one unused known rail label (`+12V`, `+9V`, `+5V`, `+5VSB`, `+3.3V`, `VBAT`):
  - Assign that label to the unresolved row.
  - Mark reason as `BIOS_SINGLETON_REMAINDER_MATCH`.

## Evidence priority
1. Parsed measured labels from BIOS analysis text (`VOLTAGE_VALUE: ...`).
2. Structured `voltage_value_hints` if present.
3. Generic label hints.

## Regression checks
- Distinct rails must not collapse into same key (e.g., `V5SB` must not become `V50`).
- If both 5V and 5VSB exist in DB rows, output must retain separate keys.
- If VBAT is only exposed via VBATLI report_name and BIOS shows VBAT, output key should be VBAT.
