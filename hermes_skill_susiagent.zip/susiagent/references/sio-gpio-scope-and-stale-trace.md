# SIO GPIO scope + stale-trace guard (AIMB-289 pattern)

When chip route is SuperIO (`NCT6126D/NCT6116D/NCT6106D/NCT6776D` family), GPIO auto-trace must follow `bios_circuit_image_analysis_rule.md` R-016/R-017 style scope discipline.

Key lessons
- Do not widen scope to nearby non-target nets (`SIO_LED_*`, `ESPI_*`, FAN/BEEP) just because they share the same chip page.
- Build `target_signal_set` first, then trace only that set.
- For SIO on these chips, default target naming is `SIO_GPIO*` unless user explicitly overrides.
- Source ingestion must include both:
  1) existing `circuit*.png|jpg|jpeg`
  2) rendered pages from `circuit*.pdf` (if present)
  The PDF path is not only fallback; it is co-evidence.
- Guard against stale artifacts: regenerate `<PROJECT>-gpio-trace.json` when any `circuit*` source is newer, or when trace content does not match chip-aware scope (e.g., no `SIO_GPIO*` items for NCT6126D route).

Observed failure mode (fixed pattern)
- Previous trace artifact contained `SIO_LED_*` / `ESPI_*` mappings (`GPIO10..17`, `GPIO80..87`) and got reused.
- User-provided focused crop `circuit_289_GPIO.png` showed correct target mappings:
  - `SIO_GPIO0 -> GP50`
  - `SIO_GPIO1 -> GP51`
  - `SIO_GPIO2 -> GP42`
  - `SIO_GPIO3 -> GP43`
  - `SIO_GPIO4 -> GP44`
  - `SIO_GPIO5 -> GP45`
  - `SIO_GPIO6 -> GP46`
  - `SIO_GPIO7 -> GP47`

Execution checklist
1. Confirm chip route is SIO (non-EC) and pick chip-aware default pattern.
2. Enumerate/prepare both `circuit*` rasters and `circuit*.pdf` rendered pages.
3. Build/validate `target_signal_set` before writing trace output.
4. Reject out-of-scope items from trace output.
5. Rebuild stale trace artifacts before `generate`.
6. Verify section-matrix for GPIO route/status and inspect generated `_GPIO.ini` key/group/bit set.
