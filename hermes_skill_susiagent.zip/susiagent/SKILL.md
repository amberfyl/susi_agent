---
name: susiagent
description: "SUSI pipeline with two explicit modes: run the existing generation/convergence workflow by default, or use --all with a confirmed host for safe-default Machine-B validation through rollback."
version: 1.2.0
author: Hermes Agent
license: MIT
platforms: [linux, windows]
---

# SusiAgent

Reference updates
- Post-first-validation fallback convergence for expected sections whose APIs fail on every channel: route-only whitelist, first-success stop, evidence, and project-override rules: `references/post-validation-route-fallback.md`
- Hermes runtime profile for deterministic SUSI execution: use Luna/medium for routine fixed-flow runs, raise reasoning for first-machine smoke or anomalies, reserve Sol/xhigh for code/design/debug work, and tune compression threshold separately from the provider-resolved context cap: `references/hermes-execution-model-and-context-profile.md`
- Public mode contract + post-INI deterministic Machine-B orchestration: `/susiagent <PROJECT>` preserves the existing probe/vision/generation workflow, including required generation-owned v2 convergence, and stops after INI/matrix/section-JSON generation without entering P6-P12 full validation; `/susiagent <PROJECT> --all --host <HOST> [--user <USER>]` continues through safe-default P5-P12 execution and recovery. After `/susiagent` has produced the INI/matrix artifacts, keep subsequent work out of PDF/probe/DB/INI-generation design; generate validation JSON deterministically, use a tested 14-section registry and dry-run manifest, deploy the full INI once, invoke the target-installed reload BAT once, run isolated section processes, aggregate only fresh reports, and restore the prior runtime state with a separate recovery reload. Keep dependency-coupled fan validation adjacent (`HWM.Fan` immediately followed by `HWM.Fan.Control`). Preserve non-zero runner exits as section evidence rather than misclassifying them as SSH transport failure. `--all` is current-turn authorization for this safe lifecycle only and never enables control/fixture/functional/SetConfig/stimulus/write opt-ins. Before P12, require a positively identified Machine-B host/user; never infer the target from an unrelated SSH alias. When describing “local tests,” explicitly identify them as WSL Python/file-contract or fake-transport tests that require neither Windows SUSI nor Machine-B execution. Treat `run_two_section_validation.py` as isolation-only: `references/post-ini-deterministic-validation-orchestrator.md`
- Machine-B complete-INI coexistence validation: deploy the full pre-INI once, reload once, run section runners sequentially, use split INIs only for isolation/convergence, and treat expected split-vs-full source hashes as warning-only by default: `references/machineb-full-ini-single-reload-validation.md`
- Screen-control schematic BL label disambiguation: distinguish connector/socket evidence from inductor/part annotations and trace PWM vs enable paths: `references/screen-control-schematic-bl-label-disambiguation.md`
- Machine-B current-runtime read-only diagnostics: no INI deploy/reload, temporary live-channel JSON, pre/post hash proof, and API-vs-functional interpretation: `references/machineb-current-runtime-readonly-diagnostics.md`
- Intel SMBus Channel2+ full-probe mapping notes: `references/intel-smbus-channel2-full-probe.md`
- SIO GPIO trace-first + bit=0 rendering guard notes: `references/sio-gpio-trace-priority-and-bit0.md`
- SMBus EC-Intel Channel1 override + SIO-empty short-circuit: `references/smbus-ec-intel-override-and-sio-empty.md`
- Partial section feasibility fallback (AIMB-289 example): `references/partial-section-feasibility-fallback.md`
- NON-EC/SIO no-request-form feasibility mode: `references/non-ec-sio-no-request-form-feasibility.md`
- WSL->Windows PowerShell SSH/SCP bridge for target-B runs: `references/wsl-windows-powershell-ssh-bridge.md`
- SSH read-only inventory before host-key remediation: `references/ssh-readonly-inventory-before-hostkey-remediation.md`
- Mandatory BIOS/schematic rule preload, keyword search, high-resolution evidence crops, complete target-set tracing, and completion checks: `references/diagram-analysis-preflight-and-evidence.md`
- EC_P* GPIO cross-reference tag interpretation (when `<n>` is net reference ID, not page jump): `references/ec-p-crossref-tag-interpretation.md`
- NCT6694B GPIO target-signal lock (all `EC_P*_GPIOn` ports vs NCT61xxD `SIO_GPIOn`): `references/nct6694b-ec-p1-gpio-pattern.md`
- EC_P1 page-jump missing-destination hard-stop (single-page/source-incomplete cases): `references/ec-p1-pagejump-missing-destination-hard-stop.md`
- Machine-B per-section JSON + split fan runners wiring: `references/machineb-section-json-and-split-runners.md`
- Machine-B fan minimal validation mode (read robustness + control RPM delta): `references/machineb-fan-validation-minimal-mode.md`
- Machine-B SW/DQA dual-verdict + CI exit-code policy: `references/machineb-sw-dqa-dual-verdict-and-exit-policy.md`
- Machine-B approval gate + fancontrol enabled config pitfall: `references/machineb-approval-and-fancontrol-enabled.md`
- Machine-B SW/DQA verdict split + CI exit-code contract: `references/machineb-sw-dqa-verdict-split.md`
- Compaction no-op + remote side-effect consent gate: `references/compaction-noop-and-sideeffect-consent.md`
- Machine-B approval-aware incremental sync (partial-approval recovery): `references/machineb-approval-aware-sync.md`
- BIOS cache value-hints contract (fan/temperature/voltage labels + values): `references/bios-cache-value-hints.md`
- GPIO INI key zero-padding guard (`GPIO00` format): `references/gpio-ini-key-zero-padding.md`
- Configuration DB schema migration audit: `references/config-schema-migration-audit.md`
- Host override + shorthand chip normalization runbook: `references/host-override-and-shorthand-chip-normalization.md`
- All-sections intent + non-`<PROJECT>.pdf` input handling: `references/all-sections-intent-and-nonproject-pdf.md`
- SuperIO HWM Voltage/Temperature v2 auto-convergence loop (single-command close): `references/v2-auto-convergence-loop.md`
- Project path canonical-output lock (avoid CASES root artifact drift): `references/project-path-canonical-output-lock.md`
- Local-probe non-destructive rerun + policy-denied recovery: `references/local-probe-nondestructive-rerun-and-deny-recovery.md`
- Local-probe no-request-form image-cap + section-subset fallback: `references/local-probe-no-request-form-image-cap-and-section-subset.md`
- HWM.Temperature option fallback orchestrated by A-side pipeline (helper relocation + matrix route marker): `references/temperature-option-fallback-a-side-orchestration.md`
- HWM.Temperature candidate-iteration contract (apply -> deploy/reprobe -> evaluate -> stop/exhaust): `references/temperature-option-fallback-candidate-iteration.md`
- Report-driven generic section tuple convergence: after first-round reports return, AI decides eligible fallback triggers; deterministic Python iterates bounded IOPort/Address + Option candidates, performs targeted reruns, and preserves safety/rollback: `references/report-driven-section-tuple-fallback.md`
- Portable `/susiagent` packaging: include both skill+references and executable project code/DB/runners/tests, exclude secrets/generated state, preserve the current hardcoded install path, and verify archive checksums/tests/DB query after extraction: `references/portable-susiagent-bundle.md`
- WinRM-first auto failover + rollback-backup guard for fetch-flow updates: `references/winrm-auto-failover-and-backup-guard.md`
- WinRM UnicodeDecodeError crash runbook (auto-mode crash => explicit SSH fallback with canonical output lock): `references/winrm-unicodedecode-explicit-ssh-fallback.md`
- WinRM UnicodeDecodeError crash runbook (auto-mode crash => explicit SSH fallback with canonical output lock): `references/winrm-unicodedecode-explicit-ssh-fallback.md`
- Machine-B fan runner exit-code/report precedence and control-enabled overlay JSON notes: `references/machineb-fan-runner-exitcode-and-enabled-overlay.md`
- Machine-B report parsing guard (fan/fan-control glob disambiguation + UTF-8 BOM-safe JSON read): `references/machineb-report-glob-and-bom-guard.md`
- Machine-B HWM.Temperature API namespace vs INI encoded channel: `references/machineb-temperature-api-id-vs-ini-channel.md`
- Machine-B HWM.Temperature end-to-end JSON builder, runner boundary, remote execution order, and verdict closure: `references/machineb-temperature-end-to-end-runbook.md`
- Machine-B HWM.Voltage JSON/API mapping, runner skeleton, and tested remote closure contract: `references/machineb-voltage-json-and-runner-contract.md`
- Machine-B HWM.Current JSON/API mapping, runner skeleton, and remote execution contract: `references/machineb-current-json-and-runner-contract.md`
- Machine-B ThermalProtect Susi4 API contract, canonical IDs, read-only runner safety, and tuple/API/SourceId separation: `references/machineb-thermalprotect-susi4-contract.md`
- Machine-B StorageArea JSON builder, storage ID mapping, read/write runner contract, and explicit-write gate: `references/machineb-storagearea-json-and-runner-contract.md`
- Machine-B StorageArea write-test observed run, lock/unlock suppression, unsupported-read interpretation, and remote cleanup order: `references/machineb-storagearea-write-test-observed-run.md`
- Machine-B GPIO minimal bank/mask JSON builder, explicit functional gate, low/high readback, and state restore: `references/machineb-gpio-json-and-runner-contract.md`
- Machine-B cross-tool differential diagnosis: API ID vs INI tuple, runtime activation evidence, actual-call auditing, capability-only limits, and explicit no-INI-deployment differential testing: `references/machineb-runtime-state-and-cross-tool-diagnosis.md`
- No-INI-touch execution rule: when the user explicitly says not to modify the target INI, upload only the runner, JSON, and required shared wrapper into an isolated directory. Do not back up, deploy, restore, or reload the INI/driver. Record pre/post runtime-INI SHA-256. Run the canonical JSON first; if it fails L1 before API calls, use a clearly temporary target-current JSON only to isolate API health, never as a replacement canonical artifact.
- Existing-runtime SW-only multi-section run (user explicitly requests a one-time reload before tests): preserve their sequence exactly: (1) confirm target/auth and inspect the existing runtime INI read-only; (2) map each existing section JSON to its corresponding runner and required shared helper(s); (3) exclude user-specified sections (e.g. WDT); (4) copy only those existing JSON/PS1/helper files to an isolated target folder—never copy INI or edit JSON; (5) inspect the SUSI4 device match count/state and close SusiDemo4 if running before reload; (6) perform exactly one explicitly requested SUSI4 PnP disable/enable cycle and verify Status=OK/Problem=0; this is not an OS reboot; (7) run paired JSON/PS1 sequentially against the unchanged live runtime INI, omitting functional/write/fixture/control switches for SW-only; (8) retrieve every new report and reload log; (9) verify runtime INI pre/post SHA-256 equality and source JSONs remain unchanged. Never silently substitute a per-section INI or temporary JSON when user says to use existing JSONs only. If the live INI lacks sections required by those JSONs, complete the run as requested and classify the resulting L1/FAIL_CONFIG reports as configuration mismatch before API execution—not as API failure. Ensure wrapper dependencies (for example run_hwm_fan_control_validation_section.ps1) are copied when required. If a runner/report does not produce a report, state that explicitly rather than counting it as completed.
- Machine-B SMBus legacy fixture protocol, explicit destructive-test gate, address profiles, public-host-ID separation, and Windows PowerShell 5 UTF-8 BOM deployment: `references/machineb-smbus-legacy-fixture-validation.md`
- Machine-B VGA.Backlight JSON builder, reversible-toggle runner, API-ID mapping, unsupported gating, and remote cleanup: `references/machineb-vga-backlight-json-and-runner-contract.md`
- Machine-B VGA.Brightness builder-vs-runner JSON ownership, API-ID mapping, functional safety, and provenance traceability: `references/machineb-vga-brightness-json-and-runner-contract.md`
- SUSI target crash triage: planned restart vs BugCheck, WER/minidump preservation, AutoReboot interpretation, and destructive-runner gate audit: `references/susi-target-crash-triage.md`
- Machine-B SUSI4 reload/app-handle gate: close SusiDemo4 before PnP reload, interpret Kernel-PnP Event 225, require final enabled-state verification, and separate PnP reload from OS reboot: `references/machineb-susi4-reload-and-app-handle-gate.md`
- Machine-B safe-default result interpretation: distinguish section-level `SECTION_FAIL` from infrastructure failure, verify rollback/recovery closure, and handle expected full-INI hash warnings: `references/machineb-safe-default-result-interpretation.md`

Trigger
- User invokes `/susiagent <PROJECT>` or `/susiagent <PROJECT> --all --host <MACHINE_B_HOST> [--user <USER>]`.
- Public mode contract (fixed):
  - Without `--all`: preserve the existing probe/vision/generation workflow through deterministic Machine-B section JSON creation, including any generation-owned v2 convergence deploy/reload/reprobe required by current rules, then stop before P6-P12 full Machine-B validation. Do not invoke the 14-section validation orchestrator.
  - With `--all`: first complete the same generation phase, then hand the resulting same-project post-INI artifacts to `run_machineB_full_validation.py --execute --host <MACHINE_B_HOST> --user <USER>` and continue through staging, backup, one validation activation reload, safe-default runners, report aggregation, runtime-INI rollback, and one recovery reload.
  - `--user` defaults to `susiaa` at the `/susiagent` layer. A positively identified Machine-B host is mandatory for the P12 handoff; never infer it from a context summary, prior project, or unrelated SSH alias.
  - `--all` is explicit current-turn authorization only for the safe-default full lifecycle above. It does not enable `AllowControl`, fixture, functional, SetConfig, stimulus, or write switches; those remain off unless separately authorized in the current turn.
  - `--all` is a top-level susiagent flag. Never forward it literally to `susi_gen.py`; translate generation to `susi_gen.py --stage all` and post-INI execution to `run_machineB_full_validation.py --execute`.
- Execution-first response norm: after invocation (or equivalent plain-language request), run the selected mode immediately with defaults/overrides. Do not stop at reassurance/planning text; return results from real tool output.
- Prerequisite consent/no-repeat-prompt rule: a current explicit `/susiagent` invocation (or equivalent request to run its generation phase) already authorizes the ordinary prerequisites needed for that selected mode: triggering/fetching the remote probe, read-only local configuration-DB queries, and local rendering of project `bios*`/`circuit*` PDFs for analysis. Proceed directly without asking the user again. This does not broaden consent to INI deployment, driver reload, functional/write/control/fixture tests, or other Machine-B validation side effects unless the selected mode separately authorizes them.
- Mandatory diagram-rule preload: before any BIOS image or schematic/circuit image/PDF analysis, first read `/home/company2/AIagent_susi/AnalysisSKill/bios_circuit_image_analysis_rule.md` in the current run and follow it as the diagram-analysis source of truth. This is automatic whenever diagram analysis is needed; never wait for the user to remind you. Do not substitute remembered rules or this skill's summaries for reading the current file.
- SUSI communication norm for this user: answer in concise Traditional Chinese by default. Lead with the decision/result, list only the affected sections/files and essential evidence, and avoid repeating full architecture explanations unless the user explicitly asks for detail. Target-machine console/report text remains English ASCII.
- Confirmation-only intent exception: if the user explicitly asks to verify whether rules are already encoded (e.g., "不要真的跑", "先確認有沒有寫進 skill 或 python"), do not execute pipeline commands in that turn. Only audit/report rule landing locations (code + skill), then wait for explicit run consent.

Goal
- Complete end-to-end flow for AIagent_susi:
  1) Fetch probe report from target machine via WinRM-first (SSH fallback)
  2) Ensure bios/circuit image cache is vision-populated for new projects (PENDING -> DONE_VISION_ANALYZE)
  3) Run `susi_gen.py --stage all` from PDF to split section ini
  4) Report generated file paths and section-matrix status
  5) Build Machine-B section JSON from current section matrix (`<project>_fan.json`, `<project>_fancontrol.json`) so B-side runners can execute per-section validation without mixed policy files
  6) Auto-converge v2 when required (second-round runtime deploy + probe refetch + regenerate), not one-pass-only
  7) When and only when the public invocation includes `--all`, continue from the freshly generated artifacts into `run_machineB_full_validation.py --execute` and complete safe-default Machine-B validation, report aggregation, rollback, and recovery health verification

Fixed target defaults
- SSH user: `susiaa`
- Host pool (auto order): `192.168.100.16, 192.168.100.15, 172.22.12.77`
- Remote BAT: `C:/Users/susiaa/Desktop/suto/V7/run_susi_full_probe.bat`
- Remote report: `C:/Users/susiaa/Desktop/suto/V7/susi_full_probe_report.txt`

Host override + remote preflight (important)
- If the user provides an IP/host in the invocation message, that host overrides the default for this run.
- In normal `/susiagent` runs, use `fetch_probe.py --mode auto` as default (WinRM first, SSH fallback); only skip remote fetch when the user explicitly requests local-probe mode (for example temporary connectivity/login issues with a pre-fetched report already in project dir).
- Treat `ping` success as network-only evidence (ICMP). It does **not** prove SSH login is possible.
- Before running fetch, preflight the selected host(s): WinRM (`Test-WSMan`/`fetch_probe.py --mode auto`) first; if WinRM path is unavailable, then run SSH auth preflight (`ssh -o BatchMode=yes ... "echo ok"`).
- If the user asks to "先看一下我現在有的是什麼" (or equivalent review-first wording), run a read-only SSH inventory first (see `references/ssh-readonly-inventory-before-hostkey-remediation.md`) and do not modify `known_hosts` in that turn.
- If preflight returns `Permission denied (publickey,password)`, stop SSH path immediately and report it as an authentication blocker (not a connectivity blocker). Then request either valid non-interactive SSH credentials/key or a local probe report override under the project directory.
- In non-interactive runs, password-only login may fail with `ssh_askpass` errors; this is expected when no TTY/askpass is available.
- Multi-target known-hosts preservation: when onboarding an additional target disk/machine/IP, keep existing `known_hosts` entries intact unless the user explicitly authorizes removal. Prefer adding the new host key (for example with first-connect `StrictHostKeyChecking=accept-new`) and use a dedicated SSH alias in `~/.ssh/config` for each target.
- Public-key rejection diagnosis gate: when host-key verification succeeds and TCP/SSH handshake succeeds but login fails with `Permission denied (publickey,password,keyboard-interactive)`, classify it as remote key-acceptance/ACL setup blocker (for Windows OpenSSH: `authorized_keys`, ACLs, and `sshd_config`/service), not a connectivity blocker. Report this classification explicitly and avoid retry loops until remote-side key acceptance is verified.
- Consistency gate: do not conflate skill defaults with code defaults. Validate `fetch_probe.py` defaults separately; when they differ, pass explicit `--remote-bat/--remote-report` args (and patch code defaults if project baseline has changed).
- WinRM stderr decode pitfall (WSL): when `fetch_probe.py --mode auto` fails during WinRM preflight with `UnicodeDecodeError` (PowerShell stderr encoding mismatch), treat it as a WinRM path/tooling decode blocker for this run and immediately continue with SSH preflight + `--mode ssh` (do not report fetch success from the failed auto attempt).
- Crash-handling detail: if auto mode exits with a Python traceback before attempting built-in fallback, operators must manually run SSH preflight (`ssh -o BatchMode=yes ... "echo ok"`) and then rerun `fetch_probe.py --mode ssh` with explicit `--dir` and `--output-name` (canonical output lock).
- Output-path lock for fetch stage: always pass explicit `--dir /home/company2/AIagent_susi/CASES/<PROJECT>` (and canonical `--output-name`) in `/susiagent` runs so probe artifacts do not drift to cwd-relative roots like `/home/company2/CASES/...`.
- WSL/Windows connectivity split gate (important): if target is reachable from Windows host but not from WSL NIC/path, run remote commands through Windows OpenSSH via `powershell.exe -NoProfile -Command "ssh ..."` from WSL instead of failing the run.
- In that bridge mode, keep SSH/SCP key paths in Windows form (e.g. `C:\Users\<win_user>\.ssh\id_ed25519_susi`) and keep remote Windows BAT execution wrapped by `cmd /c`.
- Bridge-mode output retrieval: after BAT completion, pull report with Windows `scp` invoked via PowerShell and Windows destination path, then continue local pipeline using the fetched artifact.

Inputs
- Required: project name (e.g. `SOM-6833`).
- Request-form bypass mode: if user explicitly says there is no request form and provides `chip_name`, proceed with explicit `--chip-name` and section-feasibility reporting from current artifacts; do not block waiting for a form artifact.
- Chip-name normalization in request-form bypass: user input may be shorthand (e.g. `6126D`). Resolve to canonical `ProductChip.chip_name` (e.g. `NCT6126D`) before calling `susi_gen.py --chip-name`, and require a unique match under the resolved product family key.
- ProductChip family-key pitfall: project token and DB key can differ by granularity (e.g. project `AIMB-289` but `ProductChip.product_name` is `AIMB`). Keep project paths/canonical artifact names as full model, but use family key for `(product_name, chip_name)` DB lookup and verification.
- Expected project directory: `/home/company2/AIagent_susi/CASES/<PROJECT>/`
- Expected PDF naming (default resolver path): `<PROJECT>.pdf` under the project dir unless caller provides explicit override.
- Project token normalization:
  - User input may be lowercase/mixed-case (e.g. `som-6833`).
  - Resolve against `CASES/` case-insensitively and then use the canonical on-disk name for all paths and CLI args (e.g. `SOM-6833`).
  - Do not fail early on casing mismatch if a unique case-insensitive match exists.

## Configuration database migration gate

When the project changes configuration database schema, run the migration audit before using `/susiagent`:

1. Search project runtime code, case artifacts, documentation, and skill references for retired DB filenames, table names, join keys, and hardcoded query paths.
2. Confirm ProductChip lookup remains `(product_name, chip_name)` and section joins use `hardware_id`.
3. Update both implementation and operational skill references; do not leave old schema instructions as executable-looking examples.
4. Verify with one real `config_new.db` ProductChip/section query, Python compilation, and a final stale-reference scan.

Reference checklist: `references/config-schema-migration-audit.md`.

- Always execute with project venv: `/home/company2/AIagent_susi/.venv/bin/python`
- Do not use system `python3` for this workflow.
- Reason: required deps (e.g., `pdfplumber`, `PyMuPDF/fitz`) are installed in `.venv`.

Local probe/PDF override workflow
- If the user explicitly says the target has already been probed or has no network adapter, skip SSH entirely (including SSH auth preflight). This includes direct statements like `report已經取回資料夾下 不用再SSH`.
- Treat wording like `網路不通` + `report *.txt 已經放在專案資料夾` as the same local-probe override signal, even when phrasing is mixed Chinese/English or has typos (e.g., `repot`). In this case, do not run SSH preflight/fetch; resolve probe file directly from the project directory and continue with `--probe`.
- In this local-probe mode, locate a report under the canonical project directory and pass it with `--probe`; do not rename it merely to satisfy the default filename.
- The report filename need not be `<PROJECT>_susi_board_probe_report.txt`; accept an existing report such as `som5899_susi_full_probe_report.txt` when it is clearly the project’s probe output.
- Local-probe hard gate: after this override is detected, do not run any network commands (`ssh`, `scp`, WinRM remoting, `fetch_probe.py --mode ssh|winrm|auto`) for this run, including unrelated SMBus/SPD helper probes.
- Local non-destructive execution gate: in this mode, avoid prepending destructive cleanup commands (for example `rm -f`) before generator stages unless the user explicitly requests cleanup. Prefer direct `susi_gen.py` rerun with explicit canonical output paths.
- Anti-placeholder guard: never invent or test with placeholder hosts (for example `0.0.0.0`) in `/susiagent` flows; if host is needed and user did not provide one, use the skill default host or stay fully local per override.
- If `<PROJECT>.pdf` is absent, enumerate project PDFs and use the explicitly identified board/schematic PDF with `--in-pdf`. Do not fabricate or copy a PDF under the default name.
- A scanned schematic PDF may have no text layer; use the project’s extracted `circuit*.png` images and `vision_analyze` to identify a clearly visible EC/SIO part number. Never select a DB chip key from proximity or a typical-board assumption.
- When `understand` produces an empty `chips.hwm`/`chips.gpio`, query `ProductChip` using the fixed product key and map the confirmed schematic part to the available DB `chip_name`/`config_chip`. Pass the resolved DB `chip_name` with `--chip-name` during `generate`; do not pass the user-facing `config_chip` string when it is not itself a `ProductChip.chip_name`, and do not stop at the inference error. Example: a schematic may visibly identify `RDC_EIO-IS200`, while `ProductChip` stores `chip_name=EIO-201` and `config_chip=Advantech EIO_IS200`; use `EIO-201` for the fixed `(product_name, chip_name)` lookup and generator argument, while retaining the config-chip identity as the mapping evidence.
- Example local generate invocation:
  `/home/company2/AIagent_susi/.venv/bin/python /home/company2/AIagent_susi/susi_gen.py --stage generate --project <PROJECT> --root /home/company2/AIagent_susi/CASES --in-json <SPEC> --spec-out <PROJECT>-spec.json --out-ini <PROJECT>-pre.ini --chip-name <DB_CHIP_KEY> --probe <LOCAL_REPORT> --split`
- ProductChip identity resolution details: `references/productchip-identity-resolution.md`.
- EIO-201/EIO-211 data-model and routing guard: `references/eio201-eio211-modeling-and-routing.md`.
- No-request-form + image-cap fallback: if user already provided local probe + explicit `--chip-name` + section intent and `--stage all` is blocked by extract/understand image-input limits (e.g. too many embedded images), switch to request-form bypass execution: ensure canonical `<PROJECT>.json` + `<PROJECT>-spec.json` exist, then run `--stage generate` with explicit `--in-json/--probe/--chip-name/--sections` and report section feasibility from matrix. Do not treat this as SSH/network failure.
- Report-to-JSON ownership guard: after probe is available, required JSON mutations should be owned by the primary pipeline entrypoints (`susi_gen.py` and/or `build_machineB_section_configs.py`) so reruns are reproducible from one command path. Treat standalone helpers under `targetB_task/machineB_validation/` as auxiliary/manual unless they are explicitly wired into the pipeline and documented here with invocation path.
- Unchecked-sections policy: when user explicitly states SMBus/I2C/Backlight/Brightness are not selected, keep those booleans disabled in spec bootstrap and do not silently re-enable those sections in `--sections`.
- Post-run feature-toggle correction gate: if user later corrects a previously disabled feature flag (for example `SMBUS 改成 TRUE`), treat the latest user message as authoritative, patch spec boolean(s), rerun a minimal affected-section generate pass (at least corrected section + dependency sections needed for matrix/pre.ini consistency), then rebuild Machine-B section JSON from the refreshed matrix. Clearly mark prior section status as stale-by-intent and report refreshed paths.
- Chip-name inference pitfall (important): `understand` can output non-canonical chip tokens (for example trailing punctuation like `NCT6694B-`) that make `generate`/`all` fail with `Cannot infer chip_name from spec.json` even when `chips.hwm` is non-empty. In this case, resolve canonical `ProductChip.chip_name` from DB and pass explicit `--chip-name` for `generate`/`all` (use the section-routing key required by policy, e.g. EC route `EIO-300` for non SMBus/I2C/GPIO sections).

Execution steps
1. Resolve canonical project name and validate project dir exists.
   - If `/CASES/<input>/` is missing, perform case-insensitive match in `/CASES`.
   - If exactly one match exists, adopt that canonical name for the rest of the run.
   - If none or multiple matches, stop and report ambiguity.
2. Fetch probe report (preferred helper):
   - Default (practical): `/home/company2/AIagent_susi/.venv/bin/python /home/company2/AIagent_susi/fetch_probe.py --mode auto --ssh-user susiaa --project <PROJECT> --remote-bat "C:/Users/susiaa/Desktop/suto/V7/run_susi_full_probe.bat" --remote-report "C:/Users/susiaa/Desktop/suto/V7/susi_full_probe_report.txt"`
   - If WinRM needs explicit credential: append `--win-user <WIN_USER> --win-pass <WIN_PASS>`.
3. Confirm probe file exists:
   - `/home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>_susi_board_probe_report.txt`
   - WinRM path check: remote BAT execution must return ExitCode=0 before reading report; non-zero ExitCode is a hard blocker.
   - Windows SSH pitfall: if stderr shows `'<path>.bat' is not recognized as an internal or external command`, treat it as a remote-path/shell invocation mismatch.
     - First re-verify the exact BAT path (including subfolder version segments like `V7`).
     - If path is correct but still fails under direct `ssh host C:/...bat`, retry with explicit shell invocation form (for example `cmd /c "C:\\...\\run_susi_full_probe.bat"`).
4. Pre-generate bios image cache:
   - Ensure `spec.json` exists before cache bootstrap. If this is a fresh project, run `extract` then `understand` first.
   - Then run `generate` once (or call internal cache build path) so `<PROJECT>-bios-image-cache.json` exists.
   - Pitfall: if generate fails with `Cannot infer chip_name from spec.json`, this means `understand` has not produced a usable spec yet. Run `--stage extract` and `--stage understand`, then retry generate.
5. Vision gate for new projects:
   - If cache missing, or any item has `analysis_status != DONE_VISION_ANALYZE` (especially `PENDING_VISION_ANALYZE`), then:
     - Enumerate scoped BIOS/circuit images under project dir with extension-flexible matching: `bios*`/`circuit*` + (`.png`, `.jpg`, `.jpeg`) in case-insensitive mode.
     - Scope lock: ignore non-matching files (for example `AIMB-523_A101-2_0510.pdf`, notes, JSON, or any non `bios*`/`circuit*` raster asset) unless the user explicitly expands scope.
     - Do not assume PNG-only inputs; if `bios*.png` is empty, still check `bios*.jpg`/`bios*.jpeg` before concluding BIOS images are unavailable.
     - For each image, call Hermes `vision_analyze` with a voltage-focused prompt:
       - Extract only visible voltage labels (examples: `+12V`, `+5V`, `+5VSB`, `+3.3V`, `VBAT`), no guessing.
     - Write results back to `<PROJECT>-bios-image-cache.json` per image item:
       - `analysis_status = DONE_VISION_ANALYZE`
       - `analysis_text = <vision result text>`
       - `voltage_label_hints = <dedup label list parsed from vision text>`
       - `voltage_value_hints = <[{label,value,unit}] from visible BIOS values>`
       - `temperature_value_hints = <[{label,value,unit}] from visible BIOS values>`
       - `fan_value_hints = <[{label,value,unit}] from visible BIOS values>`
       - `label_hint_source = vision_analyze`
     - Cache-write safety: perform this mutation with an approved file-edit operation (for example the file write/patch tool), not an ad-hoc shell command that directly overwrites project artifacts. If the write is denied or cannot be verified, stop the pipeline and report the exact blocked artifact; never claim the vision gate or final pipeline completed.
     - After writing, re-read the cache and verify every enumerated item is `DONE_VISION_ANALYZE`.
    - Top-level cache completion may be normalized by generator runs to either `DONE_VISION_ANALYZE` or `DONE`; treat both as complete states.
    - Verify item count matches the scoped `bios*.png` / `circuit*.png` enumeration before continuing.
   - Mandatory separate BIOS-name passes before `generate` (do not consider the voltage cache pass sufficient):
     - Temperature pass: run high-reasoning `vision_analyze` on scoped BIOS rasters (`bios*` with `.png/.jpg/.jpeg`, case-insensitive) and extract only clearly visible real-time temperature sensor labels. Ignore threshold/configuration labels such as `CPU Shutdown Temperature` unless an actual monitor row is visible.
     - Map confirmed labels to probe-backed keys (`CPU Temperature` -> `TCPU`, `System Temperature` -> `TSYS`, etc.); do not invent unsupported probe items or channel mappings.
     - Persist normalized results, including an empty `by_key` when no usable temperature label is visible, to `<PROJECT>-temperature-name-hints.json` with image/evidence/status metadata.
     - Fan-name pass: independently analyze BIOS fan labels when fan sections are present; persist `<PROJECT>-fan-name-hints.json` rather than relying on the voltage-focused cache.
     - If scoped BIOS rasters are empty across `.png/.jpg/.jpeg`, create both hints files with `status=NO_BIOS_IMAGES`, `images_analyzed=[]`, and empty `by_key`.
     - Critical pitfall: never mark `NO_BIOS_IMAGES` based on `bios*.png` alone. A board may provide BIOS captures only as `.jpg/.jpeg`; treating that as empty causes missing aliases in `[HWM.Temperature]` and `[HWM.Fan*]`.
     - Re-read and validate both name-hints artifacts before running `susi_gen.py`; if a clear BIOS label exists, the corresponding hint must be non-empty. These passes are mandatory even when the voltage image cache is already `DONE_VISION_ANALYZE`.
- PNG ambiguity fallback (schematic cross-check):
     - When `circuit*.png` evidence is insufficient (blur/crop/context causes unstable pin↔net mapping or off-by-one risk), also analyze schematic PDFs in the same project (typically `circuit*.pdf`, if present).
     - Use PDF text/structure to confirm `pin number + pin function + net name` alignment; do not infer beyond visible evidence.
   - If all already `DONE_VISION_ANALYZE`, keep cache unchanged.
- Automation-completeness gate (cache vs AI boundary):
  - Writing/merging `*-temperature-name-hints.json` and `*-fan-name-hints.json` from existing cache text is only the **consumer** half of automation.
  - Full in-pipeline automation requires a **producer** step that actively runs BIOS-focused `vision_analyze` for scoped `bios*.png|jpg|jpeg` whenever cache items are missing `analysis_text` or are not `DONE_VISION_ANALYZE`.
  - Cache completeness for downstream value correlation also requires populated `voltage_value_hints` / `temperature_value_hints` / `fan_value_hints`; if these arrays are missing, rerun producer for affected items.
  - Do not report "auto extraction completed" when only regex/cache consumption ran without producing fresh AI analysis for pending images.
  - Reference implementation notes: `references/vision-cache-vs-ai-boundary.md`.

Schematic GPIO/BI extraction
- Before this section, the mandatory preload rule applies: read `/home/company2/AIagent_susi/AnalysisSKill/bios_circuit_image_analysis_rule.md`; if this summary conflicts with that file, the current rule file wins.
- Source selection for GPIO evidence is dual-source when both raster and PDF exist. For PDFs, first search the chosen target-signal pattern/keywords, render focused high-resolution crops around every hit, and save crops plus page/keyword evidence in the project directory. A low-resolution full-page render is locator-only and must never be used for final mapping.
- Build and report the complete `target_signal_set` before tracing. For `NCT6694B`/`EIO-300`, the default search scope is all signals matching `EC_P*_GPIO*` (P1, P2, P3, etc.), not only P1. For `NCT61xxD`, default to `SIO_GPIO*`; use the current rule file for other chip-aware patterns and ambiguity handling.
- Trace each target signal by actual electrical wire through bends/junctions to its chip pin and function label. Never derive mapping from suffix/index, nearest text, OCR order, or y-coordinate proximity.
- Every target signal must produce either a confirmed mapping or an explicit ambiguity result; out-of-scope FAN/BEEP/LED signals must not leak into the GPIO table.
- Report both layers explicitly: external signal/net → logical GPIO function → normalized group/bit, with package pin retained as evidence when readable. Examples: `GPIO34 -> 3,4`, `GPIOA5 -> 10,5`.
- `X`/`NC` marks are hint-only unless attached to the traced endpoint and terminating that wire. If a crop remains ambiguous or risks off-by-one mapping, create/analyze a tighter high-resolution crop or cross-check vector/PDF geometry before accepting it.
- Stale-artifact cleanup: if a previous wrong run emitted `<PROJECT>_GPIO.ini`, overwrite it during the same rerun so obsolete mappings cannot remain.

Schematic FAN/FAN-control extraction (when user asks FAN mapping)
- Treat tach/speed nets as FAN input candidates: patterns like `FAN_SPEED*`, `*TACH*`, `CPUFANIN`, `SYSFANIN`, `AUXFANIN*`.
- Treat PWM nets as FAN control output candidates: patterns like `*_PWM`, `CPUFANOUT`, `SYSFANOUT`, `AUXFANOUT*`.
- Build mapping by net-level trace (wire path + junction continuity), not by nearby text proximity.
- Output in 3-layer form: external signal/net → logical function label (CPUFANIN/SYSFANIN/AUXFANIN*, CPUFANOUT/SYSFANOUT/AUXFANOUT*) → EC/SIO pin.
- Pair IN/OUT only when both sides are supported by the same fan-channel wire evidence; otherwise mark `ambiguous`.
- One-to-one status is a post-analysis result (after diagram/PDF tracing), never a precondition gate.
- When one-to-one IN/OUT is confirmed, normalize output with synchronized mapping for both sections:
  - `[HWM.Fan]` and `[HWM.Fan.Control]` use the same key set (`FCPU`,`FSYS`,`FOEMx`).
  - Mapping values are aligned for `hwid` (from DB), `channel_id` (`base_channel_id + idx`), `io_port`, and BIOS alias.
  - Section differences are only fixed template fields (`HWM.Fan`: `...,0x2E,0x80000000,0,"alias"`; `HWM.Fan.Control`: `...,0x2E,0x20000000,"alias"`).
- Non-one-to-one exception (important): FAN connector count / FANOUT(PWM) count may exceed confirmed FANIN channels.
  - Do **not** force `[HWM.Fan]` and `[HWM.Fan.Control]` to share the same `channel_id` mapping in this case.
  - Build `[HWM.Fan]` channel IDs from traced FANIN evidence; build `[HWM.Fan.Control]` channel IDs from traced FANOUT/PWM control-source evidence.
  - Keep key naming aligned (`FCPU`,`FSYS`,`FOEMx`) only where evidence supports it; unresolved paths stay pending/ambiguous.
  - Typical pattern: extra SYS fan connectors can be downstream branches sharing upstream PWM/TACH source; this does not automatically create new FANIN channels.
- If PNG evidence is insufficient, cross-check schematic PDF/vector page before accepting mapping (fan-control pages are often required for non-one-to-one cases).
- File/page evidence logging is optional debug data (useful for conflicts/ambiguity), not mandatory output in normal flow.
- See `references/aimb-506-fan-non-1to1-notes.md` for a concrete non-one-to-one example and extraction checklist.
  - A core SIO page may only expose CPU/SYS1/SYS2 logical nets.
  - Separate fan-control pages may add extra connectors (e.g., SYS3/SYS4) or show shared PWM sources.
- Do not assume `connector count == independent control channel count`; detect shared upstream PWM source nets before assigning distinct control channels.
- If PNG evidence is insufficient, cross-check schematic PDF/vector page before accepting mapping.
- File/page evidence logging is optional debug data (useful for conflicts/ambiguity), not mandatory output in normal flow.
- Quick reference checklist: `references/fan-mapping-evidence-checklist.md`.
- Multipage fan mapping note (connector count vs control-source count): `references/fan-multipage-channel-vs-control.md`.

- Conflict-stability gate: if multiple image passes/crops produce conflicting GPIO mappings, do not flip-flop to the latest guess; set the affected signals to `GPIO_NET_TRACE_AMBIGUOUS` and list candidate endpoints with evidence.
- When a crop is ambiguous or risks an off-by-one mapping, request/analyze a focused crop (must include signal label + full wire path + destination pin row) or cross-check the source schematic PDF/vector geometry before accepting the result.
- Session reference with corrected ARK-1251 BI mappings: see `references/ark-1251-gpio-wire-tracing.md`.

FAN/FAN control extraction (when user asks FAN analysis)
- Build mapping from connector wiring, not naming proximity.
- Output at connector granularity: `connector_name`, `tach_net`, `pwm_output_net`, `pwm_input_source_net(s)`.
- Do not assume one-to-one FANIN↔PWM. Many boards use grouped PWM control with independent TACH per connector.
- If crop evidence is weak, cross-check full-page schematic PDF before confirming pin/net pairing.
- Reference playbook: `references/fan-control-mapping-playbook.md`.

6. Run full pipeline:
   - `/home/company2/AIagent_susi/.venv/bin/python /home/company2/AIagent_susi/susi_gen.py --stage all --project <PROJECT> --root /home/company2/AIagent_susi/CASES --probe /home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>_susi_board_probe_report.txt`
   - CLI boundary pitfall: `--remote-bat` / `--remote-report` are `fetch_probe.py` arguments only. Do **not** pass them to `susi_gen.py`; `susi_gen.py` will fail with `unrecognized arguments`.
   - Canonical-output lock (important): when `--in-pdf` points to a non-`<PROJECT>.pdf` file (for example `circuit_SIO6126_AIMB-289.pdf`), `susi_gen.py` may derive output basenames from PDF stem and produce `circuit_*` artifacts. To keep project-consistency valid, pass explicit `--out-json/--spec-out/--out-ini` as `<PROJECT>.json`, `<PROJECT>-spec.json`, `<PROJECT>-pre.ini`, then verify `section-matrix.project == <PROJECT>`.
  - Directory-vs-file resolver pitfall (important): if `/CASES/<PROJECT>.json` exists at CASES root, token-only `--project <PROJECT>` can drift outputs to CASES root-level files. For `/susiagent`, prefer `--project /abs/.../CASES/<PROJECT>` plus explicit canonical `--in-pdf/--out-json/--spec-out/--out-ini` paths inside `<PROJECT>/` to prevent mixed-location artifacts.
  - Proven local EC pattern: when a project has a generic local report such as `susi_full_probe_report.txt`, pass that file directly with `--probe`; do not rename it. For an explicit EIO-300/NCT6694B compound identity, use canonical `--chip-name EIO-300` and verify the generated matrix routes `SMBus/I2C/GPIO` to `NCT6694B` while other EC-side sections use `EIO-300`. Detailed runbook: `references/local-probe-eio300-nct6694b-runbook.md`.
  - Downstream matrix/source lock: build Machine-B JSON from the matrix generated in the same canonical project dir run (`.../CASES/<PROJECT>/<PROJECT>-section-matrix.json`), not from root-level duplicates. If both locations exist, treat root-level files as stale candidates unless explicitly re-designated by user.

6.1 Auto-converge v2 second-round gate (mandatory when triggered)
   - After the first `--stage all` run, inspect `<PROJECT>-section-matrix.json`.
   - Trigger second-round automatically when either condition matches:
     1) Chip is NCT61**D family (`NCT6106D`, `NCT6116D`, `NCT6126D`) and section is `HWM.Voltage` or `HWM.Temperature`.
        - This is a hard requirement (user policy): do not stop at first-pass v1.
     2) Section route/status indicates v2 not converged yet (for example route missing `+SUPERIO_V2_BIOS_PROBE_ALIAS` or `+SUPERIO_TEMP_V2_BIOS_PROBE_ALIAS`, or v2 kept-count metadata missing while v1 seed route exists).
   - Second-round procedure (single retry budget):
     1) Deploy generated `<PROJECT>-pre.ini` (or split section INI as policy requires) to target runtime path.
     2) Reload SUSI runtime/driver on target (project-approved non-UI flow).
     3) Re-run probe fetch to refresh `<PROJECT>_susi_board_probe_report.txt`.
     4) Re-run `susi_gen.py --stage all` with refreshed probe.
     5) Re-check section matrix and require v2 markers for `HWM.Voltage` / `HWM.Temperature`.
   - If second-round still cannot converge, report explicit blocker evidence (BIOS not visible / probe no `[OK]` / auth/runtime failure) and stop; do not silently report one-pass v1 as complete.

6.2 Partial-feasibility fallback (when user asks “現有資料可完成哪些 section?” or full split is blocked)
   - If `--stage all` or `--stage generate --split` is blocked by one failing section (for example DB/query errors), do **not** stop at a single global failure.
   - Run `--stage generate` per section using `--sections <SECTION>` to isolate status and confirm what can already be produced from current artifacts.
   - Important CLI pitfall: `--split` and `--sections` are mutually exclusive; never pass both together.
   - Prefer this sequence:
     1) attempt full run (`--split`) once,
     2) on failure, run per-section probes for all 14 sections,
     3) summarize results into three buckets: `GENERATED`, `SKIPPED_EMPTY_SECTION`, and blocked/pending statuses (for example `FAN_PAIRING_AMBIGUOUS`, `PENDING_*`, hard error).
   - If a subset is known to be stable, you may produce a partial deliverable in one command by passing a comma list to `--sections` (without `--split`) and report the exact included sections.
   - Keep canonical project lock in all paths and report absolute output paths only for actually generated files.

7. Verify outputs exist:
   - `<PROJECT>-spec.json`
   - `<PROJECT>-pre.ini`
   - `<PROJECT>-section-matrix.json`
   - split `_<SECTION>.ini` files that are GENERATED
   - If EC route used: `<PROJECT>-hwm-voltage-ec-base.json` and `<PROJECT>-voltage-alias-bridge.json`
   - Section-matrix parsing pitfall: `sections` is an array of objects (`{section,status,path,...}`), not a map keyed by section name. Verification scripts must iterate the array and derive status maps explicitly.
   - Explicit user override (`all sections required`): if the current-turn user asks that all section artifacts must exist, ensure all 14 split section files are present even when some matrix statuses are `SKIPPED_EMPTY_SECTION`.
     - Keep matrix status semantics unchanged (do not relabel skipped sections as generated).
     - For missing split files in this override mode, emit minimal placeholders containing `[Information]` + target section header only.
     - Report these as `placeholder(empty)` in the final summary so artifact completeness is explicit and non-misleading.
8. Build Machine-B section JSON from the generated matrix (first-stage fan scope):
   - `/home/company2/AIagent_susi/.venv/bin/python /home/company2/AIagent_susi/build_machineB_section_configs.py --matrix /home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>-section-matrix.json --output-dir /home/company2/AIagent_susi/CASES/<PROJECT>`
   - Expect (when corresponding sections are GENERATED):
     - `/home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>_fan.json`
     - `/home/company2/AIagent_susi/CASES/<PROJECT>/<PROJECT>_fancontrol.json`
   - Blocking policy:
     - If matrix status is `SKIPPED_EMPTY_SECTION`, `PENDING_*`, or `INVALID_SECTION`, do not claim runnable JSON for that section.
     - If source section INI is missing or tuple format check fails, treat JSON build as blocked and report exact section-level error.

8.1 Top-level `--all` handoff (only when explicitly present in the current invocation):
   - Require a positively identified Machine-B host. Use current invocation `--host`; do not guess or silently reuse an old target. Default `--user` to `susiaa` only after the host gate passes.
   - Generate a unique run ID; do not delete/reuse an existing validation run directory.
   - Invoke the fixed post-INI engine:
     `/home/company2/AIagent_susi/.venv/bin/python /home/company2/AIagent_susi/run_machineB_full_validation.py --project <PROJECT> --repo-root /home/company2/AIagent_susi --run-id <UNIQUE_RUN_ID> --execute --host <MACHINE_B_HOST> --user <USER>`
   - The engine owns P5-P12: rebuild/validate section JSON, local preflight/manifest, remote staging and runtime-INI backup, full-INI deployment once, one validation reload/readiness gate, registry-ordered safe runners, fresh-report retrieval/parsing, summary, rollback, and one recovery reload/readiness check.
   - Do not invoke execute mode when the generation phase is blocked or when artifacts belong to a different project. Never substitute stale post-INI artifacts merely to keep `--all` moving.
   - Do not pass any opt-in safety switch merely because `--all` was supplied. `--all` means all runnable sections under safe defaults, not all destructive/fixture/control behavior.
   - If an independent section returns API/SW FAIL, preserve it as `SECTION_FAIL` and follow engine continuation policy. If connection/deployment/reload/report infrastructure fails, preserve `ORCHESTRATOR_ERROR`, enter recovery, and do not misreport the run as completed successfully.
   - Completion requires reporting the absolute `manifest.json`, raw report directory, `validation-summary.json`, `validation-summary.txt`, overall status/exit code, and rollback/recovery result.

8.2 No-`--all` stopping rule:
   - After Step 8 succeeds, return the generated artifact/config paths and section-status buckets, then stop before the P6-P12 full-validation handoff.
   - Preserve the existing probe fetch and generation-owned v2 convergence behavior from earlier steps; this stopping rule forbids only the post-INI 14-section full-validation deployment/reload/runner lifecycle, not generation prerequisites already required by this skill.
   - Do not invoke `run_machineB_full_validation.py --execute` or run the 14 section validators.
   - Clearly state that a later `/susiagent <PROJECT> --all --host <HOST>` invocation can execute the second phase from regenerated/current same-project artifacts.

9. Return concise status summary with absolute paths.
   - If user intent is “all sections”, completion means all standard sections are represented in section-matrix (not necessarily all `GENERATED`). Treat `SKIPPED_EMPTY_SECTION` as valid coverage, and report section buckets explicitly.
10. Intermediate artifact handling: when stage outputs are files, pass them through pipeline as machine I/O only; do not print or preview intermediate file contents/screens in normal user-facing output unless explicitly requested.

StorageArea Machine-B contract
- StorageArea is an ordinary section, not a power-state section. If the user asks to also handle StorageArea, generate `<project>_storage.json` and `run_storage_validation.ps1`; do not infer that Storage must be disabled because WDT/ThermalProtect destructive tests were disabled.
- Preserve the INI tuple channel separately from the public storage ID. Map `Area0` to `SUSI_ID_STORAGE_STD` (`0x00000000`), `Area1` to `SUSI_ID_STORAGE_OEM0` (`0x00000001`), and increment thereafter.
- Runner baseline is `SusiStorageGetCaps` plus `SusiStorageAreaRead`. A persistence write test requires explicit opt-in (JSON policy plus runner switch) and should restore original bytes when configured.
- Never enable Lock/Unlock in the initial StorageArea validation. Keep `SusiStorageAreaSetUnlock` and `SusiStorageAreaSetLock` absent from the P/Invoke declaration and runner.
- For `-EnableWriteTest`, require a successful initial read and captured original buffer before issuing any write. If caps/read returns `0xFFFFFCFF` (`SUSI_STATUS_UNSUPPORTED`), do not write; report that the write gate was enabled but no mutation occurred. Use report API-call names to distinguish policy enablement from actual writes.
- Remote execution must be staged and closed: sync/hash-check files, backup runtime INI, deploy paired INI, attempt/record driver reload separately from library init, run the gated runner, pull the timestamped report, restore the original INI, and verify its hash plus final device status. See `references/machineb-storagearea-write-test-observed-run.md`.
- Reference: `references/machineb-storagearea-json-and-runner-contract.md`.

Machine-B GPIO contract
- Prefer the minimal legacy-QA-compatible bank flow from `gpio.c`/`gpio_FF.c`/`gpio_FFFF.c`: GetCaps, save direction/level, explicit-gated low/high set+readback, then restore. Do not add fixture maps, loopback schemas, or per-pin policy unless requested by board evidence or the user.
- Derive the public SUSI GPIO number from the zero-padded INI key (`GPIO00 -> 0`), not from tuple group/pin. Preserve tuple group/pin separately; compute bank ID/mask from the public number.
- `build_machineB_section_configs.py` owns `<project>_gpio.json`; keep the generated contract compact and bank/mask based.
- Functional writes require both JSON enablement and `-EnableFunctionalTest`. Read-only execution must not mutate GPIO state.
- Restore original level first while pins remain outputs, then restore original direction; verify both. Keep emergency restore in the runner cleanup path.
- If the user says a fixed runtime INI is already deployed, do not copy INI or reload the driver. Sync/hash-check only runner, JSON, and `common_susi.ps1`, pass the runtime INI explicitly, run read-only first, inspect its report, then run the gated functional test.
- Low/high API readback validates API mapping and output latch behavior, not external electrical loopback; report that boundary explicitly.
- Reference: `references/machineb-gpio-json-and-runner-contract.md`.

VGA.Backlight Machine-B contract
- Treat Backlight as a section-specific runner/config pair, not as a generic Brightness alias. Build `<project>_backlight.json` from the generated section matrix and paired `<project>_VGA.Backlight.ini`.
- Preserve the INI tuple channel separately from the public SUSI API ID. The builder must map stable keys (`BACKLIGHT1`, `BACKLIGHT2`, ...) to the canonical Backlight API namespace/table mapping; never copy an encoded INI channel into `SusiBoardGetValue`/`SusiBoardSetValue` calls without comparing it to the full-probe `HWM_BACKLIGHT_*` IDs.
- Default validation is read-only: GetCaps/GetEnable/GetValue (as applicable). A functional toggle is a reversible side effect and requires both runner opt-in (`-EnableFunctionalTest`) and JSON policy (`functional_test.enabled=true`).
- Functional flow must be `GetEnable(original) -> SetEnable(toggle) -> GetEnable(verify) -> SetEnable(original) -> GetEnable(restore)`, with every call captured in the report. If the initial read/capability/API prerequisite is unsupported, do not issue SetEnable and classify the result as blocked/unsupported rather than a toggle failure.
- For remote target-B execution, use the explicit sequence: sync and hash-check runner/helpers/JSON/INI -> backup runtime INI -> deploy paired INI -> reload driver/runtime and record that stage separately from SUSI library init -> run runner -> pull the newly timestamped report -> restore original INI -> reload after restore -> verify restored hash and final device status. Do not present a prior report as the corrected run.
- Keep SW/DQA verdict separation and CI exit policy identical to other Machine-B runners: SW gates configuration/capability/API/readback; DQA covers functional/recovery; exit code follows SW only. A fixture- or toggle-gated result may be CONDITIONAL/N_A without being a SW pass if API prerequisites failed.
- Reference: `references/machineb-vga-backlight-json-and-runner-contract.md`.

Rules
- User-facing SUSI discussion style: respond in concise Traditional Chinese by default. Lead with the decision/result and only include evidence needed to support it. Do not expand a simple confirmation or file classification into a long architecture essay unless the user asks for detail.
- First-validation tuple-fallback decision: after the normal complete-INI validation, retrieve fresh reports first; AI determines which sections satisfy the fallback trigger gate, then emits a structured plan. Python—not ad-hoc AI edits—owns ordered candidate mutation, deploy/reload, targeted reruns, evidence capture, and rollback. Follow `references/section-tuple-fallback-ai-trigger.md`.
- Project-consistency guard: every generated/verified path must use the resolved canonical project name from Step 1, and post-run artifacts must match that same project token (e.g., `section-matrix.project == <PROJECT>`). If mismatch exists, stop and report stale/wrong-project artifacts instead of claiming success.
- Latest-message project lock: when the user invokes `/susiagent <PROJECT>`, treat that `<PROJECT>` as the active target for the current turn. Do not reuse project tokens from earlier context summaries or prior runs.
- SMBus precedence gate (cross-skill consistency):
- Precedence order for SMBus decisions is: **chip-specific SMBus rule/template** > **Intel/AMD channel mapping logic**.
- AMD route policy: do not pre-filter AMD by `EPYC` token. All AMD platforms enter the normal AMD SPD/probe-driven SMBus path; SMBus output is decided by downstream probe/spec evidence, not by an early EPYC hard exception.
- AMD SPD idx remote flow: use WinRM-first (SSH fallback) to run target B `C:/Users/susiaa/Desktop/suto/V7/run_susi_spd_idx_probe.bat`, then pull/read `C:/Users/susiaa/Desktop/suto/V7/susi_spd_idx_probe_report.txt` to machine A.

    `/home/company2/AIagent_susi/.venv/bin/python /home/company2/AIagent_susi/fetch_probe.py --mode auto --probe-kind spd_idx --ssh-user susiaa --project <PROJECT>`
    (Equivalent explicit-path form with `--remote-bat/--remote-report` is also valid.)
  - If this AMD SPD idx path/result is missing or unresolved, keep `PENDING_AMD_SPD_PROBE_PATH_OR_RESULT`; do not emit guessed SMBus channels.
Rules
- Machine-B all-section validation defaults to the complete-INI coexistence flow when the user authorizes deployment: deploy `<project>-pre.ini` once, reload the driver once, then execute every runnable section runner sequentially in isolated PowerShell processes and collect an individual report after each run. Do not reload between ordinary section runners. Reserve split-section INI deploy/reload loops for explicit isolation, conflict diagnosis, or ordered candidate convergence. A valid API/config failure report may be recorded and the loop continued while driver health remains good; driver-health failure, runner crash, or missing report is an infrastructure stop/recovery condition. Follow `references/machineb-full-ini-single-reload-validation.md`.
- Post-first-round fallback decision: retrieve and parse all first-round section reports before selecting fallback targets. AI owns the section-level trigger judgment; deterministic Python owns candidate ordering and execution. Trigger only for an expected/generated section with healthy infrastructure and whole-section consistent failure, or evidence-backed missing functionality attributable to Option. Never trigger section-wide fallback for partial channel failure, missing fixture/population, NOACK alone, runner/report/reload failure, or DQA-pending evidence. Follow `references/report-driven-section-tuple-fallback.md`.
- Machine-B fan validation execution should be split by section runner and JSON-driven:
  - `targetB_task/machineB_validation/hwm.fan_verify.ps1` loads `<project>_fan.json` (or explicit `-ConfigPath`) and validates `[HWM.Fan]`.
  - `targetB_task/machineB_validation/hwm.fan.control.ps1` loads `<project>_fancontrol.json` plus fan dependency JSON and validates `[HWM.Fan.Control]`.
  - If user asks for lean/legacy behavior, use minimal acceptance mode: (1) read robustness over multiple samples, (2) control-set RPM delta effectiveness, (3) recovery verification; keep user-facing report concise (`result/reason/metrics`) instead of forcing L1~L6 labels.
  - SW/DQA dual-verdict contract (CI-safe): each validation report should include `sw_verdict`, `dqa_verdict`, and `ci_exit_code`.
    - `sw_verdict`: derived from L1~L4 (`L1_configuration`, `L2_capability`, `L3_api`, `L4_readback`). Any `FAIL*` in these layers => `FAIL_SW`; otherwise `PASS_SW`.
    - `dqa_verdict`: derived from L5~L6 (`L5_functional`, `L6_recovery`). Any `FAIL*` => `FAIL_DQA`; all `PASS` => `PASS_DQA`; all `N_A/NOT_REQUIRED` => `N_A_DQA`; otherwise `PENDING_DQA`.
    - Exit-code policy is governed by SW verdict only: `FAIL_SW` => non-zero, `PASS_SW` => zero, even when `result` is `CONDITIONAL`/`BLOCKED_*` due to fixture or reboot-gated checks.
  - Keep `result`/`reason` for human diagnostics, but use `sw_verdict` for pipeline pass/fail gating and `dqa_verdict` for fixture-lab completion tracking.
  - Prefer these split entrypoints over mixed AIMB-only policy scripts for new runs.
  - Keep JSON scope to current platform/current generated section INIs; do not merge unrelated section policies into one runtime config.
  - Remote invocation on Windows target should use process-scope bypass in the same command (`Set-ExecutionPolicy -Scope Process Bypass -Force`) before calling entrypoints, because helpers are dot-sourced.
  - Temperature execution-order gate (Machine-B): treat `INI deploy -> runtime/driver reload -> runner with JSON` as three explicit stages. Do not imply reload happened just because the runner called `SusiLibInitialize/SusiLibUninitialize`; that is library init/uninit, not OS driver/service reload.
  - Corrected-rerun gate: after fixing a generated JSON/config mapping, do not present the previous failure report as the current result. Sync the corrected JSON, verify its critical ID/value on the target before execution, run exactly one targeted validation, pull the newly timestamped report, and cite that report path. Keep the prior report only as root-cause evidence.
  - Restore/closure gate for remote Temperature runs: backup the runtime INI before deployment, restore it in a `finally`/cleanup path, reload the driver after restore, then verify both the restored INI hash and final device status (`OK`/`CM_PROB_NONE`) before claiming the run is complete.
  - When a temperature run returns API/read FAIL, report stage evidence explicitly: (1) deployed INI path+hash on target, (2) whether runtime/driver reload was executed (exact command/path), (3) runner `-ConfigPath/-IniPath` arguments used. If reload was skipped, classify as an execution-gap blocker before deeper mapping conclusions.
  - Always sync `common_susi.ps1` with repo version before remote run; stale helper files can break newer entrypoints.
  - SHA policy is execution-mode specific:
    - Complete-INI coexistence mode: JSON may carry the paired split-section INI hash while the target intentionally runs `<project>-pre.ini`; record both hashes and warn, but do not block solely on this expected mismatch. Verify the required section/rows exist in the complete runtime INI.
    - Paired/single-section mode or explicit integrity audit: enforce runtime INI equality with JSON `source_ini.sha256`; if it differs, deploy/pass the paired INI or regenerate JSON from the intended runtime artifact.
    - Never let a warning-only full-INI policy silently weaken strict paired-section validation. See `references/machineb-full-ini-single-reload-validation.md`.
  - SMBus Machine-B builder parsing: SUSI SMBus tuple field 2 may be an encoded channel `0x80000000 + idx` (for example `0x80000000` for Channel1 or `0x80000001` for Channel2), not a literal bus index. Preserve the raw tuple in JSON, but decode the capability/bus index by subtracting `0x80000000` before applying the `[0,31]` validation. A builder rejection such as `bus index ... got 2147483648` is a parser defect, not a generated-INI mapping failure.
  - SMBus fixture gate: keep legacy transaction/write tests behind explicit `-EnableFixtureTest`; default runs validate only configuration, supported-host mask, and API availability. Treat `0xAC`, `0xAE`, and `0x4A` as encoded fixture slave addresses—not host IDs—and keep `PASS_FIXTURE`/`FAIL_FIXTURE` separate from L1-L4 `sw_verdict`. Keep target console/report wording in plain English/ASCII for legibility and Windows PowerShell 5 compatibility. Before execution, run a remote parser check; after execution, decode `NOT_FOUND`/`NOACK` probe statuses and report them as “no ACK during this run,” not as definitive proof of a script defect or disconnected fixture. Full protocol and verification order: `references/machineb-smbus-legacy-fixture-validation.md`.
  - Control-enable pitfall: `<project>_fancontrol.json` may intentionally keep `control_check.enabled=false` for safe default. In this case control runner returns `BLOCKED_CONFIGURATION` even with `-AllowControl`. For active control-effect validation, pass explicit enabled config (for example `<project>_fancontrol_enabled.json`) via `-ConfigPath`.
  - SW/DQA verdict split policy (Phase1): section runners must append `sw_verdict`/`dqa_verdict` and derive CI exit code from SW only.
    - `sw_verdict`: evaluate only `L1_configuration..L4_readback` (`FAIL*` in any => `FAIL_SW`, otherwise `PASS_SW`).
    - `dqa_verdict`: evaluate `L5_functional`/`L6_recovery` (`FAIL*=>FAIL_DQA`, both N_A/NOT_REQUIRED => `N_A_DQA`, both PASS => `PASS_DQA`, else `PENDING_DQA`).
    - Exit-code contract: `FAIL_SW -> non-zero`, `PASS_SW -> 0` even when DQA is pending/conditional.
  - Machine-B JSON builder contract: generated `<project>_fan.json`, `<project>_fancontrol.json`, `<project>_smbus.json`, `<project>_wdt.json` should include `verdict_policy` with the same SW/DQA mapping so runners and configs stay aligned.
  - Approval-gated side effects: SCP/SSH writes may be approved/denied per command. Do not chain multiple remote write actions in one shell command. Send one state-changing command at a time, wait for approval, then verify remote files before the next action.ase1): section runners must append `sw_verdict`/`dqa_verdict` and derive CI exit code from SW only.
    - `sw_verdict`: evaluate only `L1_configuration..L4_readback` (`FAIL*` in any => `FAIL_SW`, otherwise `PASS_SW`).
    - `dqa_verdict`: evaluate `L5_functional`/`L6_recovery` (`FAIL*=>FAIL_DQA`, both N_A/NOT_REQUIRED => `N_A_DQA`, both PASS => `PASS_DQA`, else `PENDING_DQA`).
    - Exit-code contract: `FAIL_SW -> non-zero`, `PASS_SW -> 0` even when DQA is pending/conditional.
  - Machine-B JSON builder contract: generated `<project>_fan.json`, `<project>_fancontrol.json`, `<project>_smbus.json`, `<project>_wdt.json` should include `verdict_policy` with the same SW/DQA mapping so runners and configs stay aligned.
  - Approval-gated side effects: SCP/SSH writes may be approved/denied per command. Do not chain multiple remote write actions in one shell command. Send one state-changing command at a time, wait for approval, then verify remote files before the next action.
  - Control-enable pitfall: `<project>_fancontrol.json` may intentionally keep `control_check.enabled=false` for safe default. In this case control runner returns `BLOCKED_CONFIGURATION` even with `-AllowControl`. For active control-effect validation, pass explicit enabled config (for example `<project>_fancontrol_enabled.json`) via `-ConfigPath`.
  - SW/DQA verdict split policy (Phase1): section runners must append `sw_verdict`/`dqa_verdict` and derive CI exit code from SW only.
    - `sw_verdict`: evaluate only `L1_configuration..L4_readback` (`FAIL*` in any => `FAIL_SW`, otherwise `PASS_SW`).
    - `dqa_verdict`: evaluate `L5_functional`/`L6_recovery` (`FAIL*=>FAIL_DQA`, both N_A/NOT_REQUIRED => `N_A_DQA`, both PASS => `PASS_DQA`, else `PENDING_DQA`).
    - Exit-code contract: `FAIL_SW -> non-zero`, `PASS_SW -> 0` even when DQA is pending/conditional.
  - Machine-B JSON builder contract: generated `<project>_fan.json`, `<project>_fancontrol.json`, `<project>_smbus.json`, `<project>_wdt.json` should include `verdict_policy` with the same SW/DQA mapping so runners and configs stay aligned.
  - Approval-gated side effects: SCP/SSH writes may be approved/denied per command. Do not chain multiple remote write actions in one shell command. Send one state-changing command at a time, wait for approval, then verify remote files before the next action.
  - When passing section-only INI files (e.g., `<project>_HWM.Fan.ini`), do not rely on wrapper model inference; pass explicit `-ConfigPath`/`-FanConfigPath` to avoid wrong `<model>_fan*.json` name resolution.
- Do not fabricate output.
- Interruption-retry gate: if a long-running `susi_gen.py` stage is interrupted (`exit_code=130`, e.g. terminal/user interruption) and no deterministic hard error is shown, rerun the exact same stage command once, then continue the pipeline from that stage on success. Report the exact blocked stage/command and exit code briefly before continuing.
- If probe fetch fails (WinRM/SSH), report exact stderr and stop; do not pretend success.
- For HWM.Voltage output, preserve project rules already encoded in `susi_gen.py`.
  - Alias fills Name field only; do not alias-remap left-side item keys by label text. Keep item key identity from report_name/channel semantics (avoid collapsing `V5SB` into `V50`).
  - 5V/5VSB disambiguation must be report_name-aware first: `HWM_VOLTAGE_5VSB` maps to `+5VSB` only when BIOS has 5VSB evidence; never auto-downgrade to plain `+5V`.
- Vision source policy: use Hermes `vision_analyze` (not offline OCR).
- Reasoning policy: use **high reasoning only** for circuit/BIOS image analysis and ambiguity judgment in the vision gate; all other stages follow Hermes default reasoning.
- Cache policy: hash-stable images should reuse prior vision results; only pending/missing items are analyzed.
- Handoff/compaction guard: if a context-compaction or handoff summary block appears, treat it as background only. Continue this skill using the latest explicit user request (e.g., `/susiagent <PROJECT>`). Do not switch to unrelated tasks or write side files outside the susiagent pipeline.
- No-op gate after handoff: if the latest turn is only a compaction/handoff reference block and contains no new executable user ask, perform zero pipeline actions and explicitly wait for the next concrete instruction.
- Handoff anti-drift guard (mandatory): after any compaction note, discard in-flight tool plans from before compaction. Re-resolve scope strictly from the latest explicit user message before any file read/run.
- Project-token anti-drift guard: never switch to or continue another project (for example by probing existing CASES files) unless that project token is explicitly present in the latest user request for this turn.
- Read-only scope gate: when user intent is file review/read (e.g., "看一下這檔案"), do only read/summarize actions for that turn; do not append deployment/run steps.
- Remote side-effect consent gate: require explicit current-turn user consent before SCP/SSH/WinRM writes, remote script execution, driver reload, or other state-changing Machine-B actions. A current invocation of `/susiagent <PROJECT> --all --host <HOST>` is that consent for the safe-default P5-P12 lifecycle only; an invocation without `--all` is not consent for Machine-B validation side effects. `--all` never implies consent for control/fixture/functional/SetConfig/stimulus/write opt-ins.
- Current-runtime quick-test gate: when the user says to simply run the PS1 against the current target and explicitly forbids INI update/reload, treat that as a strict diagnostic scope. Upload only runner/JSON/common helper to an isolated directory, pass the live INI by `-IniPath`, omit every functional/write/fixture switch, and prove the live INI hash is unchanged before/after. If builder JSON channels differ from live INI, keep the builder JSON untouched and use a clearly labelled temporary live-channel JSON only to observe current API behavior; report it as runtime diagnostics, never as generated-config validation. Follow `references/machineb-current-runtime-readonly-diagnostics.md`.
- Minimal-request anti-expansion gate: wording such as "簡單跑一下" / "只是想看目前結果" does not authorize related fixes, generator changes, INI deployment, reload, or functional tests. Perform the smallest read-only run that answers the question and stop after reporting the observed result.
- Change-safety gate for workflow/code updates: when user asks for rollback safety before modifications, create timestamped `.bk_<ts>` backups of each target file before applying patches (at minimum `fetch_probe.py` and this skill file when they are being edited).
- Denial handling gate: when a side-effect command is policy-denied, do not retry via alternate commands/paths; report blocked status and wait for approval.
- Local-stage denial recovery: if a combined local command is denied due to destructive pre-steps, do not retry by changing command shape in the same turn. Report the exact blocked path and wait for the user's decision. For repeatable validation artifacts, prefer a new unique `run-id` over deleting an existing `validation_runs/<run-id>` directory. If cleanup is genuinely required, identify the exact absolute directory and state what it contains before requesting deletion approval; never hide `rm -rf` inside a combined verification command.
- Information-source policy (probe-first):

- Information-source policy (probe-first):
  - Fan key handling is dynamic in logic: accept/generate `FOEM<n>` (`n>=0`) from evidence; never impose a fixed cap.
  - Keep compatibility display lists unchanged where required (for example, `FOEM0..FOEM6` in prompt/reference lists), but validators/parsers/generators must still accept `FOEM7+`.
  - `[HWM.Fan]` channel_id should follow fan item order as contiguous IDs (`0x80000000 + idx`) without gaps for the resolved fan key set.
  - Do not skip IDs just because schematic FAN_SPEED/TACH labels are non-contiguous.
  - `[HWM.Fan.Control]` channel_id may be shared across multiple fan items when they are driven by the same PWM source (one-to-many control).
- Information-source policy (probe-first):
- Reasoning policy: use **high reasoning only** for circuit/BIOS image analysis and ambiguity judgment in the vision gate; all other stages follow Hermes default reasoning.
- Cache policy: hash-stable images should reuse prior vision results; only pending/missing items are analyzed.
- Information-source policy (probe-first):

  - SMBus gating + channel-fill policy (spec + probe):
    - Decision order is mandatory: `SIO short-circuit` -> `spec gate` -> `CPU path`.
    - SIO route (`NCT6106D`/`NCT6116D`/`NCT6126D`/`NCT6776D*`) => SMBus remains `SECTION_EMPTY` by default.
    - EC route + Intel CPU => always emit fixed `Channel1` (idx=0) even when `spec.features.smbus=false`.
    - For non-Intel routes, `spec.features.smbus=false` still skips SMBus generation (`SECTION_EMPTY`).
    - `spec.features.smbus=true` => continue SMBus generation with probe-driven CPU/platform policy.
    - Preserve SMBus non-boolean context from understand output in `spec.feature_details.smbus` (especially `chip` / description text such as EC-related hints). Do not collapse all SMBus meaning to boolean only.
    - NCT6694B + EC/SOC hint path: Channel2 is mandatory from SMBus table fixed row (`hardware_id/channel_id/io_port/options`); if row missing, return pending blocker (`PENDING_SMBUS_FIXED_CHANNEL2_DB_ROW`).
    - Non-NCT6694B + EC/SOC hint path: Channel2 may be filled from SMBus table fixed row when DB row exists; if no row, continue normal Intel/AMD policy (no hard blocker).
    - Intel path: keep Channel1 fixed idx=0, then fill Channel2+ from full probe `SMBUS_OEMn ... EXISTS` evidence (`OEM0->Channel2`, `OEM1->Channel3`, channel field `0x80000000+n`). If non-NCT6694B EC/SOC fixed-row Channel2 exists, it can override Channel2 while Channel3+ still follows OEM evidence.
    - AMD path: Channel1 idx comes from SPD-idx probe; if Channel1 idx is `0..3` and SMBus is EC-related in spec details, set Channel2 fixed to idx=4 (`0x80000004`); if Channel1 idx is `4`, do not emit Channel2. If non-NCT6694B EC/SOC fixed-row Channel2 exists, it can override that Channel2 tuple.
    - Do not hardcode fixed Intel/AMD Channel2 behavior without checking the spec gate + probe evidence above.
    - Reference details/examples: `references/smbus-gating-and-channel-policy.md`.

  - Chip-role routing guard (EIO-300 / NCT6694B / NCT61xxD):
    - For EIO-300 + NCT6694B compound cases, route only `GPIO`/`I2C`/`SMBus` sections to `NCT6694B`; route other EC-side sections to `EIO-300` (`Advantech EIO_IS200` path).
    - Treat `NCT61xxD` (for example `NCT6106D`/`NCT6116D`/`NCT6126D`) as pure SuperIO routing, not EC.
    - Do not infer EC/SIO solely from vendor string style; apply section-aware routing by chip role.
    - EIO-201 and EIO-211 may share `hardware_id=0x30313640` but are distinct chip identities/generations. Keep lookup key atomic at `(product_name, chip_name)` and avoid slash-joined chip names.
    - If DB lacks `EIO-211` ProductChip row, treat this as a data-model gap to fix in DB/schema; do not auto-fallback to `EIO-300` for convenience, because that can wrongly trigger NCT6694B routing in EC cases.
    - Verification gate (implementation, not docs-only): after generate/all, read `<PROJECT>-section-matrix.json` and assert `query_key.chip_name` by section — `SMBus/I2C/GPIO => NCT6694B`, all other EC-side sections => `EIO-300`. If any mismatch appears (for example `GPIO` still queried with `EIO-300`), treat it as generator routing defect, patch `susi_gen.py` section-level chip resolution, rerun, then re-verify section matrix and regenerated INIs.
    - Reference: `references/chip-role-routing.md`.

  - `PlatformVersion` must come from probe `BOARD_PLATFORM_REV_VAL` when available.
  - `BIOSVersion` must come from probe `BOARD_BIOS_REVISION_STR` when available.
  - Fallback only when probe value is missing.
  - Intel SMBus Channel2+ must be derived from full probe SMBus evidence (not hardcoded blank):
    - Parse `SMBUS_OEM<n> ... : EXISTS` from `<PROJECT>_susi_board_probe_report.txt`.
    - Map `OEM0 -> Channel2`, `OEM1 -> Channel3`, ... (bounded to Channel2..Channel5).
    - For each mapped channel use:
      - field1 `hwid` = ProductChip `hardware_id` (fixed lookup key `(product_name, chip_name)`)
      - field2 `channel` = `0x80000000 + n`
      - field3 `io_port` = `0`
      - field4 `option` = `0xA0000000`
    - Keep Channel1 fixed template (`0x00000001,0,0,0xA0000000,`).
    - If no `SMBUS_OEM<n> EXISTS` evidence, Channel2+ may remain empty.
- Post-run check: verify `[Information]` lines in `<PROJECT>-pre.ini` reflect probe-derived values.
   - Probe parsing note: this report format is `[OK] ... Value=...` / `Value="..."`, not `KEY=VALUE` lines. Extract values from the `Value=` field on the matching `BOARD_*` row.
   - Key-name rendering invariant: `[HWM.Current]` must use `OEM0/OEM1/...` keys (not DB raw names like `CURRENT_OEM0`), and `[VGA.Backlight]` must use `BACKLIGHT1/BACKLIGHT2/...` (not `BACKLIGHT_1`). Verify this in split INIs and `<PROJECT>-pre.ini` after regeneration.
   - Name-field rendering invariant: `[HWM.Current]`, `[StorageArea]`, and `[ThermalProtect]` Name fields remain blank (trailing empty field); do not apply BIOS alias backfill to these sections. After every regeneration, verify this in each corresponding split INI and again in `<PROJECT>-pre.ini`. Stable section keys identify these rows.
- Alias/label type invariant: BIOS temperature and fan hint artifacts may contain structured values such as `{"label": "CPU Temperature", "evidence": ...}` or legacy Python-dict string representations. Before rendering `[HWM.Temperature]`, `[HWM.Fan]`, and `[HWM.Fan.Control]`, coerce every display hint to its plain string `label`; never stringify the full dict into an INI field. After regeneration, assert that alias/name fields are scalar plain strings and contain no `{'label': ...}` or `"label":` payload. See `references/alias-label-normalization-and-ini-validation.md`.
   - Implementation consistency gate: probe-first policy must be enforced by the active generator code, not only by this skill. Before declaring completion, inspect the generated `[Information]` values and, when they disagree with probe rows, treat the generator fallback/hardcoded default as a defect: patch the generator to use the parsed probe value first, retain spec/project fallback only when the probe field is absent, then rerun the full pipeline and reverify all project-scoped artifacts.

- Spec understand output policy (preserve feature context):
  - `features.smbus` remains a boolean compatibility flag for generation gates.
  - Do not collapse SMBus metadata to boolean-only output in `<PROJECT>-spec.json`.
  - Preserve extractor-derived feature context (chip/model/description text such as `EC`, specific EC model, or mixed descriptors like `PCH or EC ...`) in a structured object (for example `feature_details.smbus`).
  - Apply the same preservation pattern to other SUSI features when present (`i2c`, `watchdog`, `storage_eeprom`, etc.) so spec keeps source semantics while generators continue using boolean gates.

- I2C maximum-set versus full-probe filtering:
  - Treat `config_new.db` I2C rows as the maximum topology; do not modify the DB to fit one board.
  - When full probe `i2c_buses` data exists, intersect DB rows with probe-supported buses before rendering `[I2C]`. Prefer exact `report_name` to probe bus-name matching; if the DB row has no report name, fall back to decoded encoded-channel ID versus probe `probe_id`.
  - A probe line such as `Devices found: (none)` still represents a supported bus with no detected slave; filter on `supported`/`not supported` status and capability IDs, not device count.
  - If no probe bus list is available, preserve DB maximum-set behavior rather than silently emitting an empty section.
  - Preserve the encoded INI tuple channel separately from public API IDs, record filtered IDs in diagnostics, and add regression coverage for a four-row DB reduced to the two buses supported by the probe. Reference: `references/i2c-db-maximum-probe-filter.md`.

- HWM.Temperature query policy:
  - Do NOT treat `HWM.Temperature.Channels` / `HWM.Temperature.Defaults` as direct section-query targets in `query_config_db.py`.
  - Temperature generation path must be probe-driven in `susi_gen.py`: use probe `[OK]` temperature items to resolve matching `config_new.db` `HWM.Temperature` rows by `hardware_id`/`report_name`, then take `io_port`, `options`, `offset` and channel fields from the matched section row, with display name backfilled from BIOS/spec alias when available.
  - Validation should be done on generated `_<SECTION>.ini` / `<PROJECT>-pre.ini` outputs, not by forcing legacy direct table queries.
  - Machine-B validator ID-namespace gate: the HWM.Temperature INI tuple's second field (typically `0x80000000 + index`) is an encoded configuration channel, not the `SusiBoardGetValue()` API ID. Build section JSON API IDs from the canonical SUSI temperature namespace (`0x00020000 + index`), preserve the tuple channel separately, and fail generation for unknown keys instead of copying the tuple field. Before any option fallback, compare the runner API ID with the full-probe `[OK] HWM_TEMP_*` ID. See `references/machineb-temperature-api-id-vs-ini-channel.md`.
  - Temperature display-name backfill is a separate BIOS-vision pass from voltage cache analysis. Run high-reasoning vision on scoped `bios*.png` and extract only clearly visible real-time sensor labels; do not use threshold/configuration labels such as `CPU Shutdown Temperature` as sensor names.
  - Persist normalized evidence as `<PROJECT>-temperature-name-hints.json` and apply it after probe/DB channel resolution, preserving probe-driven item existence and channel/template fields. Regenerate and verify both `_<SECTION>.ini` and `<PROJECT>-pre.ini`.
  - Option-fallback orchestration is A-side owned: keep canonical helper at `tools/hwm_temperature_option_fallback.py`, invoke it from `susi_gen.py` in generate flow (not manual B-side-only execution), apply to both split section INI and pre-INI, and record decision/route marker (`+TEMP_OPTION_FALLBACK`) in section-matrix when triggered.
  - Candidate fallback must run as ordered iteration, not one-shot toggle: for each `(io_port, options)` candidate do apply -> deploy/reload/reprobe -> evaluate, stop at first non-all-ERR, otherwise return exhausted (`ALL_CANDIDATES_FAILED`).
  - Candidate set is expected to grow incrementally across sessions; do not require "complete candidate list" upfront before enabling the loop.
  - Reference: `references/temperature-name-backfill.md`.
  - Troubleshooting addendum (jpg/jpeg fallback + alias completion gate): `references/image-format-fallback-and-alias-gate.md`.
  - Integration note: `references/temperature-option-fallback-a-side-orchestration.md`.

- VGA.Brightness generation policy (DB-first):
  - Do not hardcode Brightness `Max/Min/Frequency` in renderer defaults when DB provides values.
  - Resolve the fixed `(product_name, chip_name)` to `ProductChip.hardware_id`, then consume the matching `VGA.Brightness` row (`report_name`, `channel_name`, `channel_id`, `io_port`, `options`, ranges, frequency) directly.
  - Do not add or require a project-specific routing JSON when the hardware-specific DB row already contains the complete channel tuple. A rule such as `project + controller + socket + display chip -> AUXOUT` is redundant when the resolved DB row already says `channel_name=AUXOUT`; treating it as a required file embeds a project answer outside the database.
  - `query_config_db.py` must project `range_max`, `range_min`, and `frequency` columns from `VGA.Brightness` rows (when present).
  - `susi_gen.py` rendering for `[VGA.Brightness]` must consume DB fields in order: `[Max]=range_max`, `[Min]=range_min`, `[Frequency]=frequency`.
  - Legacy fallback (`100,0,0`) is allowed only when those DB fields are absent/empty for compatibility.
  - Verification gate: after generate/all run, re-read both `<PROJECT>_VGA.Brightness.ini` and `<PROJECT>-pre.ini` and confirm Brightness tuple matches DB row values for the fixed `(product_name, chip_name)` key.

- HWM.Fan / HWM.Fan.Control hybrid policy (code + AI boundary):
  - Do NOT treat DB query rows as final mapping for FAN sections. Query is baseline only.
  - Query API boundary (important): generic `query_config_db.py` section queries target the hardware-specific `HWM.Fan` table in `config_new.db`; do not query retired `HWM.Fan.Defaults` / `HWM.Fan.Channels` tables. Use `load_hwm_fan_defaults()` only for the shared fan-template compatibility path.
  - Current fallback behavior: do not require physical `HWM.Fan.Control` table rows to generate fan-control output. `HWM.Fan`/`HWM.Fan.Control` may be synthesized from probe/pairing/hints + deterministic channel construction when DB fan rows are partial/empty for the chip.
  - Keep fan-default applicability aligned with generator code (currently includes `EIO-201`, `EIO-211`, `IT-8528`, `IT-5782`, `IT-5121`).
  - AI/vision is REQUIRED for topology judgement (`FAN_ONE_TO_ONE_CONFIRMED` vs `FAN_ONE_TO_MANY_CONFIRMED` vs ambiguous/pending), especially on AIMB/ASMB and other non-1:1 boards.
  - Reference: `references/fan-defaults-query-boundary.md`.
  - Python generation should consume a structured pairing artifact (prefer `<PROJECT>-fan-pairing.json`; fallback `<PROJECT>-fan-analysis.json`) and then apply deterministic channel fill:
    - one-to-one: `HWM.Fan.Control` follows `HWM.Fan` channel by key (or `base + control_idx` when key-only fallback is needed)
    - one-to-many: `HWM.Fan.Control` uses `base + control_idx` and may share channel_id across keys
  - Stable convention must be encoded in code (not docs-only) to avoid drift:
    - Default fan idx mapping: `FCPU -> 0`, `FSYS -> 1`.
    - Precedence order for resolved idx/channel is: (1) explicit evidence from pairing (`fanin_idx_candidate` / `control_idx_candidate`), then (2) stable convention defaults, then (3) next free idx for remaining keys.
    - If evidence conflicts with convention, evidence wins; do not force conventional idx.
  - Fan `io_port` (3rd field in FAN rows) is chip-gated, not globally hardcoded:
    - Use `0x2E` only when `chip_name` is `NCT6106D`, `NCT6116D`, or `NCT6126D`.
    - For other chip names, do not default to `0x2E` (use generator non-`0x2E` route, commonly `0`).
    - Apply the same resolved `io_port` rule to both `[HWM.Fan]` and `[HWM.Fan.Control]`.
  - Fan display-name backfill must be code-driven (not docs-only / manual rename):
    - Name source priority: `<PROJECT>-fan-name-hints.json` > BIOS vision cache extraction > key fallback alias (`FCPU->CPU Fan`, `FSYS->System Fan`, `FOEMn->OEM Fan n`).
    - If BIOS cache is voltage-focused and lacks fan wording, run a fan-focused `vision_analyze` pass on `bios*.png` and persist normalized hints into `<PROJECT>-fan-name-hints.json`.
    - Apply identical resolved display names to both `[HWM.Fan]` and `[HWM.Fan.Control]` rows for the same fan key unless explicit evidence requires divergence.
  - Minimal machine contract is preferred (no manual cleanup):
    - `{ "topology_status": "...", "items": [{"key":"FCPU/FSYS/FOEMx","fanin_idx_candidate":<int|null>,"control_idx_candidate":<int|null>}] }`
    - Extra metadata is optional and should not be required for downstream consumption.
  - If AI result is pending/ambiguous (`FAN_PAIRING_AMBIGUOUS` / `FAN_PAIRING_NEEDS_FANCONTROL_EVIDENCE`), keep section pending in matrix and do not force output channels.
  - Critical verification gate: even with valid pairing/probe, do not claim fan sections generated unless section matrix shows non-`INVALID_SECTION` for both `HWM.Fan` and `HWM.Fan.Control`.
  - Data-flow contract: AI decides topology + idx candidates; Python owns template rendering, channel arithmetic, validation, and section-matrix recording.
  - Troubleshooting reference: `references/fan-sections-db-baseline-blocker.md`.

    - tolerate verbose upstream payloads at ingest, but normalize/write back to minimal contract for pipeline continuity
    - avoid adding non-essential fields (`schema_version`, `project`, `source`, `summary`, `reason`) unless a caller explicitly requires them
  - If AI result is pending/ambiguous (`FAN_PAIRING_AMBIGUOUS` / `FAN_PAIRING_NEEDS_FANCONTROL_EVIDENCE`), keep section pending in matrix and do not force output channels.
  - Data-flow contract: AI decides topology + idx candidates; Python owns template rendering, channel arithmetic, validation, and section-matrix recording.
  - Reference: `references/fan-pairing-minimal-contract.md`.
  - Fan display-name backfill reference (BIOS vision -> hints JSON -> INI disp_name): `references/fan-name-backfill.md`.
  - Fan-name completion gate: after any generate/all run that is expected to use BIOS-visible names, read both generated files and verify every resolved fan key has the same non-fallback display name in `[HWM.Fan]` and `[HWM.Fan.Control]`. Do not report completion while either section still contains fallback aliases such as `CPU Fan` / `System Fan` when BIOS evidence or explicit hints exist. If the voltage cache has no fan wording, run a separate fan-focused vision pass over scoped `bios*.png`, write normalized `<PROJECT>-fan-name-hints.json`, regenerate, then re-read the INIs.

- GPIO policy (EC-first, mandatory):
  - First decide route from `spec.json` / chip context: if GPIO is EC route, do **not** run image tracing as the baseline path.
  - GPIO INI key formatting guard: render GPIO item keys as zero-padded two digits (`GPIO00`, `GPIO01`, `GPIO02`, ...). Do not emit single-digit keys like `GPIO0`/`GPIO1`.
  - EC baseline path is DB-driven and deterministic:
    1) query ProductChip by fixed key `(product_name, chip_name)` to get `hwid`
    2) read hardware-specific rows from the `GPIO` section table for template fields
    3) use the row-level `group`/`pin` mapping from the `GPIO` section table
    4) trim rows by probe-first GPIO evidence before spec fallback: use probe `gpio.keys`/`gpio.count` when available; otherwise use `spec.gpio.count` or `len(spec.gpio.pins)`
    5) HWM.Voltage key policy: keep item_name derived from `report_name/channel_id` semantics; alias mapping only fills Name(disp_name), never remap 5V/5VSB keys by alias text.
    6) VBAT exception: if BIOS confidently shows VBAT and the only matching row is `HWM_VOLTAGE_VBATLI` while no true `VBAT` key exists in section, promote key `VBATLI -> VBAT` exactly once.
    7) BIOS singleton-remainder mapping: when alias bridge has exactly one unresolved voltage row and BIOS has exactly one unused known rail label (including +9V), assign that remaining label to that remaining row with explicit reason tag. (see `references/voltage-alias-bridge-rules.md`)
  - For EC route, image/PDF GPIO tracing is exception-only (used only when DB/spec evidence is missing or user explicitly asks), not default workflow.
  - NON-EC/SIO guard (important): if route is SIO/NON-EC and `spec.gpio` is empty, do **not** finalize from `config_new.db` GPIO rows alone; run/consume circuit-trace artifact first (`<PROJECT>-gpio-trace.json`), then fallback to spec/DB only for unresolved rows.
  - SIO rule lock (must follow project rulebook): apply `AnalysisSKill/bios_circuit_image_analysis_rule.md` R-016/R-017 semantics when building GPIO trace.
    - Build a single `target_signal_set` first (chip-aware default for `NCT6126D/NCT6116D/NCT6106D/NCT6776D` is `SIO_GPIO*`).
    - If default pattern has no hits, try alternate GPIO naming patterns and choose only one evidence-consistent set; if multiple remain plausible, mark `GPIO_SIGNAL_SCOPE_AMBIGUOUS` (do not union them).
    - Keep `OUT_OF_SCOPE` nets out of mapping output (including FAN/BEEP/LED/PORT80 helper nets even if pin text contains `GP*`).
    - NCT61xxD strict SIO_GPIOn normalization: when low-bank `SIO_GPIO0..7` evidence exists, do not co-emit high-bank aliases (`SIO_GPIO80/81/...`) in the same GPIO output. Normalize final emitted set to the project-approved scope (for AIMB-289 this is 8 items: `GPIO00..GPIO07`).
    - If generated trace JSON conflicts with user-reviewed schematic count/scope, treat trace artifact as stale/noisy and regenerate or normalize before claiming final GPIO results; do not present artifact-only labels as confirmed board truth.
  - Circuit evidence source rule: for NON-EC/SIO GPIO tracing, ingest both `circuit*` raster files and rendered pages from `circuit*.pdf` when available in the same run; PDF is evidence complement, not raster-only fallback. Do not ingest `bios*` images for GPIO mapping.
  - For EC route, image/PDF GPIO tracing is exception-only (used only when DB/spec evidence is missing or user explicitly asks), not default workflow.
  - For SIO route (for example NCT6126D/NCT6116D/NCT6106D/NCT6776D), apply circuit-trace-first with R-016 scope discipline: build `target_signal_set` first and only output that set (default naming hint: `SIO_GPIO*`, unless user explicitly overrides). Do not mix nearby non-target nets (`SIO_LED*`, `ESPI*`, FAN/BEEP) into GPIO output.
  - SIO GPIO source ingestion must include both `circuit*.png|jpg|jpeg` and rendered `circuit*.pdf` pages when present; PDF is co-evidence, not png-only fallback.
  - Stale-artifact guard: if any `circuit*` source is newer than `<PROJECT>-gpio-trace.json`, or the trace content fails chip-aware scope sanity (for example no `SIO_GPIO*` items on NCT6126D route), regenerate trace before `generate`.
  - Do NOT ask the user to manually create or edit GPIO trace artifacts in normal `/susiagent` runs.
  - Keep strict scope to `bios*` / `circuit*` assets when visual analysis is explicitly needed.
  - Reference: `references/sio-gpio-scope-and-stale-trace.md`.
